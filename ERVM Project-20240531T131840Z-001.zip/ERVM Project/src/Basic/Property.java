/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Basic;

/**
 *
 * @author Roberto de Medeiros
 */
public class Property {
    /*
     * Privados
     */
    private String type;
    private String name;
    private String value;
    private String internal;

    /*
     * Públicos
     */

    /*
     * Tipo do identificador
     */
    public String getType(){
        return this.type;
    }

    public void setType(String obj){
        this.type = obj;
    }

    /*
     * Nome
     */
    public String getName(){
        return this.name;
    }

    public void setName(String obj){
        this.name = obj;
    }

    /*
     * Valor
     */
    public String getValue(){
        return this.value;
    }

    public void setValue(String obj){
        this.value = obj;
    }

    /*
     * Valor Strig (livre) a ser colocado internamente no elemento
     */
    public String getInternal(){
        return this.internal;
    }

    public void setInternal(String obj){
        this.internal = obj;
    }

    /*
     * Construtor
     */
    public Property(String name, String value){
        this.type = "";
        this.name = name;
        this.value = value;
        this.internal = "";
    }

    public Property(String type, String name, String value, String internal){
        this.type = type;
        this.name = name;
        this.value = value;
        this.internal = internal;
    }

    public Property(String name, String value, String internal){
        this.type = "";
        this.name = name;
        this.value = value;
        this.internal = internal;
    }
}
