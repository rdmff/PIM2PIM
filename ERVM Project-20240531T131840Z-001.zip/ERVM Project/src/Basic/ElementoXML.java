/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Basic;

/**
 *
 * @author Roberto de Medeiros
 */
public class ElementoXML {
    private String _id;
    private String _elem;
    private String _atrib;

    public String getId(){
        return this._id;
    }

    public void setId(String value){
        this._id = value;
    }

    public String getElemento(){
        return this._elem;
    }

    public void setElemento(String value){
        this._elem = value;
    }

    public String getAtribute(){
        return this._atrib;
    }

    public void setAtribute(String value){
        this._atrib = value;
    }
}
