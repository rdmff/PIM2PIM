/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Basic;

/**
 *
 * @author Roberto de Medeiros
 */
public class Hex {
    public static String convetHexadecimal(int value){
        //System.out.println(Integer.toHexString(value));
        return ("0x" + Integer.toHexString(value));
    }

    public static int convetDecimal(String value){
        return Integer.parseInt(value,16);
    }
}
