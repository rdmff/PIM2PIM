/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Basic;

import java.io.*;

/**
 *
 * @author Roberto de Medeiros
 */
public class TextFile {
    
   public static void Write(String FullText, String FullPath) throws IOException{
        
        FileWriter file = new FileWriter(FullPath,false);
        BufferedWriter buffW = new BufferedWriter(file);
        
        buffW.write(FullText);        
        buffW.close();
        //file.close();
    }
    
    /*public static void Write(String FullText, String FullPath) throws IOException{
        //
    }*/
    
    public static String Read(String FullPath) throws FileNotFoundException, IOException{
        FileReader fr = new FileReader(FullPath);
        BufferedReader in = new BufferedReader(fr);
        String strFull = "";
        String str;
        while ((str = in.readLine()) != null) {
            strFull += str;
        }
        fr.close();
        in.close();
        
        return strFull;
    }
}
