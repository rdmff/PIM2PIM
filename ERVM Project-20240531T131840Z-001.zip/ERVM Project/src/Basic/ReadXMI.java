/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Basic;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Roberto de Medeiros
 */
public class ReadXMI {
//    public static void main(String argv[]) {
//         try {
//                /*
//                 * Nesta primeira parte do código, faço as cargas iniciais e declaração de variáveis
//                 * correto:
//                 * File fXmlFile = new File(path);
//                 */
//                File fileXml = new File("C:\\ROBERTO\\NiosIIModeling.xml");
//                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
//                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
//                Document doc = dBuilder.parse(fileXml);
//                Node nNode, subNode, kNode;
//                NodeList nList, subList, kList;
//                Element elem;
//                //
//                doc.getDocumentElement().normalize();
//                //
//                nList = ((NodeList)doc.getChildNodes()).item(0).getChildNodes();
//                System.out.println("----------XMI-READ-STARTED----------");
//                //
//                nNode = null;
//                for(int i = 0; i < nList.getLength(); i++){
//                    nNode = nList.item(i);
//                    //aqui, removo o if e captura todos os nós
//                    //captura as propriedades
//                    if (nNode.getNodeType() == Node.ELEMENT_NODE){
//                          elem = (Element) nNode;
//                          //funciona com [name,kind]
//                          if(elem.getNodeName()=="uml:Model")
//                              i=nList.getLength();//break
//                    }
//                }
//                /*
//                 * Captura o elemento chave que contém as informações fundamentais
//                 */
//                nList = nNode.getChildNodes();
//                for(int i = 0; i < nList.getLength(); i++){
//                    nNode = nList.item(i);
//                    if (nNode.getNodeType() == Node.ELEMENT_NODE){
//                        elem = (Element) nNode;
//                        if(! elem.getAttribute("name").equals("")){
//                            i=nList.getLength();//break
//                        }
//                    }
//                }
//                /*
//                 * Captura todos componentes.
//                 */
//                //do{
//                    //
//                    nList = nNode.getChildNodes();
//                    for(int i = 0; i < nList.getLength(); i++){
//                        nNode = nList.item(i);
//                        elem = null;
//                        if (nNode.getNodeType() == Node.ELEMENT_NODE){
//                            elem = (Element) nNode;
//                            System.out.println("\n" + elem.getAttribute("name"));
//                            /*
//                             * Captura todos atributos dos componentes. Obs.: estes têm tipo.
//                             */
//                            subList = elem.getChildNodes();
//                            for(int j = 0; j < subList.getLength(); j++){
//                                subNode = subList.item(j);
//                                if (subNode.getNodeType() == Node.ELEMENT_NODE){
//                                    elem = (Element) subNode;
//                                    System.out.print("\n"+elem.getAttribute("name"));
//                                    /*
//                                     * ainda há erro, embora o type apareça
//                                     */
//                                    kList = subNode.getChildNodes();
//                                    for(int k = 0; k < kList.getLength(); k++){
//                                        kNode = kList.item(k);
//                                        if (kNode.getNodeType() == Node.ELEMENT_NODE){
//                                            elem = (Element) kNode;
//                                            System.out.print("=" + elem.getAttribute("value"));
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//                    //
//                //}while(nList != null);
//                //
//                System.out.println("----------XMI-READ-FINISHED---------");
//          } catch (Exception e) {
//            e.printStackTrace();
//          }
//     }


//    /*
//     *
//     */
//    public List<String> load(String path) {
//        List<String> xmi = new LinkedList<String>();
//        try {
//            /*
//             * Nesta primeira parte do código, faço as cargas iniciais e declaração de variáveis
//             * Correto: File fXmlFile = new File(path);
//             */
//            File fileXml = new File(path);
//            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
//            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
//            Document doc = dBuilder.parse(fileXml);
//            Node nNode, subNode, kNode;
//            NodeList nList, subList, kList;
//            Element elem, elem2;
//            String atributo = "";
//            /*
//             *
//             */
//            doc.getDocumentElement().normalize();
//            //
//            nList = ((NodeList)doc.getChildNodes()).item(0).getChildNodes();
//            //System.out.println("----------XMI-READ-STARTED----------");
//            //
//            nNode = null;
//            for(int i = 0; i < nList.getLength(); i++){
//                nNode = nList.item(i);
//                //aqui, removo o if e captura todos os nós
//                //captura as propriedades
//                if (nNode.getNodeType() == Node.ELEMENT_NODE){
//                      elem = (Element) nNode;
//                      //funciona com [name,kind]
//                      if(elem.getNodeName()=="uml:Model")
//                          i=nList.getLength();//break
//                }
//            }
//            /*
//             * Captura o elemento chave que contém as informações fundamentais
//             */
//            nList = nNode.getChildNodes();
//            for(int i = 0; i < nList.getLength(); i++){
//                nNode = nList.item(i);
//                if (nNode.getNodeType() == Node.ELEMENT_NODE){
//                    elem = (Element) nNode;
//                    if(! elem.getAttribute("name").equals("")){
//                        i=nList.getLength();//break
//                    }
//                }
//            }
//            /*
//             * Captura todos componentes. nNode contém o nó inicial
//             */
//            xmi.add("Project:" + ((Element)nNode).getAttribute("name"));
//            nList = nNode.getChildNodes();
//            for(int i = 0; i < nList.getLength(); i++){
//                nNode = nList.item(i);
//                elem = null;
//                if (nNode.getNodeType() == Node.ELEMENT_NODE){
//                    elem = (Element) nNode;
//                    //xmi.add("Elemento:" + elem.getAttribute("name"));
//                    //xmi.add("id=" + elem.getAttribute("xmi:id"));//pega os IDs de cada elemento
//                    /*
//                     * Faz os objetos de conexão (ainda não tratados).
//                     */
//                    if(elem.getAttribute("xmi:type").equals("uml:Association")){
//                        kList = nNode.getChildNodes();
//                        //
//                        subNode = kList.item(1);
//                        kNode = kList.item(3);
//                        elem = (Element)subNode;
//                        elem2 = (Element)kNode;
//                        //
//                        xmi.add("Connection=" + elem.getAttribute("xmi:idref") + "=" + elem2.getAttribute("xmi:idref"));
//                        //
//                    } else{
//                        /*
//                         * Captura todos atributos dos componentes. Obs.: estes têm tipo.
//                         */
//                        xmi.add("Element=" + elem.getAttribute("name"));
//                        subList = elem.getChildNodes();
//                        for(int j = 0; j < subList.getLength(); j++){
//                            subNode = subList.item(j);
//                            //
//                            if(subNode.getNodeType() == Node.ELEMENT_NODE){
//                                if(((Element) subNode).getAttribute("name").equals("")){
//                                //if(j==subList.getLength()){
//                                    xmi.add("Id=" + ((Element) subNode).getAttribute("xmi:id"));//pega os IDs de cada elemento
//                                } else{
//                                    elem = (Element) subNode;
//                                    atributo = "Atribute=" + elem.getAttribute("name");
//                                    /*
//                                     * Ainda há erro, embora o type apareça
//                                     */
//                                    kList = subNode.getChildNodes();
//                                    for(int k = 0; k < kList.getLength(); k++){
//                                        kNode = kList.item(k);
//                                        if (kNode.getNodeType() == Node.ELEMENT_NODE){
//                                            elem = (Element) kNode;
//                                            xmi.add(atributo + "=" + elem.getAttribute("value"));
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//            //System.out.println("----------XMI-READ-FINISHED---------");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return xmi;
//     }

    /*
     *
     */
    public List<String> load(String path) {
        List<String> xmi = new LinkedList<String>();
        try {
            /*
             * Nesta primeira parte do código, faço as cargas iniciais e declaração de variáveis
             * Correto: File fXmlFile = new File(path);
             */
            File fileXml = new File(path);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fileXml);
            Node nNode, subNode, kNode;
            NodeList nList, subList, kList;
            Element elem, elem2;
            String atributo = "";
            String elemento;
            int count = 0;
            /*
             *
             */
            doc.getDocumentElement().normalize();
            //
            nList = ((NodeList)doc.getChildNodes()).item(0).getChildNodes();
            //System.out.println("----------XMI-READ-STARTED----------");
            //
            nNode = null;
            for(int i = 0; i < nList.getLength(); i++){
                nNode = nList.item(i);
                //aqui, removo o if e captura todos os nós
                //captura as propriedades
                if (nNode.getNodeType() == Node.ELEMENT_NODE){
                      elem = (Element) nNode;
                      //funciona com [name,kind]
                      if(elem.getNodeName()=="uml:Model"){
                      //if(elem.getNodeName()=="xmi:Extension"){
                          //count++;
                          //if(count==2){
                            i=nList.getLength();//break
                          //}
                      }
                }
            }
            /*
             * Captura o elemento chave que contém as informações fundamentais
             */
            nList = nNode.getChildNodes();
            nList = nList.item(0).getChildNodes();
            for(int i = 0; i < nList.getLength(); i++){
                nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE){
                    elem = (Element) nNode;
                    if(! elem.getAttribute("name").equals("")){
                        i=nList.getLength();//break
                        break;
                    }
                }
            }
            /*
             * uml:Class
             */
            nList = nNode.getChildNodes();
            //nList = nList.item(0).getChildNodes();
            for(int i = 0; i < nList.getLength(); i++){
                nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE){
                    elem = (Element) nNode;
                    if( ((Element)nNode).getAttribute("xmi:type").equals("uml:Class")){
                        i=nList.getLength();//break
                        break;
                    }
                }
            }
            /*
             * Captura todos componentes. nNode contém o nó inicial
             */
            xmi.add("Project:" + ((Element)nNode).getAttribute("name"));
            //xmi.add("Project: beta");
            nList = nNode.getChildNodes();
            for(int i = 0; i < nList.getLength(); i++){
                nNode = nList.item(i);
                elem = null;
                if (nNode.getNodeType() == Node.ELEMENT_NODE){
                    elem = (Element) nNode;
                    //xmi.add("Elemento:" + elem.getAttribute("name"));
                    //xmi.add("id=" + elem.getAttribute("xmi:id"));//pega os IDs de cada elemento
                    /*
                     * Faz os objetos de conexão (ainda não tratados).
                     */
                    if(elem.getAttribute("xmi:type").equals("uml:Association")){
                        kList = nNode.getChildNodes();
                        //
                        subNode = kList.item(1);
                        kNode = kList.item(3);
                        elem = (Element)subNode;
                        elem2 = (Element)kNode;
                        //
                        xmi.add("Connection:" + elem.getAttribute("xmi:idref") +
                                "=" + elem2.getAttribute("xmi:idref"));
                        //
                    } else if(elem.getAttribute("xmi:type").equals("uml:Class")){
                        /*
                         * Captura todos atributos dos componentes. Obs.: estes têm tipo.
                         */
                        elemento = elem.getAttribute("name") + "@";
                        //xmi.add("Element=" + elem.getAttribute("name"));
                        subList = elem.getChildNodes();
                        for(int j = 0; j < subList.getLength(); j++){
                            subNode = subList.item(j);
                            //
                            if(subNode.getNodeType() == Node.ELEMENT_NODE){
                                if(((Element) subNode).getAttribute("name").equals("")){
                                //if(j==subList.getLength()){
                                    elemento += "Id:" + ((Element) subNode).getAttribute("xmi:id") + ";";
                                    //xmi.add("Id=" + ((Element) subNode).getAttribute("xmi:id"));
                                    //pega os IDs de cada elemento
                                } else{
                                    elem = (Element) subNode;
                                    elemento += "Atributo:" + elem.getAttribute("name");
                                    //atributo = "Atribute=" + elem.getAttribute("name");
                                    /*
                                     * Ainda há erro, embora o type apareça
                                     */
                                    kList = subNode.getChildNodes();
                                    if(kList.getLength() == 0)
                                        elemento = elemento + ";";
                                    for(int k = 0; k < kList.getLength(); k++){
                                        kNode = kList.item(k);
                                        if (kNode.getNodeType() == Node.ELEMENT_NODE){
                                            elem = (Element) kNode;
                                            elemento += "=" + elem.getAttribute("value") + ";";
                                            //xmi.add(atributo + "=" + elem.getAttribute("value"));
                                        }
                                    }
                                }
                            }
                        }
                        xmi.add(elemento);
                    }
                }
            }
            //System.out.println("----------XMI-READ-FINISHED---------");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return xmi;
     }
}
