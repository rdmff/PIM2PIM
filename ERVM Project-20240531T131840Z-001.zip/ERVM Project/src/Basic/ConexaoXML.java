/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Basic;

/**
 *
 * @author Roberto de Medeiros
 */
public class ConexaoXML {
    private String _id1;
    private String _id2;

    public String getId1(){
        return this._id1;
    }

    public void setId1(String value){
        this._id1 = value;
    }

    public String getId2(){
        return this._id2;
    }

    public void setId2(String value){
        this._id2 = value;
    }
}
