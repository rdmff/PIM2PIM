/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Repository;

import java.util.LinkedList;
import java.util.List;

/**
 * Faz a leitura dos componentes fundamentais de um arquivo xmi
 * @author Roberto de Medeiros
 */
public class RepositoryAltera {
    /*
     * Atributos Privados
     */
    private String tipo;
    private String nome;
    private List<String> atributo;
    private List<String> ids;

    /*
     * Atributos Públicos
     */

    public int getSizeAtributo(){
        return atributo.size();
    }
    //
    public int getSizeId(){
        return ids.size();
    }
    /*
     * Tipo
     */
    public String getTipo(){
        return this.tipo;
    }

    public void setTipo(String value){
        this.tipo = value;
    }

    /*
     * Nome
     */
    public String getNome(){
        return this.nome;
    }

    public void setNome(String value){
        this.nome = value;
    }

    /*
     * Atributo
     */
    public String getAtributo(int index){
        return this.atributo.get(index);
    }

    public String setAtributo(int index, String valor){
        return this.atributo.set(index, valor);
    }

    public void addAtributo(String valor){
        this.atributo.add(valor);
    }

    public void delAtributo(int index){
        this.atributo.remove(index);
    }

    /*
     * Ids
     */
    public String getId(int index){
        return this.ids.get(index);
    }

    public String setId(int index, String valor){
        return this.ids.set(index, valor);
    }

    public void addId(String valor){
        this.ids.add(valor);
    }

    public void delId(int index){
        this.ids.remove(index);
    }


    /*
     *
     */
    /*private void start(){
        //
    }*/

    public RepositoryAltera(){
        this.atributo = new LinkedList<String>();
        this.ids = new LinkedList<String>();
    }

    public RepositoryAltera(String tipo, String nome){
        this.tipo = tipo;
        this.nome = nome;
        this.atributo = new LinkedList<String>();
        this.ids = new LinkedList<String>();
    }

    public RepositoryAltera(String tipo, String nome, List<String> atributo, List<String> ids){
        this.tipo = tipo;
        this.nome = nome;
        this.atributo = atributo;
        this.ids = ids;
    }
}