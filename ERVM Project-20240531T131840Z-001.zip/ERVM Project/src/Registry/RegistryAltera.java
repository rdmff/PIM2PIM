/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Registry;

import Repository.RepositoryAltera;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Roberto de Medeiros
 */
public class RegistryAltera{
    private List<RepositoryAltera> xmi;

    /*
     * Elementos tradicionais
     */
    public RepositoryAltera get(int index){
        return this.xmi.get(index);
    }

    public void set(int index, RepositoryAltera elem){
        this.xmi.set(index,elem);
    }

    public void add(RepositoryAltera elem){
        this.xmi.add(elem);
    }

    public String searchConnection(String conn){
        RepositoryAltera rep;
        //id1 = -1;
        //int id2 = -1;
        for(int i = 0; i < xmi.size(); i++){
            rep = xmi.get(i);
            for(int j = 0; j < rep.getSizeId(); j++){
                if(rep.getId(j).equals(conn)&&(!rep.getTipo().equals("Connection"))){
                    //if(id1 != -1)
                        //id1 = i;
                        return rep.getNome();
                    //else
                    //    id2 = i;
                }
            }
        }
        return "";//+"."+xmi.get(id2).getNome();
    }

    /*
     *
     */
    public RepositoryAltera searchRepositoryByConnection(String conn){
        for(int i = 0; i < xmi.size(); i++){
            for(int j = 0; j < xmi.get(i).getSizeId(); j++)
                if(xmi.get(i).getId(j).equals(conn)&&
                (!xmi.get(i).getTipo().equals("Connection")))
                {
                        return xmi.get(i);
                }
        }
        return null;
    }

    public String searchConnectionType(String conn){
        for(int j = 0; j < xmi.size(); j++){
            if((xmi.get(j).getId(0).equals(conn)||
                    xmi.get(j).getId(1).equals(conn))&&
                    (!xmi.get(j).getTipo().equals("Connection"))){
                //if(id1 != -1)
                    //id1 = i;
                    return xmi.get(j).getTipo();
                //else
                //    id2 = i;
            }
        }
        return "";//+"."+xmi.get(id2).getNome();
    }

    public int size(){
        return xmi.size();
    }
    /*
     * Trata os projetos
     */
    private void makeProject(String linha){
        //
        //String aux[];
        //aux = linha;
        //aux = linha.split("\n");
        //xmi.add(new repXMI(aux[0].split(":")[1], aux[1]));
        //xmi.add(new repXMI("<<HwResource>>", "beta"));
        xmi.add(new RepositoryAltera("<<HwResource>>",linha.split(":")[1]));
    }

    /*
     * Trata os elementos
     */
    private void makeElement(String linha){
        //
        String aux[], aux1[];
        //
        String tipo, nome;
        String aux2;
        List<String> atributos = new LinkedList<String>();
        List<String> ids = new LinkedList<String>();
        //elemento
        aux = linha.split("@");
        //tipo e nome
        aux1 = aux[0].split("\n");
        tipo = aux1[0];
        nome = aux1[1];
        //
        aux = aux[1].split(";");
        for(int i = 0; i < aux.length; i++){
            if(aux[i].contains("Id:")){
                ids.add(aux[i].substring(3));//antes era 1
            } else{
                atributos.add(aux[i]);
            }
        }
        //
        xmi.add(new RepositoryAltera(tipo, nome, atributos, ids));
    }

    /*
     * Versão alfa 1
     */
    private void makeConnections(String linha){
        //
        String aux[], auxTipo;
        aux = linha.split(":");
        auxTipo = aux[0];
        aux = aux[1].split("=");
        //
        RepositoryAltera repositorio = new RepositoryAltera();
        //
        repositorio.setTipo("Connection");
        //teste versão alfa 2, ids oks...
        //
        //System.out.println("1: " + aux[0]);
        //System.out.println("1: " + aux[1]);
        //
        //erro corrigido na versão alfa 2
        //
        repositorio.addId(aux[0]);
        repositorio.addId(aux[1]);
        repositorio.setTipo(auxTipo);
        //
        xmi.add(repositorio);
    }

    public void trataLista(List<String> lista){
        makeProject(lista.get(0));
        for(int i = 1; i < lista.size(); i++){
            if(!lista.get(i).contains("Connection")){
                makeElement(lista.get(i));
            } else{
                makeConnections(lista.get(i));//
            }
        }
        //
    }

    public RegistryAltera(List<String> lista){
        xmi = new LinkedList<RepositoryAltera>();
        trataLista(lista);
    }
}
