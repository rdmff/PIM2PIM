/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Registry;

import Repository.RepositoryXilinx;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Roberto de Medeiros
 */
public class RegistryXilinx{
    private List<RepositoryXilinx> repository;

    /*
     * Elementos tradicionais
     */
    public RepositoryXilinx get(int index){
        return this.repository.get(index);
    }

    public void set(int index, RepositoryXilinx elem){
        this.repository.set(index,elem);
    }

    public void add(RepositoryXilinx elem){
        this.repository.add(elem);
    }

    public String searchConnection(String conn){
        RepositoryXilinx rep;
        //id1 = -1;
        //int id2 = -1;
        for(int i = 0; i < repository.size(); i++){
            rep = repository.get(i);
            for(int j = 0; j < rep.getSizeId(); j++){
                if(rep.getId(j).equals(conn)&&(!rep.getTipo().equals("Connection"))){
                    //if(id1 != -1)
                        //id1 = i;
                        return rep.getNome();
                    //else
                    //    id2 = i;
                }
            }
        }
        return "";//+"."+repository.get(id2).getNome();
    }

    /*
     *
     */
    public RepositoryXilinx searchRepositoryByConnection(String conn){
        for(int i = 0; i < repository.size(); i++){
            for(int j = 0; j < repository.get(i).getSizeId(); j++)
                if(repository.get(i).getId(j).equals(conn)&&
                (!repository.get(i).getTipo().equals("Connection")))
                {
                        return repository.get(i);
                }
        }
        return null;
    }

    public String searchConnectionType(String conn){
        for(int j = 0; j < repository.size(); j++){
            if((repository.get(j).getId(0).equals(conn)||
                    repository.get(j).getId(1).equals(conn))&&
                    (!repository.get(j).getTipo().equals("Connection"))){
                //if(id1 != -1)
                    //id1 = i;
                    return repository.get(j).getTipo();
                //else
                //    id2 = i;
            }
        }
        return "";//+"."+repository.get(id2).getNome();
    }

    public int size(){
        return repository.size();
    }
    /*
     * Trata os projetos
     */
    private void makeProject(String linha){
        //
        //String aux[];
        //aux = linha;
        //aux = linha.split("\n");
        //repository.add(new reprepository(aux[0].split(":")[1], aux[1]));
        //repository.add(new reprepository("<<HwResource>>", "beta"));
        repository.add(new RepositoryXilinx("<<HwResource>>",linha.split(":")[1]));
    }

    /*
     * Trata os elementos
     */
    private void makeElement(String linha){
        //
        String aux[], aux1[];
        //
        String tipo, nome;
        String aux2;
        List<String> atributos = new LinkedList<String>();
        List<String> ids = new LinkedList<String>();
        //elemento
        aux = linha.split("@");
        //tipo e nome
        aux1 = aux[0].split("\n");
        tipo = aux1[0];
        nome = aux1[1];
        //
        aux = aux[1].split(";");
        for(int i = 0; i < aux.length; i++){
            if(aux[i].contains("Id:")){
                ids.add(aux[i].substring(3));//antes era 1
            } else{
                atributos.add(aux[i]);
            }
        }
        //
        repository.add(new RepositoryXilinx(tipo, nome, atributos, ids));
    }

    /*
     * Versão alfa 1
     */
    private void makeConnections(String linha){
        //
        String aux[], auxTipo;
        aux = linha.split(":");
        auxTipo = aux[0];
        aux = aux[1].split("=");
        //
        RepositoryXilinx repositorio = new RepositoryXilinx();
        //
        repositorio.setTipo("Connection");
        //teste versão alfa 2, ids oks...
        //
        //System.out.println("1: " + aux[0]);
        //System.out.println("1: " + aux[1]);
        //
        //erro corrigido na versão alfa 2
        //
        repositorio.addId(aux[0]);
        repositorio.addId(aux[1]);
        repositorio.setTipo(auxTipo);
        //
        repository.add(repositorio);
    }

    public void trataLista(List<String> lista){
        makeProject(lista.get(0));
        for(int i = 1; i < lista.size(); i++){
            if(!lista.get(i).contains("Connection")){
                makeElement(lista.get(i));
            } else{
                makeConnections(lista.get(i));//
            }
        }
        //
    }

    public RegistryXilinx(List<String> lista){
        repository = new LinkedList<RepositoryXilinx>();
        trataLista(lista);
    }
}
