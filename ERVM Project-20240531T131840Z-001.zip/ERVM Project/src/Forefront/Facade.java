/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Forefront;

import Registry.RegistryAltera;
import Basic.Hex;
import Basic.Property;
import Basic.ReadXMI;
import DataBase.DatabaseAltera;
import DataBase.DatabaseXilinx;
import Registry.RegistryXilinx;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Roberto de Medeiros
 */
public class Facade {
    public static void facade(String pathXMI, String fullPath, String nomeProjeto, char tipo, String device) throws Exception{
        ReadXMI readXMI = new ReadXMI();
        DatabaseAltera sopc;
        DatabaseXilinx xps;
        List<String> lista;
        RegistryAltera xmiAltera;
        RegistryXilinx xmiXilinx;
        List<Property> propertiesXMP;
        //
        lista = readXMI.load(pathXMI);
        
        //Letra é igual ao tipo ('x' = Xilinx e 'a' [else] = Altera
        if(tipo == 'x'){//xilinx
            xmiXilinx = new RegistryXilinx(lista);            
            
            propertiesXMP = new LinkedList<Property>();
            propertiesXMP.add(new Property("XmpVersion", "13.4"));
            propertiesXMP.add(new Property("VerMgmt", "13.4"));
            propertiesXMP.add(new Property("IntStyle", "default"));
            propertiesXMP.add(new Property("Flow", "ise"));
            propertiesXMP.add(new Property("MHS File", "system.mhs"));
            propertiesXMP.add(new Property("Architecture", "spartan3e"));
            propertiesXMP.add(new Property("Device", "xc3s500e"));
            propertiesXMP.add(new Property("Package", "fg320"));
            propertiesXMP.add(new Property("SpeedGrade", "-4"));
            propertiesXMP.add(new Property("UserCmd1", ""));
            propertiesXMP.add(new Property("UserCmd1Type", "0"));
            propertiesXMP.add(new Property("UserCmd2", ""));
            propertiesXMP.add(new Property("UserCmd2Type", "0"));
            propertiesXMP.add(new Property("GenSimTB", "0"));
            propertiesXMP.add(new Property("SdkExportBmmBit", "1"));
            propertiesXMP.add(new Property("SdkExportDir", "SDK/SDK_Export"));
            propertiesXMP.add(new Property("InsertNoPads", "0"));
            propertiesXMP.add(new Property("WarnForEAArch", "1"));
            propertiesXMP.add(new Property("HdlLang", "VHDL"));
            propertiesXMP.add(new Property("SimModel", "BEHAVIORAL"));
            propertiesXMP.add(new Property("ExternalMemSim", "0"));
            propertiesXMP.add(new Property("UcfFile", "data/system.ucf"));
            propertiesXMP.add(new Property("EnableParTimingError", "1"));
            propertiesXMP.add(new Property("ShowLicenseDialog", "1"));
            propertiesXMP.add(new Property("ICacheAddr", "DDR_SDRAM"));//pegar isso
            propertiesXMP.add(new Property("Processor", "cpu"));//pegar isso
            propertiesXMP.add(new Property("ElfImp", ""));
            propertiesXMP.add(new Property("ElfSim", ""));
            //
            xps = new DatabaseXilinx();
            //
            xps.writeXMP(fullPath+".xmp", propertiesXMP);
            xps.writeMHS(fullPath+".mhs", xmiXilinx, nomeProjeto);
            //sopc.writeSOPC(fullPath, xmi, nomeProjeto);
            //DatabaseAltera.replaceErrorsXML(fullPath);
        } else{//altera
            xmiAltera = new RegistryAltera(lista);
            sopc = new DatabaseAltera();
            sopc.writeSOPC(fullPath+".sopc", xmiAltera, nomeProjeto, device);
            DatabaseAltera.replaceMinnorGreaterThanXML(fullPath+".sopc");
        }
        //
    }
}