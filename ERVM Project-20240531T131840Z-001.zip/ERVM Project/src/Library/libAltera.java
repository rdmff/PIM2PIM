/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Library;

import Basic.Property;
import Basic.Property;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import sun.io.Converters;

/**
 *
 * @author Roberto de Medeiros
 */
public class libAltera {
    /*
     * clock_source
     */
    public List<Property> clk_source(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("clockFrequency", "50000000"));
        properties.add(new Property("clockFrequencyKnown", "true"));
        properties.add(new Property("inputClockFrequency", "0"));
        //
        return properties;
    }

    public List<Property> bus_zero(){
        List<Property> properties = new LinkedList<Property>();
        //
        return properties;
    }

    /*
     * clock_source com list de propertie-value
     */
    public List<Property> clk_source(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        Property aux;
        //
        properties.add(new Property("clockFrequency", "50000000"));
        properties.add(new Property("clockFrequencyKnown", "true"));
        properties.add(new Property("inputClockFrequency", "0"));
        properties.add(new Property("resetSynchronousEdges", "NONE"));
        //
        for(int i = 0; i < values.size(); i++){
            System.out.println(values.get(i).getValue());
            if(values.get(i).getName().contains("frequency")){//transformo em Hz
                if(values.get(i).getValue().contains("KHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("KHz", ""))*1000));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("MHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("MHz", ""))*1000000));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("GHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("GHz", ""))*1000000000));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("rpm")){
                    aux = new Property("clockFrequency", String.valueOf(Double.parseDouble(values.get(i).getValue().replace("rpm", ""))*0.0166666666667));
                    values.set(i, aux);
                }
            }
            //
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_onchip_memory2
     */
    public List<Property> onchip_memory(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("allowInSystemMemoryContentEditor", "false"));
        properties.add(new Property("blockType", "AUTO"));
        //
        properties.add(new Property("dataWidth", "32"));
        properties.add(new Property("deviceFamily", "Cyclone II"));
        properties.add(new Property("dualPort", "false"));
        properties.add(new Property("initMemContent", "true"));
        properties.add(new Property("initializationFileName", "onchip_mem"));
        properties.add(new Property("instanceID", "NONE"));
        properties.add(new Property("memorySize", "16384"));
        properties.add(new Property("readDuringWriteMode", "DONT_CARE"));
        properties.add(new Property("simAllowMRAMContentsFile", "false"));
        properties.add(new Property("slave1Latency", "1"));
        properties.add(new Property("slave2Latency", "1"));
        properties.add(new Property("useNonDefaultInitFile", "false"));
        properties.add(new Property("useShallowMemBlocks", "false"));
        properties.add(new Property("writable", "true"));
        //
        return properties;
    }

    /*
     * altera_avalon_onchip_memory
     */
    public List<Property> onchip_memory(List<Property> values, String nomeRAM){
        List<Property> properties = new LinkedList<Property>();
        Property aux;
        //
        properties.add(new Property("allowInSystemMemoryContentEditor", "false"));
        properties.add(new Property("blockType", "AUTO"));
        //
        properties.add(new Property("dataWidth", "32"));
        properties.add(new Property("deviceFamily", "Cyclone II"));//
        properties.add(new Property("dualPort", "false"));
        properties.add(new Property("initMemContent", "true"));
        properties.add(new Property("initializationFileName", nomeRAM));
        properties.add(new Property("instanceID", "NONE"));
        properties.add(new Property("memorySize", "4096"));
        properties.add(new Property("readDuringWriteMode", "DONT_CARE"));
        properties.add(new Property("simAllowMRAMContentsFile", "false"));
        properties.add(new Property("slave2Latency", "1"));
        properties.add(new Property("slave1Latency", "1"));
        properties.add(new Property("useNonDefaultInitFile", "false"));
        properties.add(new Property("useShallowMemBlocks", "false"));
        properties.add(new Property("writable", "true"));
        //
        for(int i = 0; i < values.size(); i++){
            //
            //
            //
            if(values.get(i).getName().contains("sectorSize")){//transformo p bytes
                if(values.get(i).getValue().contains("KB")){
                    aux = new Property("memorySize", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("KB", ""))*1024));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("MB")){
                    aux = new Property("memorySize", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("MB", ""))*1048576));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("GB")){
                    aux = new Property("memorySize", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("GB", ""))*1073741824));
                    values.set(i, aux);
                }
            }
            //
            //
            //
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_green_led(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Output"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "9"));
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_green_led(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Output"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "9"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_red_led(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Output"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "18"));
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_red_led(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Output"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "18"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_switch(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Input"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "18"));
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_switch(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Input"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "18"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_button(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Input"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "true"));
        properties.add(new Property("irqType", "EDGE"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "4"));
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio_button(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Input"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "true"));
        properties.add(new Property("irqType", "EDGE"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "4"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_new_sdram_controller
     */
    public List<Property> SDRAM(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("TAC", "5.5"));
        properties.add(new Property("TMRD", "3"));
        properties.add(new Property("TRCD", "20.0"));
        properties.add(new Property("TRFC", "70.0"));
        properties.add(new Property("TRP", "20.0"));
        properties.add(new Property("TWR", "14.0"));
        properties.add(new Property("casLatency", "3"));
        properties.add(new Property("clockRate", "100000000"));
        properties.add(new Property("columnWidth", "9"));
        properties.add(new Property("dataWidth", "16"));
        properties.add(new Property("generateSimulationModel", "true"));
        properties.add(new Property("initNOPDelay", "0.0"));
        properties.add(new Property("initRefreshCommands", "2"));
        properties.add(new Property("masteredTristateBridgeSlave", ""));
        properties.add(new Property("model", "custom"));
        properties.add(new Property("numberOfBanks", "4"));
        properties.add(new Property("numberOfChipSelects", "1"));
        properties.add(new Property("pinsSharedViaTriState", "false"));
        properties.add(new Property("powerUpDelay", "200.0"));
        properties.add(new Property("refreshPeriod", "7.8125"));
        properties.add(new Property("registerDataIn", "true"));
        properties.add(new Property("rowWidth", "13"));
        //
        return properties;
    }

    /*
     * altera_avalon_new_sdram_controller
     */
    public List<Property> SDRAM(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("TAC", "5.5"));
        properties.add(new Property("TMRD", "3"));
        properties.add(new Property("TRCD", "20.0"));
        properties.add(new Property("TRFC", "70.0"));
        properties.add(new Property("TRP", "20.0"));
        properties.add(new Property("TWR", "14.0"));
        properties.add(new Property("casLatency", "3"));
        properties.add(new Property("clockRate", "100000000"));
        properties.add(new Property("columnWidth", "9"));
        properties.add(new Property("dataWidth", "16"));
        properties.add(new Property("generateSimulationModel", "true"));
        properties.add(new Property("initNOPDelay", "0.0"));
        properties.add(new Property("initRefreshCommands", "2"));
        properties.add(new Property("masteredTristateBridgeSlave", ""));
        properties.add(new Property("model", "custom"));
        properties.add(new Property("numberOfBanks", "4"));
        properties.add(new Property("numberOfChipSelects", "1"));
        properties.add(new Property("pinsSharedViaTriState", "false"));
        properties.add(new Property("powerUpDelay", "200.0"));
        properties.add(new Property("refreshPeriod", "7.8125"));
        properties.add(new Property("registerDataIn", "true"));
        properties.add(new Property("rowWidth", "13"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_cy7c1380_ssram
     */
    public List<Property> SSRAM(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("readLatency", "2"));
        properties.add(new Property("sharedPorts", ""));
        properties.add(new Property("simMakeModel", "true"));
        properties.add(new Property("size", "2"));
        //
        return properties;
    }

    /*
     * altera_avalon_cy7c1380_ssram
     */
    public List<Property> SSRAM(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("readLatency", "2"));
        properties.add(new Property("sharedPorts", ""));
        properties.add(new Property("simMakeModel", "true"));
        properties.add(new Property("size", "2"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_tri_state_bridge
     */
    public List<Property> tri_stage_bridge(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("registerIncomingSignals", "true"));
        //
        return properties;
    }

    /*
     * altera_avalon_tri_state_bridge
     */
    public List<Property> tri_stage_bridge(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("registerIncomingSignals", "true"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_cfi_flash
     */
    public List<Property> cfi_flash(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("addressWidth", "22"));
        properties.add(new Property("clockRate", "100000000"));
        properties.add(new Property("corePreset", "CUSTOM"));
        properties.add(new Property("dataWidth", "16"));
        properties.add(new Property("holdTime", "0"));
        properties.add(new Property("setupTime", "0"));
        properties.add(new Property("sharedPorts", ""));
        properties.add(new Property("timingUnits", "NS"));
        properties.add(new Property("waitTime", "100"));
        //
        return properties;
    }

    /*
     * altera_avalon_cfi_flash
     */
    public List<Property> cfi_flash(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("addressWidth", "22"));
        properties.add(new Property("clockRate", "100000000"));
        properties.add(new Property("corePreset", "CUSTOM"));
        properties.add(new Property("dataWidth", "16"));
        properties.add(new Property("holdTime", "0"));
        properties.add(new Property("setupTime", "0"));
        properties.add(new Property("sharedPorts", ""));
        properties.add(new Property("timingUnits", "NS"));
        properties.add(new Property("waitTime", "100"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_timer
     */
    public List<Property> timer(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("alwaysRun", "false"));
        properties.add(new Property("counterSize", "32"));
        properties.add(new Property("fixedPeriod", "false"));
        properties.add(new Property("period", "1.0"));
        properties.add(new Property("periodUnits", "MSEC"));
        properties.add(new Property("resetOutput", "false"));
        properties.add(new Property("snapshot", "true"));
        properties.add(new Property("systemFrequency", "100000000"));
        properties.add(new Property("timeoutPulseOutput", "false"));
        properties.add(new Property("timerPreset", "CUSTOM"));
        //
        return properties;
    }
    
    /*
     * altera_avalon_timer
     */
    public List<Property> timer(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("alwaysRun", "false"));
        properties.add(new Property("counterSize", "32"));
        properties.add(new Property("fixedPeriod", "false"));
        properties.add(new Property("period", "1.0"));
        properties.add(new Property("periodUnits", "MSEC"));
        properties.add(new Property("resetOutput", "false"));
        properties.add(new Property("snapshot", "true"));
        properties.add(new Property("systemFrequency", "100000000"));
        properties.add(new Property("timeoutPulseOutput", "false"));
        properties.add(new Property("timerPreset", "CUSTOM"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_timer
     */
    public List<Property> timer_stamp(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("alwaysRun", "false"));
        properties.add(new Property("counterSize", "32"));
        properties.add(new Property("fixedPeriod", "false"));
        properties.add(new Property("period", "1.0"));
        properties.add(new Property("periodUnits", "MSEC"));
        properties.add(new Property("resetOutput", "false"));
        properties.add(new Property("snapshot", "true"));
        properties.add(new Property("systemFrequency", "100000000"));
        properties.add(new Property("timeoutPulseOutput", "false"));
        properties.add(new Property("timerPreset", "CUSTOM"));
        //
        return properties;
    }

    /*
     * altera_avalon_timer
     */
    public List<Property> timer_stamp(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("alwaysRun", "false"));
        properties.add(new Property("counterSize", "32"));
        properties.add(new Property("fixedPeriod", "false"));
        properties.add(new Property("period", "1.0"));
        properties.add(new Property("periodUnits", "MSEC"));
        properties.add(new Property("resetOutput", "false"));
        properties.add(new Property("snapshot", "true"));
        properties.add(new Property("systemFrequency", "100000000"));
        properties.add(new Property("timeoutPulseOutput", "false"));
        properties.add(new Property("timerPreset", "CUSTOM"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_jtag_uart
     */
    public List<Property> jtag_uart(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("allowMultipleConnections", "false"));
        properties.add(new Property("hubInstanceID", "0"));
        properties.add(new Property("readBufferDepth", "64"));
        properties.add(new Property("readIRQThreshold", "8"));
        properties.add(new Property("simInputCharacterStream", ""));
        properties.add(new Property("simInteractiveOptions", "", "INTERACTIVE_ASCII_OUTPUT"));
        properties.add(new Property("useRegistersForReadBuffer", "false"));
        properties.add(new Property("useRegistersForWriteBuffer", "false"));
        properties.add(new Property("useRelativePathForSimFile", "false"));
        properties.add(new Property("writeBufferDepth", "64"));
        properties.add(new Property("writeIRQThreshold", "8"));
        //
        return properties;
    }

    /*
     * altera_avalon_jtag_uart
     */
    public List<Property> jtag_uart(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("allowMultipleConnections", "false"));
        properties.add(new Property("hubInstanceID", "0"));
        properties.add(new Property("readBufferDepth", "64"));
        properties.add(new Property("readIRQThreshold", "8"));
        properties.add(new Property("simInputCharacterStream", ""));
        properties.add(new Property("simInteractiveOptions", "", "INTERACTIVE_ASCII_OUTPUT"));
        properties.add(new Property("useRegistersForReadBuffer", "false"));
        properties.add(new Property("useRegistersForWriteBuffer", "false"));
        properties.add(new Property("useRelativePathForSimFile", "false"));
        properties.add(new Property("writeBufferDepth", "64"));
        properties.add(new Property("writeIRQThreshold", "8"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_uart
     */
    public List<Property> uart(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("baud", "115200"));
        properties.add(new Property("clockRate", "100000000"));
        properties.add(new Property("dataBits", "8"));
        properties.add(new Property("fixedBaud", "true"));
        properties.add(new Property("parity", "NONE"));
        properties.add(new Property("simCharStream", ""));
        properties.add(new Property("simInteractiveInputEnable", "false"));
        properties.add(new Property("simInteractiveOutputEnable", "false"));
        properties.add(new Property("simTrueBaud", "false"));
        properties.add(new Property("stopBits", "1"));
        properties.add(new Property("syncRegDepth", "2"));
        properties.add(new Property("useCtsRts", "true"));
        properties.add(new Property("useEopRegister", "false"));
        properties.add(new Property("useRelativePathForSimFile", "false"));
        //
        return properties;
    }

    /*
     * altera_avalon_uart
     */
    public List<Property> uart(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("baud", "115200"));
        properties.add(new Property("clockRate", "100000000"));
        properties.add(new Property("dataBits", "8"));
        properties.add(new Property("fixedBaud", "true"));
        properties.add(new Property("parity", "NONE"));
        properties.add(new Property("simCharStream", ""));
        properties.add(new Property("simInteractiveInputEnable", "false"));
        properties.add(new Property("simInteractiveOutputEnable", "false"));
        properties.add(new Property("simTrueBaud", "false"));
        properties.add(new Property("stopBits", "1"));
        properties.add(new Property("syncRegDepth", "2"));
        properties.add(new Property("useCtsRts", "true"));
        properties.add(new Property("useEopRegister", "false"));
        properties.add(new Property("useRelativePathForSimFile", "false"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * ISP1362_IF
     */
    public List<Property> isp1362(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("AUTO_HC_CLOCK_CLOCK_RATE", "100000000"));
        properties.add(new Property("AUTO_DC_CLOCK_CLOCK_RATE", "100000000"));
        //
        return properties;
    }

    /*
     * ISP1362_IF
     */
    public List<Property> isp1362(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("AUTO_HC_CLOCK_CLOCK_RATE", "100000000"));
        properties.add(new Property("AUTO_DC_CLOCK_CLOCK_RATE", "100000000"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Output"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "1"));
        //
        return properties;
    }

    /*
     * altera_avalon_pio
     */
    public List<Property> pio(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("bitClearingEdgeCapReg", "false"));
        properties.add(new Property("bitModifyingOutReg", "false"));
        properties.add(new Property("captureEdge", "false"));
        properties.add(new Property("captureEdge", "100000000"));
        properties.add(new Property("direction", "Output"));
        properties.add(new Property("edgeType", "RISING"));
        properties.add(new Property("generateIRQ", "false"));
        properties.add(new Property("irqType", "LEVEL"));
        properties.add(new Property("resetValue", "0"));
        properties.add(new Property("simDoTestBenchWiring", "false"));
        properties.add(new Property("simDrivenValue", "0"));
        properties.add(new Property("width", "1"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * clock_source
     */
    public List<Property> clk(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("clockFrequency", "25000000"));
        properties.add(new Property("clockFrequencyKnown", "true"));
        properties.add(new Property("inputClockFrequency", "0"));
        //
        return properties;
    }

    /*
     * clock_source
     */
    public List<Property> clk(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        Property aux;
        //
        properties.add(new Property("clockFrequency", "25000000"));
        properties.add(new Property("clockFrequencyKnown", "true"));
        properties.add(new Property("inputClockFrequency", "0"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        for(int i = 0; i < values.size(); i++){//atributos
            if(values.get(i).getName().contains("frequency")){//transformo em Hz
                if(values.get(i).getName().contains("KHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("KHz", ""))*1000));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("MHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("MHz", ""))*1000000));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("GHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("GHz", ""))*1000000000));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("rpm")){
                    aux = new Property("clockFrequency", String.valueOf(Double.parseDouble(values.get(i).getValue().replace("rpm", ""))*0.0166666666667));
                    values.set(i, aux);
                }
            }
            //
            //
            //
            for(int j = 0; j < properties.size(); j++){//propriedades finais
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * SEG7_IF
     */
    public List<Property> seg7_if(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("ADDR_WIDTH", "3"));
        properties.add(new Property("DEFAULT_ACTIVE", "1"));
        properties.add(new Property("SEG7_NUM", "8"));
        properties.add(new Property("LOW_ACTIVE", "1"));
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        return properties;
    }

    /*
     * SEG7_IF
     */
    public List<Property> seg7_if(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("ADDR_WIDTH", "3"));
        properties.add(new Property("DEFAULT_ACTIVE", "1"));
        properties.add(new Property("SEG7_NUM", "8"));
        properties.add(new Property("LOW_ACTIVE", "1"));
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * AUDIO_IF
     */
    public List<Property> audio(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        return properties;
    }

    /*
     * AUDIO_IF
     */
    public List<Property> audio(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * VGA_NIOS_CTRL
     */
    public List<Property> vga(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("RAM_SIZE", "307200"));
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        return properties;
    }

    /*
     * VGA_NIOS_CTRL
     */
    public List<Property> vga(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("RAM_SIZE", "307200"));
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * DM9000A_IF
     */
    public List<Property> dm9000a(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "25000000"));
        //
        return properties;
    }

    /*
     * DM9000A_IF
     */
    public List<Property> dm9000a(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "25000000"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }


    /*
     * VGA_NIOS_CTRL
     */
    public List<Property> vga_nios_ctrl(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("RAM_SIZE", "307200"));
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        return properties;
    }

    /*
     * VGA_NIOS_CTRL
     */
    public List<Property> vga_nios_ctrl(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("RAM_SIZE", "307200"));
        properties.add(new Property("AUTO_S1_CLOCK_CLOCK_RATE", "100000000"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altpll
     */
    public List<Property> altpll(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("HIDDEN_CUSTOM_ELABORATION", "", "altpll_avalon_elaboration"));
        properties.add(new Property("HIDDEN_CUSTOM_POST_EDIT", "", "altpll_avalon_post_edit"));
        properties.add(new Property("INTENDED_DEVICE_FAMILY", "Cyclone II"));
        properties.add(new Property("WIDTH_CLOCK", ""));
        properties.add(new Property("WIDTH_PHASECOUNTERSELECT", ""));
        properties.add(new Property("PRIMARY_CLOCK", ""));
        properties.add(new Property("INCLK0_INPUT_FREQUENCY", "20000"));
        properties.add(new Property("INCLK1_INPUT_FREQUENCY", ""));
        properties.add(new Property("OPERATION_MODE", "NORMAL"));
        properties.add(new Property("PLL_TYPE", ""));
        properties.add(new Property("QUALIFY_CONF_DONE", ""));
        properties.add(new Property("COMPENSATE_CLOCK", "CLK0"));
        properties.add(new Property("SCAN_CHAIN", ""));
        properties.add(new Property("GATE_LOCK_SIGNAL", ""));
        properties.add(new Property("GATE_LOCK_COUNTER", ""));
        properties.add(new Property("LOCK_HIGH", ""));
        properties.add(new Property("LOCK_LOW", ""));
        properties.add(new Property("VALID_LOCK_MULTIPLIER", ""));
        properties.add(new Property("INVALID_LOCK_MULTIPLIER", ""));
        properties.add(new Property("SWITCH_OVER_ON_LOSSCLK", ""));
        properties.add(new Property("SWITCH_OVER_ON_GATED_LOCK", ""));
        properties.add(new Property("ENABLE_SWITCH_OVER_COUNTER", ""));
        properties.add(new Property("SKIP_VCO", ""));
        properties.add(new Property("SWITCH_OVER_COUNTER", ""));
        properties.add(new Property("SWITCH_OVER_TYPE", ""));
        properties.add(new Property("FEEDBACK_SOURCE", ""));
        properties.add(new Property("BANDWIDTH", ""));
        properties.add(new Property("BANDWIDTH_TYPE", ""));
        properties.add(new Property("SPREAD_FREQUENCY", ""));
        properties.add(new Property("DOWN_SPREAD", ""));
        properties.add(new Property("SELF_RESET_ON_GATED_LOSS_LOCK", ""));
        properties.add(new Property("SELF_RESET_ON_LOSS_LOCK", ""));
        properties.add(new Property("CLK0_MULTIPLY_BY", "2"));
        properties.add(new Property("CLK1_MULTIPLY_BY", ""));
        properties.add(new Property("CLK2_MULTIPLY_BY", ""));
        properties.add(new Property("CLK3_MULTIPLY_BY", ""));
        properties.add(new Property("CLK4_MULTIPLY_BY", ""));
        properties.add(new Property("CLK5_MULTIPLY_BY", ""));
        properties.add(new Property("CLK6_MULTIPLY_BY", ""));
        properties.add(new Property("CLK7_MULTIPLY_BY", ""));
        properties.add(new Property("CLK8_MULTIPLY_BY", ""));
        properties.add(new Property("CLK9_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK0_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK1_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK2_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK3_MULTIPLY_BY", ""));
        properties.add(new Property("CLK0_DIVIDE_BY", "1"));
        properties.add(new Property("CLK1_DIVIDE_BY", ""));
        properties.add(new Property("CLK2_DIVIDE_BY", ""));
        properties.add(new Property("CLK3_DIVIDE_BY", ""));
        properties.add(new Property("CLK4_DIVIDE_BY", ""));
        properties.add(new Property("CLK5_DIVIDE_BY", ""));
        properties.add(new Property("CLK6_DIVIDE_BY", ""));
        properties.add(new Property("CLK7_DIVIDE_BY", ""));
        properties.add(new Property("CLK8_DIVIDE_BY", ""));
        properties.add(new Property("CLK9_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK0_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK1_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK2_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK3_DIVIDE_BY", ""));
        properties.add(new Property("CLK0_PHASE_SHIFT", "0"));
        properties.add(new Property("CLK1_PHASE_SHIFT", ""));
        properties.add(new Property("CLK2_PHASE_SHIFT", ""));
        properties.add(new Property("CLK3_PHASE_SHIFT", ""));
        properties.add(new Property("CLK4_PHASE_SHIFT", ""));
        properties.add(new Property("CLK5_PHASE_SHIFT", ""));
        properties.add(new Property("CLK6_PHASE_SHIFT", ""));
        properties.add(new Property("CLK7_PHASE_SHIFT", ""));
        properties.add(new Property("CLK8_PHASE_SHIFT", ""));
        properties.add(new Property("CLK9_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK0_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK1_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK2_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK3_PHASE_SHIFT", ""));
        properties.add(new Property("CLK0_DUTY_CYCLE", "50"));
        properties.add(new Property("CLK1_DUTY_CYCLE", ""));
        properties.add(new Property("CLK2_DUTY_CYCLE", ""));
        properties.add(new Property("CLK3_DUTY_CYCLE", ""));
        properties.add(new Property("CLK4_DUTY_CYCLE", ""));
        properties.add(new Property("CLK5_DUTY_CYCLE", ""));
        properties.add(new Property("CLK6_DUTY_CYCLE", ""));
        properties.add(new Property("CLK7_DUTY_CYCLE", ""));
        properties.add(new Property("CLK8_DUTY_CYCLE", ""));
        properties.add(new Property("CLK9_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK0_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK1_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK2_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK3_DUTY_CYCLE", ""));
        properties.add(new Property("PORT_clkena0", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena1", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena2", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena3", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena4", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena5", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclkena0", ""));
        properties.add(new Property("PORT_extclkena1", ""));
        properties.add(new Property("PORT_extclkena2", ""));
        properties.add(new Property("PORT_extclkena3", ""));
        properties.add(new Property("PORT_extclk0", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclk1", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclk2", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclk3", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKBAD0", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKBAD1", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk0", "PORT_USED"));
        properties.add(new Property("PORT_clk1", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk2", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk3", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk4", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk5", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk6", ""));
        properties.add(new Property("PORT_clk7", ""));
        properties.add(new Property("PORT_clk8", ""));
        properties.add(new Property("PORT_clk9", ""));
        properties.add(new Property("PORT_SCANDATA", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANDATAOUT", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANDONE", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCLKOUT1", ""));
        properties.add(new Property("PORT_SCLKOUT0", ""));
        properties.add(new Property("PORT_ACTIVECLOCK", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKLOSS", "PORT_UNUSED"));
        properties.add(new Property("PORT_INCLK1", "PORT_UNUSED"));
        properties.add(new Property("PORT_INCLK0", "PORT_UNUSED"));
        properties.add(new Property("PORT_FBIN", "PORT_UNUSED"));
        properties.add(new Property("PORT_PLLENA", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKSWITCH", "PORT_UNUSED"));
        properties.add(new Property("PORT_ARESET", "PORT_UNUSED"));
        properties.add(new Property("PORT_PFDENA", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANCLK", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANACLR", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANREAD", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANWRITE", "PORT_UNUSED"));
        properties.add(new Property("PORT_ENABLE0", ""));
        properties.add(new Property("PORT_ENABLE1", ""));
        properties.add(new Property("PORT_LOCKED", "PORT_UNUSED"));
        properties.add(new Property("PORT_CONFIGUPDATE", "PORT_UNUSED"));
        properties.add(new Property("PORT_FBOUT", ""));
        properties.add(new Property("PORT_PHASEDONE", "PORT_UNUSED"));
        properties.add(new Property("PORT_PHASESTEP", "PORT_UNUSED"));
        properties.add(new Property("PORT_PHASEUPDOWN", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANCLKENA", "PORT_UNUSED"));
        properties.add(new Property("PORT_PHASECOUNTERSELECT", "PORT_UNUSED"));
        properties.add(new Property("PORT_VCOOVERRANGE", ""));
        properties.add(new Property("PORT_VCOUNDERRANGE", ""));
        properties.add(new Property("DPA_MULTIPLY_BY", ""));
        properties.add(new Property("DPA_DIVIDE_BY", ""));
        properties.add(new Property("DPA_DIVIDER", ""));
        properties.add(new Property("VCO_MULTIPLY_BY", ""));
        properties.add(new Property("VCO_DIVIDE_BY", ""));
        properties.add(new Property("SCLKOUT0_PHASE_SHIFT", ""));
        properties.add(new Property("SCLKOUT1_PHASE_SHIFT", ""));
        properties.add(new Property("VCO_FREQUENCY_CONTROL", ""));
        properties.add(new Property("VCO_PHASE_SHIFT_STEP", ""));
        properties.add(new Property("USING_FBMIMICBIDIR_PORT", ""));
        properties.add(new Property("SCAN_CHAIN_MIF_FILE", ""));
        properties.add(new Property("AVALON_USE_SEPARATE_SYSCLK", "NO"));
        properties.add(new Property("HIDDEN_CONSTANTS", "", "CT#PORT_clk5 PORT_UNUSED CT#PORT_clk4 PORT_UNUSED CT#PORT_clk3 PORT_UNUSED CT#PORT_clk2 PORT_UNUSED CT#PORT_clk1 PORT_UNUSED CT#PORT_clk0 PORT_USED CT#CLK0_MULTIPLY_BY 2 CT#PORT_SCANWRITE PORT_UNUSED CT#PORT_SCANACLR PORT_UNUSED CT#PORT_PFDENA PORT_UNUSED CT#PORT_PLLENA PORT_UNUSED CT#PORT_SCANDATA PORT_UNUSED CT#PORT_SCANCLKENA PORT_UNUSED CT#PORT_SCANDATAOUT PORT_UNUSED CT#LPM_TYPE altpll CT#CLK0_PHASE_SHIFT 0 CT#PORT_PHASEDONE PORT_UNUSED CT#OPERATION_MODE NORMAL CT#PORT_CONFIGUPDATE PORT_UNUSED CT#COMPENSATE_CLOCK CLK0 CT#PORT_CLKSWITCH PORT_UNUSED CT#INCLK0_INPUT_FREQUENCY 20000 CT#PORT_SCANDONE PORT_UNUSED CT#PORT_CLKLOSS PORT_UNUSED CT#PORT_INCLK1 PORT_UNUSED CT#AVALON_USE_SEPARATE_SYSCLK NO CT#PORT_INCLK0 PORT_USED CT#PORT_clkena5 PORT_UNUSED CT#PORT_clkena4 PORT_UNUSED CT#PORT_clkena3 PORT_UNUSED CT#PORT_clkena2 PORT_UNUSED CT#PORT_clkena1 PORT_UNUSED CT#PORT_clkena0 PORT_UNUSED CT#PORT_ARESET PORT_UNUSED CT#INTENDED_DEVICE_FAMILY {Cyclone II} CT#PORT_SCANREAD PORT_UNUSED CT#PORT_PHASESTEP PORT_UNUSED CT#PORT_SCANCLK PORT_UNUSED CT#PORT_CLKBAD1 PORT_UNUSED CT#PORT_CLKBAD0 PORT_UNUSED CT#PORT_FBIN PORT_UNUSED CT#PORT_PHASEUPDOWN PORT_UNUSED CT#PORT_extclk3 PORT_UNUSED CT#PORT_extclk2 PORT_UNUSED CT#PORT_extclk1 PORT_UNUSED CT#PORT_PHASECOUNTERSELECT PORT_UNUSED CT#PORT_extclk0 PORT_UNUSED CT#PORT_ACTIVECLOCK PORT_UNUSED CT#CLK0_DUTY_CYCLE 50 CT#CLK0_DIVIDE_BY 1 CT#PORT_LOCKED PORT_UNUSED"));
        properties.add(new Property("HIDDEN_PRIVATES", "", "PT#GLOCKED_FEATURE_ENABLED 1 PT#SPREAD_FEATURE_ENABLED 0 PT#BANDWIDTH_FREQ_UNIT MHz PT#CUR_DEDICATED_CLK c0 PT#INCLK0_FREQ_EDIT 50.000 PT#BANDWIDTH_PRESET Low PT#PLL_LVDS_PLL_CHECK 0 PT#BANDWIDTH_USE_PRESET 0 PT#AVALON_USE_SEPARATE_SYSCLK NO PT#PLL_ENHPLL_CHECK 0 PT#OUTPUT_FREQ_UNIT0 MHz PT#PHASE_RECONFIG_FEATURE_ENABLED 0 PT#CREATE_CLKBAD_CHECK 0 PT#CLKSWITCH_CHECK 1 PT#INCLK1_FREQ_EDIT 100.000 PT#NORMAL_MODE_RADIO 1 PT#SRC_SYNCH_COMP_RADIO 0 PT#PLL_ARESET_CHECK 0 PT#LONG_SCAN_RADIO 1 PT#SCAN_FEATURE_ENABLED 0 PT#PHASE_RECONFIG_INPUTS_CHECK 0 PT#USE_CLK0 1 PT#PRIMARY_CLK_COMBO inclk0 PT#BANDWIDTH 1.000 PT#GLOCKED_COUNTER_EDIT_CHANGED 1 PT#PLL_ENA_CHECK 0 PT#PLL_FASTPLL_CHECK 0 PT#SPREAD_FREQ_UNIT KHz PT#PLL_AUTOPLL_CHECK 1 PT#LVDS_PHASE_SHIFT_UNIT0 deg PT#SWITCHOVER_FEATURE_ENABLED 0 PT#MIG_DEVICE_SPEED_GRADE Any PT#OUTPUT_FREQ_MODE0 1 PT#BANDWIDTH_FEATURE_ENABLED 0 PT#INCLK0_FREQ_UNIT_COMBO MHz PT#ZERO_DELAY_RADIO 0 PT#OUTPUT_FREQ0 100.00000000 PT#SHORT_SCAN_RADIO 0 PT#LVDS_MODE_DATA_RATE_DIRTY 0 PT#CUR_FBIN_CLK c0 PT#PLL_ADVANCED_PARAM_CHECK 0 PT#CLKBAD_SWITCHOVER_CHECK 0 PT#PHASE_SHIFT_STEP_ENABLED_CHECK 0 PT#DEVICE_SPEED_GRADE Any PT#PLL_FBMIMIC_CHECK 0 PT#LVDS_MODE_DATA_RATE {Not Available} PT#LOCKED_OUTPUT_CHECK 0 PT#SPREAD_PERCENT 0.500 PT#PHASE_SHIFT0 0.00000000 PT#DIV_FACTOR0 1 PT#CNX_NO_COMPENSATE_RADIO 0 PT#USE_CLKENA0 0 PT#CREATE_INCLK1_CHECK 0 PT#GLOCK_COUNTER_EDIT 1048575 PT#BANDWIDTH_USE_CUSTOM 0 PT#INCLK1_FREQ_UNIT_COMBO MHz PT#EFF_OUTPUT_FREQ_VALUE0 100.000000 PT#SPREAD_FREQ 50.000 PT#USE_MIL_SPEED_GRADE 0 PT#EXPLICIT_SWITCHOVER_COUNTER 0 PT#STICKY_CLK0 1 PT#EXT_FEEDBACK_RADIO 0 PT#MIRROR_CLK0 0 PT#SWITCHOVER_COUNT_EDIT 1 PT#SELF_RESET_LOCK_LOSS 0 PT#PLL_PFDENA_CHECK 0 PT#INT_FEEDBACK__MODE_RADIO 1 PT#INCLK1_FREQ_EDIT_CHANGED 1 PT#CLKLOSS_CHECK 0 PT#SYNTH_WRAPPER_GEN_POSTFIX 0 PT#PHASE_SHIFT_UNIT0 deg PT#BANDWIDTH_USE_AUTO 1 PT#HAS_MANUAL_SWITCHOVER 1 PT#MULT_FACTOR0 1 PT#SPREAD_USE 0 PT#GLOCKED_MODE_CHECK 0 PT#SACN_INPUTS_CHECK 0 PT#DUTY_CYCLE0 50.00000000 PT#INTENDED_DEVICE_FAMILY {Cyclone II} PT#PLL_TARGET_HARCOPY_CHECK 0 PT#INCLK1_FREQ_UNIT_CHANGED 1 PT#RECONFIG_FILE ALTPLL1311306200659976.mif PT#ACTIVECLK_CHECK 0"));
        properties.add(new Property("HIDDEN_USED_PORTS", "", "UP#c0 used UP#inclk0 used"));
        properties.add(new Property("HIDDEN_IS_NUMERIC", "", "IN#CLK0_DUTY_CYCLE 1 IN#PLL_TARGET_HARCOPY_CHECK 1 IN#SWITCHOVER_COUNT_EDIT 1 IN#INCLK0_INPUT_FREQUENCY 1 IN#PLL_LVDS_PLL_CHECK 1 IN#PLL_AUTOPLL_CHECK 1 IN#PLL_FASTPLL_CHECK 1 IN#PLL_ENHPLL_CHECK 1 IN#DIV_FACTOR0 1 IN#LVDS_MODE_DATA_RATE_DIRTY 1 IN#GLOCK_COUNTER_EDIT 1 IN#CLK0_DIVIDE_BY 1 IN#MULT_FACTOR0 1 IN#CLK0_MULTIPLY_BY 1 IN#USE_MIL_SPEED_GRADE 1"));
        properties.add(new Property("HIDDEN_MF_PORTS", "MF#clk 1 MF#inclk 1"));
        properties.add(new Property("HIDDEN_IF_PORTS", "", "IF#locked {output 0} IF#reset {input 0} IF#clk {input 0} IF#readdata {output 32} IF#write {input 0} IF#phasedone {output 0} IF#address {input 2} IF#c0 {output 0} IF#writedata {input 32} IF#read {input 0}"));
        properties.add(new Property("HIDDEN_IS_FIRST_EDIT", "0"));
        properties.add(new Property("AUTO_INCLK_INTERFACE_CLOCK_RATE", "50000000"));
        properties.add(new Property("AUTO_DEVICE_FAMILY", "Cyclone II"));
        //
        return properties;
    }

    /*
     * altpll
     */
    public List<Property> altpll(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("HIDDEN_CUSTOM_ELABORATION", "", "altpll_avalon_elaboration"));
        properties.add(new Property("HIDDEN_CUSTOM_POST_EDIT", "", "altpll_avalon_post_edit"));
        properties.add(new Property("INTENDED_DEVICE_FAMILY", "Cyclone II"));
        properties.add(new Property("WIDTH_CLOCK", ""));
        properties.add(new Property("WIDTH_PHASECOUNTERSELECT", ""));
        properties.add(new Property("PRIMARY_CLOCK", ""));
        properties.add(new Property("INCLK0_INPUT_FREQUENCY", "20000"));
        properties.add(new Property("INCLK1_INPUT_FREQUENCY", ""));
        properties.add(new Property("OPERATION_MODE", "NORMAL"));
        properties.add(new Property("PLL_TYPE", ""));
        properties.add(new Property("QUALIFY_CONF_DONE", ""));
        properties.add(new Property("COMPENSATE_CLOCK", "CLK0"));
        properties.add(new Property("SCAN_CHAIN", ""));
        properties.add(new Property("GATE_LOCK_SIGNAL", "NO"));
        properties.add(new Property("GATE_LOCK_COUNTER", ""));
        properties.add(new Property("LOCK_HIGH", ""));
        properties.add(new Property("LOCK_LOW", ""));
        properties.add(new Property("VALID_LOCK_MULTIPLIER", "1"));
        properties.add(new Property("INVALID_LOCK_MULTIPLIER", "5"));
        properties.add(new Property("SWITCH_OVER_ON_LOSSCLK", ""));
        properties.add(new Property("SWITCH_OVER_ON_GATED_LOCK", ""));
        properties.add(new Property("ENABLE_SWITCH_OVER_COUNTER", ""));
        properties.add(new Property("SKIP_VCO", ""));
        properties.add(new Property("SWITCH_OVER_COUNTER", ""));
        properties.add(new Property("SWITCH_OVER_TYPE", ""));
        properties.add(new Property("FEEDBACK_SOURCE", ""));
        properties.add(new Property("BANDWIDTH", ""));
        properties.add(new Property("BANDWIDTH_TYPE", ""));
        properties.add(new Property("SPREAD_FREQUENCY", ""));
        properties.add(new Property("DOWN_SPREAD", ""));
        properties.add(new Property("SELF_RESET_ON_GATED_LOSS_LOCK", ""));
        properties.add(new Property("SELF_RESET_ON_LOSS_LOCK", ""));
        properties.add(new Property("CLK0_MULTIPLY_BY", "1"));
        properties.add(new Property("CLK1_MULTIPLY_BY", ""));
        properties.add(new Property("CLK2_MULTIPLY_BY", ""));
        properties.add(new Property("CLK3_MULTIPLY_BY", ""));
        properties.add(new Property("CLK4_MULTIPLY_BY", ""));
        properties.add(new Property("CLK5_MULTIPLY_BY", ""));
        properties.add(new Property("CLK6_MULTIPLY_BY", ""));
        properties.add(new Property("CLK7_MULTIPLY_BY", ""));
        properties.add(new Property("CLK8_MULTIPLY_BY", ""));
        properties.add(new Property("CLK9_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK0_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK1_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK2_MULTIPLY_BY", ""));
        properties.add(new Property("EXTCLK3_MULTIPLY_BY", ""));
        properties.add(new Property("CLK0_DIVIDE_BY", "1"));
        properties.add(new Property("CLK1_DIVIDE_BY", ""));
        properties.add(new Property("CLK2_DIVIDE_BY", ""));
        properties.add(new Property("CLK3_DIVIDE_BY", ""));
        properties.add(new Property("CLK4_DIVIDE_BY", ""));
        properties.add(new Property("CLK5_DIVIDE_BY", ""));
        properties.add(new Property("CLK6_DIVIDE_BY", ""));
        properties.add(new Property("CLK7_DIVIDE_BY", ""));
        properties.add(new Property("CLK8_DIVIDE_BY", ""));
        properties.add(new Property("CLK9_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK0_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK1_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK2_DIVIDE_BY", ""));
        properties.add(new Property("EXTCLK3_DIVIDE_BY", ""));
        properties.add(new Property("CLK0_PHASE_SHIFT", "0"));
        properties.add(new Property("CLK1_PHASE_SHIFT", ""));
        properties.add(new Property("CLK2_PHASE_SHIFT", ""));
        properties.add(new Property("CLK3_PHASE_SHIFT", ""));
        properties.add(new Property("CLK4_PHASE_SHIFT", ""));
        properties.add(new Property("CLK5_PHASE_SHIFT", ""));
        properties.add(new Property("CLK6_PHASE_SHIFT", ""));
        properties.add(new Property("CLK7_PHASE_SHIFT", ""));
        properties.add(new Property("CLK8_PHASE_SHIFT", ""));
        properties.add(new Property("CLK9_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK0_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK1_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK2_PHASE_SHIFT", ""));
        properties.add(new Property("EXTCLK3_PHASE_SHIFT", ""));
        properties.add(new Property("CLK0_DUTY_CYCLE", "50"));
        properties.add(new Property("CLK1_DUTY_CYCLE", ""));
        properties.add(new Property("CLK2_DUTY_CYCLE", ""));
        properties.add(new Property("CLK3_DUTY_CYCLE", ""));
        properties.add(new Property("CLK4_DUTY_CYCLE", ""));
        properties.add(new Property("CLK5_DUTY_CYCLE", ""));
        properties.add(new Property("CLK6_DUTY_CYCLE", ""));
        properties.add(new Property("CLK7_DUTY_CYCLE", ""));
        properties.add(new Property("CLK8_DUTY_CYCLE", ""));
        properties.add(new Property("CLK9_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK0_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK1_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK2_DUTY_CYCLE", ""));
        properties.add(new Property("EXTCLK3_DUTY_CYCLE", ""));
        properties.add(new Property("PORT_clkena0", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena1", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena2", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena3", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena4", "PORT_UNUSED"));
        properties.add(new Property("PORT_clkena5", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclkena0", ""));
        properties.add(new Property("PORT_extclkena1", ""));
        properties.add(new Property("PORT_extclkena2", ""));
        properties.add(new Property("PORT_extclkena3", ""));
        properties.add(new Property("PORT_extclk0", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclk1", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclk2", "PORT_UNUSED"));
        properties.add(new Property("PORT_extclk3", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKBAD0", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKBAD1", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk0", "PORT_USED"));
        properties.add(new Property("PORT_clk1", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk2", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk3", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk4", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk5", "PORT_UNUSED"));
        properties.add(new Property("PORT_clk6", ""));
        properties.add(new Property("PORT_clk7", ""));
        properties.add(new Property("PORT_clk8", ""));
        properties.add(new Property("PORT_clk9", ""));
        properties.add(new Property("PORT_SCANDATA", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANDATAOUT", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANDONE", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCLKOUT1", ""));
        properties.add(new Property("PORT_SCLKOUT0", ""));
        properties.add(new Property("PORT_ACTIVECLOCK", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKLOSS", "PORT_UNUSED"));
        properties.add(new Property("PORT_INCLK1", "PORT_UNUSED"));
        properties.add(new Property("PORT_INCLK0", "PORT_UNUSED"));
        properties.add(new Property("PORT_FBIN", "PORT_UNUSED"));
        properties.add(new Property("PORT_PLLENA", "PORT_UNUSED"));
        properties.add(new Property("PORT_CLKSWITCH", "PORT_UNUSED"));
        properties.add(new Property("PORT_ARESET", "PORT_UNUSED"));
        properties.add(new Property("PORT_PFDENA", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANCLK", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANACLR", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANREAD", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANWRITE", "PORT_UNUSED"));
        properties.add(new Property("PORT_ENABLE0", ""));
        properties.add(new Property("PORT_ENABLE1", ""));
        properties.add(new Property("PORT_LOCKED", "PORT_UNUSED"));
        properties.add(new Property("PORT_CONFIGUPDATE", "PORT_UNUSED"));
        properties.add(new Property("PORT_FBOUT", ""));
        properties.add(new Property("PORT_PHASEDONE", "PORT_UNUSED"));
        properties.add(new Property("PORT_PHASESTEP", "PORT_UNUSED"));
        properties.add(new Property("PORT_PHASEUPDOWN", "PORT_UNUSED"));
        properties.add(new Property("PORT_SCANCLKENA", "PORT_UNUSED"));
        properties.add(new Property("PORT_PHASECOUNTERSELECT", "PORT_UNUSED"));
        properties.add(new Property("PORT_VCOOVERRANGE", ""));
        properties.add(new Property("PORT_VCOUNDERRANGE", ""));
        properties.add(new Property("DPA_MULTIPLY_BY", ""));
        properties.add(new Property("DPA_DIVIDE_BY", ""));
        properties.add(new Property("DPA_DIVIDER", ""));
        properties.add(new Property("VCO_MULTIPLY_BY", ""));
        properties.add(new Property("VCO_DIVIDE_BY", ""));
        properties.add(new Property("SCLKOUT0_PHASE_SHIFT", ""));
        properties.add(new Property("SCLKOUT1_PHASE_SHIFT", ""));
        properties.add(new Property("VCO_FREQUENCY_CONTROL", ""));
        properties.add(new Property("VCO_PHASE_SHIFT_STEP", ""));
        properties.add(new Property("USING_FBMIMICBIDIR_PORT", ""));
        properties.add(new Property("SCAN_CHAIN_MIF_FILE", ""));
        properties.add(new Property("AVALON_USE_SEPARATE_SYSCLK", "NO"));
        properties.add(new Property("HIDDEN_CONSTANTS", "", "CT#PORT_clk5 PORT_UNUSED CT#PORT_clk4 PORT_UNUSED CT#PORT_clk3 PORT_UNUSED CT#PORT_clk2 PORT_UNUSED CT#PORT_clk1 PORT_UNUSED CT#PORT_clk0 PORT_USED CT#VALID_LOCK_MULTIPLIER 1 CT#CLK0_MULTIPLY_BY 1 CT#PORT_SCANWRITE PORT_UNUSED CT#PORT_SCANACLR PORT_UNUSED CT#PORT_PFDENA PORT_UNUSED CT#PORT_PLLENA PORT_UNUSED CT#PORT_SCANDATA PORT_UNUSED CT#PORT_SCANCLKENA PORT_UNUSED CT#PORT_SCANDATAOUT PORT_UNUSED CT#LPM_TYPE altpll CT#CLK0_PHASE_SHIFT 0 CT#PORT_PHASEDONE PORT_UNUSED CT#OPERATION_MODE NORMAL CT#PORT_CONFIGUPDATE PORT_UNUSED CT#COMPENSATE_CLOCK CLK0 CT#PORT_CLKSWITCH PORT_UNUSED CT#INCLK0_INPUT_FREQUENCY 20000 CT#PORT_SCANDONE PORT_UNUSED CT#PORT_CLKLOSS PORT_UNUSED CT#PORT_INCLK1 PORT_UNUSED CT#AVALON_USE_SEPARATE_SYSCLK NO CT#PORT_INCLK0 PORT_USED CT#PORT_clkena5 PORT_UNUSED CT#PORT_clkena4 PORT_UNUSED CT#PORT_clkena3 PORT_UNUSED CT#PORT_clkena2 PORT_UNUSED CT#PORT_clkena1 PORT_UNUSED CT#PORT_clkena0 PORT_UNUSED CT#PORT_ARESET PORT_USED CT#INVALID_LOCK_MULTIPLIER 5 CT#INTENDED_DEVICE_FAMILY {Cyclone II} CT#PORT_SCANREAD PORT_UNUSED CT#PORT_PHASESTEP PORT_UNUSED CT#PORT_SCANCLK PORT_UNUSED CT#PORT_CLKBAD1 PORT_UNUSED CT#PORT_CLKBAD0 PORT_UNUSED CT#PORT_FBIN PORT_UNUSED CT#PORT_PHASEUPDOWN PORT_UNUSED CT#PORT_extclk3 PORT_UNUSED CT#PORT_extclk2 PORT_UNUSED CT#PORT_extclk1 PORT_UNUSED CT#PORT_PHASECOUNTERSELECT PORT_UNUSED CT#PORT_extclk0 PORT_UNUSED CT#PORT_ACTIVECLOCK PORT_UNUSED CT#CLK0_DUTY_CYCLE 50 CT#CLK0_DIVIDE_BY 1 CT#GATE_LOCK_SIGNAL NO CT#PORT_LOCKED PORT_USED"));
        properties.add(new Property("HIDDEN_PRIVATES", "", "PT#GLOCKED_FEATURE_ENABLED 1 PT#SPREAD_FEATURE_ENABLED 0 PT#BANDWIDTH_FREQ_UNIT MHz PT#CUR_DEDICATED_CLK c0 PT#INCLK0_FREQ_EDIT 50.000 PT#BANDWIDTH_PRESET Low PT#PLL_LVDS_PLL_CHECK 0 PT#BANDWIDTH_USE_PRESET 0 PT#AVALON_USE_SEPARATE_SYSCLK NO PT#PLL_ENHPLL_CHECK 0 PT#OUTPUT_FREQ_UNIT0 MHz PT#PHASE_RECONFIG_FEATURE_ENABLED 0 PT#CREATE_CLKBAD_CHECK 0 PT#CLKSWITCH_CHECK 1 PT#INCLK1_FREQ_EDIT 100.000 PT#NORMAL_MODE_RADIO 1 PT#SRC_SYNCH_COMP_RADIO 0 PT#PLL_ARESET_CHECK 1 PT#LONG_SCAN_RADIO 1 PT#SCAN_FEATURE_ENABLED 0 PT#PHASE_RECONFIG_INPUTS_CHECK 0 PT#USE_CLK0 1 PT#PRIMARY_CLK_COMBO inclk0 PT#BANDWIDTH 1.000 PT#GLOCKED_COUNTER_EDIT_CHANGED 1 PT#PLL_ENA_CHECK 0 PT#PLL_FASTPLL_CHECK 0 PT#SPREAD_FREQ_UNIT KHz PT#PLL_AUTOPLL_CHECK 1 PT#LVDS_PHASE_SHIFT_UNIT0 deg PT#SWITCHOVER_FEATURE_ENABLED 0 PT#MIG_DEVICE_SPEED_GRADE Any PT#OUTPUT_FREQ_MODE0 0 PT#BANDWIDTH_FEATURE_ENABLED 0 PT#INCLK0_FREQ_UNIT_COMBO MHz PT#ZERO_DELAY_RADIO 0 PT#OUTPUT_FREQ0 100.00000000 PT#SHORT_SCAN_RADIO 0 PT#LVDS_MODE_DATA_RATE_DIRTY 0 PT#CUR_FBIN_CLK c0 PT#PLL_ADVANCED_PARAM_CHECK 0 PT#CLKBAD_SWITCHOVER_CHECK 0 PT#PHASE_SHIFT_STEP_ENABLED_CHECK 0 PT#DEVICE_SPEED_GRADE Any PT#PLL_FBMIMIC_CHECK 0 PT#LVDS_MODE_DATA_RATE {Not Available} PT#LOCKED_OUTPUT_CHECK 1 PT#SPREAD_PERCENT 0.500 PT#PHASE_SHIFT0 0.00000000 PT#DIV_FACTOR0 1 PT#CNX_NO_COMPENSATE_RADIO 0 PT#USE_CLKENA0 0 PT#CREATE_INCLK1_CHECK 0 PT#GLOCK_COUNTER_EDIT 1048575 PT#BANDWIDTH_USE_CUSTOM 0 PT#INCLK1_FREQ_UNIT_COMBO MHz PT#EFF_OUTPUT_FREQ_VALUE0 50.000000 PT#SPREAD_FREQ 50.000 PT#USE_MIL_SPEED_GRADE 0 PT#EXPLICIT_SWITCHOVER_COUNTER 0 PT#STICKY_CLK0 1 PT#EXT_FEEDBACK_RADIO 0 PT#MIRROR_CLK0 0 PT#SWITCHOVER_COUNT_EDIT 1 PT#SELF_RESET_LOCK_LOSS 0 PT#PLL_PFDENA_CHECK 0 PT#INT_FEEDBACK__MODE_RADIO 1 PT#INCLK1_FREQ_EDIT_CHANGED 1 PT#CLKLOSS_CHECK 0 PT#SYNTH_WRAPPER_GEN_POSTFIX 0 PT#PHASE_SHIFT_UNIT0 deg PT#BANDWIDTH_USE_AUTO 1 PT#HAS_MANUAL_SWITCHOVER 1 PT#MULT_FACTOR0 1 PT#SPREAD_USE 0 PT#GLOCKED_MODE_CHECK 0 PT#SACN_INPUTS_CHECK 0 PT#DUTY_CYCLE0 50.00000000 PT#INTENDED_DEVICE_FAMILY {Cyclone II} PT#PLL_TARGET_HARCOPY_CHECK 0 PT#INCLK1_FREQ_UNIT_CHANGED 1 PT#RECONFIG_FILE ALTPLL1341601308996280.mif PT#ACTIVECLK_CHECK 0"));
        properties.add(new Property("HIDDEN_USED_PORTS", "", "UP#locked used UP#c0 used UP#areset used UP#inclk0 used"));
        properties.add(new Property("HIDDEN_IS_NUMERIC", "", "IN#CLK0_DUTY_CYCLE 1 IN#PLL_TARGET_HARCOPY_CHECK 1 IN#SWITCHOVER_COUNT_EDIT 1 IN#INCLK0_INPUT_FREQUENCY 1 IN#PLL_LVDS_PLL_CHECK 1 IN#PLL_AUTOPLL_CHECK 1 IN#PLL_FASTPLL_CHECK 1 IN#VALID_LOCK_MULTIPLIER 1 IN#PLL_ENHPLL_CHECK 1 IN#DIV_FACTOR0 1 IN#INVALID_LOCK_MULTIPLIER 1 IN#LVDS_MODE_DATA_RATE_DIRTY 1 IN#GLOCK_COUNTER_EDIT 1 IN#CLK0_DIVIDE_BY 1 IN#MULT_FACTOR0 1 IN#CLK0_MULTIPLY_BY 1 IN#USE_MIL_SPEED_GRADE 1"));
        properties.add(new Property("HIDDEN_MF_PORTS", "MF#areset 1 MF#clk 1 MF#locked 1 MF#inclk 1"));
        properties.add(new Property("HIDDEN_IF_PORTS", "", "IF#locked {output 0} IF#reset {input 0} IF#clk {input 0} IF#readdata {output 32} IF#write {input 0} IF#phasedone {output 0} IF#address {input 2} IF#c0 {output 0} IF#writedata {input 32} IF#read {input 0}"));
        properties.add(new Property("HIDDEN_IS_FIRST_EDIT", "0"));
        properties.add(new Property("AUTO_INCLK_INTERFACE_CLOCK_RATE", "50000000"));
        properties.add(new Property("AUTO_DEVICE_FAMILY", "Cyclone II"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_nios2
     */
    public List<Property> cpu_nios2(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("userDefinedSettings", ""));
        properties.add(new Property("setting_showUnpublishedSettings", "false"));
        properties.add(new Property("setting_showInternalSettings", "false"));
        properties.add(new Property("setting_shadowRegisterSets", "0"));
        properties.add(new Property("setting_preciseSlaveAccessErrorException", "false"));
        properties.add(new Property("setting_preciseIllegalMemAccessException", "false"));
        properties.add(new Property("setting_preciseDivisionErrorException", "false"));
        properties.add(new Property("setting_performanceCounter", "false"));
        properties.add(new Property("setting_perfCounterWidth", "_32"));
        properties.add(new Property("setting_interruptControllerType", "Internal"));
        properties.add(new Property("setting_illegalMemAccessDetection", "false"));
        properties.add(new Property("setting_illegalInstructionsTrap", "false"));
        properties.add(new Property("setting_fullWaveformSignals", "false"));
        properties.add(new Property("setting_extraExceptionInfo", "false"));
        properties.add(new Property("setting_exportPCB", "false"));
        properties.add(new Property("setting_debugSimGen", "false"));
        properties.add(new Property("setting_clearXBitsLDNonBypass", "true"));
        properties.add(new Property("setting_branchPredictionType", "Automatic"));
        properties.add(new Property("setting_bit31BypassDCache", "true"));
        properties.add(new Property("setting_bigEndian", "false"));
        properties.add(new Property("setting_bhtPtrSz", "_8"));
        properties.add(new Property("setting_bhtIndexPcOnly", "false"));
        properties.add(new Property("setting_avalonDebugPortPresent", "false"));
        properties.add(new Property("setting_alwaysEncrypt", "true"));
        properties.add(new Property("setting_allowFullAddressRange", "false"));
        properties.add(new Property("setting_activateTrace", "true"));
        properties.add(new Property("setting_activateTestEndChecker", "false"));
        properties.add(new Property("setting_activateMonitors", "true"));
        properties.add(new Property("setting_activateModelChecker", "false"));
        properties.add(new Property("setting_HDLSimCachesCleared", "true"));
        properties.add(new Property("setting_HBreakTest", "false"));
        properties.add(new Property("resetSlave", "onchip_mem.s1"));
        properties.add(new Property("resetOffset", "0"));
        properties.add(new Property("muldiv_multiplierType", "EmbeddedMulFast"));
        properties.add(new Property("muldiv_divider", "false"));
        properties.add(new Property("mpu_useLimit", "false"));
        properties.add(new Property("mpu_numOfInstRegion", "8"));
        properties.add(new Property("mpu_numOfDataRegion", "8"));
        properties.add(new Property("mpu_minInstRegionSize", "_12"));
        properties.add(new Property("mpu_minDataRegionSize", "_12"));
        properties.add(new Property("mpu_enabled", "false"));
        properties.add(new Property("mmu_uitlbNumEntries", "_4"));
        properties.add(new Property("mmu_udtlbNumEntries", "_6"));
        properties.add(new Property("mmu_tlbPtrSz", "_7"));
        properties.add(new Property("mmu_tlbNumWays", "_16"));
        properties.add(new Property("mmu_processIDNumBits", "_8"));
        properties.add(new Property("mmu_enabled", "false"));
        properties.add(new Property("mmu_autoAssignTlbPtrSz", "true"));
        properties.add(new Property("mmu_TLBMissExcSlave", ""));
        properties.add(new Property("mmu_TLBMissExcOffset", "0"));
        properties.add(new Property("manuallyAssignCpuID", "false"));
        properties.add(new Property("internalIrqMaskSystemInfo", "1"));
        properties.add(new Property("instSlaveMapParam", "", "<![CDATA[<address-map><slave name='onchip_memory2_0.s1' start='0x8000' end='0x10000' /><slave name='cpu_0.jtag_debug_module' start='0x10800' end='0x11000' /></address-map>]]>"));
        properties.add(new Property("instAddrWidth", "17"));
        properties.add(new Property("impl", "Tiny"));
        properties.add(new Property("icache_size", "_4096"));
        properties.add(new Property("icache_ramBlockType", "Automatic"));
        properties.add(new Property("icache_numTCIM", "_0"));
        properties.add(new Property("icache_burstType", "None"));
        properties.add(new Property("exceptionSlave", "onchip_mem.s1"));
        properties.add(new Property("exceptionOffset", "32"));
        properties.add(new Property("deviceFeaturesSystemInfo", "", "M512_MEMORY 0 M4K_MEMORY 1 M9K_MEMORY 0 M20K_MEMORY 0 M144K_MEMORY 0 MRAM_MEMORY 0 MLAB_MEMORY 0 ESB 0 EPCS 1 DSP 0 EMUL 1 HARDCOPY 0 LVDS_IO 0 ADDRESS_STALL 1 TRANSCEIVER_3G_BLOCK 0 TRANSCEIVER_6G_BLOCK 0 DSP_SHIFTER_BLOCK 0"));
        properties.add(new Property("deviceFamilyName", "Cyclone II"));
        properties.add(new Property("debug_triggerArming", "true"));
        properties.add(new Property("debug_level", "Level1"));
        properties.add(new Property("debug_jtagInstanceID", "0"));
        properties.add(new Property("debug_embeddedPLL", "true"));
        properties.add(new Property("debug_debugReqSignals", "false"));
        properties.add(new Property("debug_assignJtagInstanceID", "false"));
        properties.add(new Property("debug_OCIOnchipTrace", "_128"));
        properties.add(new Property("dcache_size", "_2048"));
        properties.add(new Property("dcache_ramBlockType", "Automatic"));
        properties.add(new Property("dcache_omitDataMaster", "false"));
        properties.add(new Property("dcache_numTCDM", "_0"));
        properties.add(new Property("dcache_lineSize", "_32"));
        properties.add(new Property("dcache_bursts", "false"));
        properties.add(new Property("dataSlaveMapParam", "", "<![CDATA[<address-map><slave name='onchip_memory2_0.s1' start='0x8000' end='0x10000' /><slave name='cpu_0.jtag_debug_module' start='0x10800' end='0x11000' /><slave name='altpll_0.pll_slave' start='0x11000' end='0x11010' /><slave name='jtag_uart_0.avalon_jtag_slave' start='0x11010' end='0x11018' /></address-map>]]>"));
        properties.add(new Property("dataAddrWidth", "17"));
        properties.add(new Property("cpuReset", "false"));
        properties.add(new Property("cpuID", "0"));
        properties.add(new Property("clockFrequency", "100000000"));
        properties.add(new Property("breakSlave", "", "cpu_0.jtag_debug_module"));
        properties.add(new Property("breakOffset", "32"));
        //
        return properties;
    }

    /*
     * altera_nios2
     */
    public List<Property> cpu_nios2(List<Property> values, String nomeRAM,
            String nomeCPU, String nomeJTAG, String nomeALTPLL){
        List<Property> properties = new LinkedList<Property>();
        //int aux;
        Property aux;
        //
        properties.add(new Property("userDefinedSettings", ""));
        
        properties.add(new Property("tightlyCoupledInstructionMaster3MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster3AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledInstructionMaster2MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster2AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledInstructionMaster1MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster1AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledInstructionMaster0MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster0AddrWidth", "1"));
        
        properties.add(new Property("tightlyCoupledDataMaster3MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster3AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledDataMaster2MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster2AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledDataMaster1MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster1AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledDataMaster0MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster0AddrWidth", "1"));
        
        properties.add(new Property("setting_showUnpublishedSettings", "false"));
        properties.add(new Property("setting_showInternalSettings", "false"));
        properties.add(new Property("setting_shadowRegisterSets", "0"));
        properties.add(new Property("setting_preciseSlaveAccessErrorException", "false"));
        properties.add(new Property("setting_preciseIllegalMemAccessException", "false"));
        properties.add(new Property("setting_preciseDivisionErrorException", "false"));
        properties.add(new Property("setting_performanceCounter", "false"));
        properties.add(new Property("setting_perfCounterWidth", "_32"));
        properties.add(new Property("setting_interruptControllerType", "Internal"));
        properties.add(new Property("setting_illegalMemAccessDetection", "false"));
        properties.add(new Property("setting_illegalInstructionsTrap", "false"));
        properties.add(new Property("setting_fullWaveformSignals", "false"));
        properties.add(new Property("setting_extraExceptionInfo", "false"));
        properties.add(new Property("setting_exportPCB", "false"));
        properties.add(new Property("setting_debugSimGen", "false"));
        properties.add(new Property("setting_clearXBitsLDNonBypass", "true"));
        properties.add(new Property("setting_branchPredictionType", "Automatic"));
        properties.add(new Property("setting_bit31BypassDCache", "true"));
        properties.add(new Property("setting_bigEndian", "false"));
        properties.add(new Property("setting_bhtPtrSz", "_8"));
        properties.add(new Property("setting_bhtIndexPcOnly", "false"));
        properties.add(new Property("setting_avalonDebugPortPresent", "false"));
        properties.add(new Property("setting_alwaysEncrypt", "true"));
        properties.add(new Property("setting_allowFullAddressRange", "false"));
        properties.add(new Property("setting_activateTrace", "true"));
        properties.add(new Property("setting_activateTestEndChecker", "false"));
        properties.add(new Property("setting_activateMonitors", "true"));
        properties.add(new Property("setting_activateModelChecker", "false"));
        properties.add(new Property("setting_HDLSimCachesCleared", "true"));
        properties.add(new Property("setting_HBreakTest", "false"));
        properties.add(new Property("resetSlave", nomeRAM + ".s1"));//memory name
        properties.add(new Property("resetOffset", "0"));
        properties.add(new Property("muldiv_multiplierType", "EmbeddedMultFast"));
        properties.add(new Property("muldiv_divider", "false"));
        properties.add(new Property("mpu_useLimit", "false"));
        properties.add(new Property("mpu_numOfInstRegion", "8"));
        properties.add(new Property("mpu_numOfDataRegion", "8"));
        properties.add(new Property("mpu_minInstRegionSize", "_12"));
        properties.add(new Property("mpu_minDataRegionSize", "_12"));
        properties.add(new Property("mpu_enabled", "false"));
        properties.add(new Property("mmu_uitlbNumEntries", "_4"));
        properties.add(new Property("mmu_udtlbNumEntries", "_6"));
        properties.add(new Property("mmu_tlbPtrSz", "_7"));
        properties.add(new Property("mmu_tlbNumWays", "_16"));
        properties.add(new Property("mmu_processIDNumBits", "_8"));
        properties.add(new Property("mmu_enabled", "false"));
        properties.add(new Property("mmu_autoAssignTlbPtrSz", "true"));
        properties.add(new Property("mmu_TLBMissExcSlave", ""));
        properties.add(new Property("mmu_TLBMissExcOffset", "0"));
        properties.add(new Property("manuallyAssignCpuID", "false"));
        properties.add(new Property("internalIrqMaskSystemInfo", "1"));
        properties.add(new Property("instSlaveMapParam", "", "<![CDATA[<address-map>" + 
                "<slave name='" + nomeRAM + ".s1' start='0x3000' end='0x4000' />" + 
                "<slave name='" + nomeCPU + ".jtag_debug_module' start='0x1000' end='0x1800' />" +
                "</address-map>]]>"
                ));// memory name
        properties.add(new Property("instAddrWidth", "14"));
        properties.add(new Property("impl", "Tiny"));
        properties.add(new Property("icache_size", "_4096"));
        properties.add(new Property("icache_ramBlockType", "Automatic"));
        properties.add(new Property("icache_numTCIM", "_0"));
        properties.add(new Property("icache_burstType", "None"));
        properties.add(new Property("exceptionSlave", nomeRAM + ".s1"));
        properties.add(new Property("exceptionOffset", "32"));
        properties.add(new Property("deviceFeaturesSystemInfo", "", "M512_MEMORY 0 M4K_MEMORY 1 M9K_MEMORY 0 M20K_MEMORY 0 M144K_MEMORY 0 MRAM_MEMORY 0 MLAB_MEMORY 0 ESB 0 EPCS 1 DSP 0 EMUL 1 HARDCOPY 0 LVDS_IO 0 ADDRESS_STALL 1 TRANSCEIVER_3G_BLOCK 0 TRANSCEIVER_6G_BLOCK 0 DSP_SHIFTER_BLOCK 0"));
        properties.add(new Property("deviceFamilyName", "Cyclone"));
        properties.add(new Property("debug_triggerArming", "true"));
        properties.add(new Property("debug_level", "Level1"));
        properties.add(new Property("debug_jtagInstanceID", "0"));
        properties.add(new Property("debug_embeddedPLL", "true"));
        properties.add(new Property("debug_debugReqSignals", "false"));
        properties.add(new Property("debug_assignJtagInstanceID", "false"));
        properties.add(new Property("debug_OCIOnchipTrace", "_128"));
        properties.add(new Property("dcache_size", "_2048"));
        properties.add(new Property("dcache_ramBlockType", "Automatic"));
        properties.add(new Property("dcache_omitDataMaster", "false"));
        properties.add(new Property("dcache_numTCDM", "_0"));
        properties.add(new Property("dcache_lineSize", "_32"));
        properties.add(new Property("dcache_bursts", "false"));
        //properties.add(new Property("dataSlaveMapParam", "", "<![CDATA[]]>"));
        properties.add(new Property("dataSlaveMapParam", "", "<![CDATA[<address-map>" + 
                "<slave name='" + nomeRAM + ".s1' start='0x3000' end='0x4000' />" +
                "<slave name='" + nomeCPU + ".jtag_debug_module' start='0x1000' end='0x1800' />" +
                "<slave name='" + nomeJTAG + ".avalon_jtag_slave' start='0x0' end='0x8' />" +
                "<slave name='" + nomeALTPLL + ".pll_slave' start='0x0' end='0x8' />" +
                "</address-map>]]>"));//memory name
        properties.add(new Property("dataAddrWidth", "14"));
        
        properties.add(new Property("customInstSlavesSystemInfo", "<info/>"));
        
        properties.add(new Property("cpuReset", "false"));
        properties.add(new Property("cpuID", "0"));
        properties.add(new Property("clockFrequency", "50000000"));
        properties.add(new Property("breakSlave", "", "cpu_0.jtag_debug_module"));
        properties.add(new Property("breakOffset", "32"));
        //
        for(int i = 0; i < values.size(); i++){//atributos
            if(values.get(i).getName().contains("frequency")){//transformo em Hz
                if(values.get(i).getName().contains("KHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("KHz", ""))*1000));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("MHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("MHz", ""))*1000000));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("GHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("GHz", ""))*1000000000));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("rpm")){
                    aux = new Property("clockFrequency", String.valueOf(Double.parseDouble(values.get(i).getValue().replace("rpm", ""))*0.0166666666667));
                    values.set(i, aux);
                }
            }
            //
            //
            //
            if(values.get(i).getName().contains("Size")){//transformo p bytes
                if(values.get(i).getName().contains("KB")){
                    aux = new Property(values.get(i).getName(), String.valueOf(Integer.parseInt(values.get(i).getValue().replace("KB", ""))*1024));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("MB")){
                    aux = new Property(values.get(i).getName(), String.valueOf(Integer.parseInt(values.get(i).getValue().replace("MB", ""))*1048576));
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("GB")){
                    aux = new Property(values.get(i).getName(), String.valueOf(Integer.parseInt(values.get(i).getValue().replace("GB", ""))*1073741824));
                    values.set(i, aux);
                }
            }
            //
            //
            //
            if(values.get(i).getName().contains("nbStage")){//transformo p bytes
                if(values.get(i).getName().contains("3")){
                    aux = new Property("impl", "Tiny");
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("5")){
                    aux = new Property("impl", "Small");
                    values.set(i, aux);
                } else if(values.get(i).getValue().contains("6")){
                    aux = new Property("impl", "Fast");
                    values.set(i, aux);
                }
            }
            //
            //
            //
            for(int j = 0; j < properties.size(); j++){//propriedades finais
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }
    
    /*
     * construção
     */
    public List<Property> cpu_nios2_5pipeline(List<Property> values, String nomeRAM,
            String nomeCPU, String nomeJTAG){
        List<Property> properties = new LinkedList<Property>();
        //int aux;
        Property aux;
        //
        properties.add(new Property("userDefinedSettings", ""));
        
        properties.add(new Property("tightlyCoupledInstructionMaster3MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster3AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledInstructionMaster2MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster2AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledInstructionMaster1MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster1AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledInstructionMaster0MapParam", ""));
        properties.add(new Property("tightlyCoupledInstructionMaster0AddrWidth", "1"));
        
        properties.add(new Property("tightlyCoupledDataMaster3MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster3AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledDataMaster2MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster2AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledDataMaster1MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster1AddrWidth", "1"));
        properties.add(new Property("tightlyCoupledDataMaster0MapParam", ""));
        properties.add(new Property("tightlyCoupledDataMaster0AddrWidth", "1"));
        
        properties.add(new Property("setting_showUnpublishedSettings", "false"));
        properties.add(new Property("setting_showInternalSettings", "false"));
        properties.add(new Property("setting_shadowRegisterSets", "0"));
        properties.add(new Property("setting_preciseSlaveAccessErrorException", "false"));
        properties.add(new Property("setting_preciseIllegalMemAccessException", "false"));
        properties.add(new Property("setting_preciseDivisionErrorException", "false"));
        properties.add(new Property("setting_performanceCounter", "false"));
        properties.add(new Property("setting_perfCounterWidth", "_32"));
        properties.add(new Property("setting_interruptControllerType", "Internal"));
        properties.add(new Property("setting_illegalMemAccessDetection", "false"));
        properties.add(new Property("setting_illegalInstructionsTrap", "false"));
        properties.add(new Property("setting_fullWaveformSignals", "false"));
        properties.add(new Property("setting_extraExceptionInfo", "false"));
        properties.add(new Property("setting_exportPCB", "false"));
        properties.add(new Property("setting_debugSimGen", "false"));
        properties.add(new Property("setting_clearXBitsLDNonBypass", "true"));
        properties.add(new Property("setting_branchPredictionType", "Automatic"));
        properties.add(new Property("setting_bit31BypassDCache", "true"));
        properties.add(new Property("setting_bigEndian", "false"));
        properties.add(new Property("setting_bhtPtrSz", "_8"));
        properties.add(new Property("setting_bhtIndexPcOnly", "false"));
        properties.add(new Property("setting_avalonDebugPortPresent", "false"));
        properties.add(new Property("setting_alwaysEncrypt", "true"));
        properties.add(new Property("setting_allowFullAddressRange", "false"));
        properties.add(new Property("setting_activateTrace", "true"));
        properties.add(new Property("setting_activateTestEndChecker", "false"));
        properties.add(new Property("setting_activateMonitors", "true"));
        properties.add(new Property("setting_activateModelChecker", "false"));
        properties.add(new Property("setting_HDLSimCachesCleared", "true"));
        properties.add(new Property("setting_HBreakTest", "false"));
        properties.add(new Property("resetSlave", nomeRAM + ".s1"));//memory name
        properties.add(new Property("resetOffset", "0"));
        properties.add(new Property("muldiv_multiplierType", "NoneSmall"));
        properties.add(new Property("muldiv_divider", "false"));
        properties.add(new Property("mpu_useLimit", "false"));
        properties.add(new Property("mpu_numOfInstRegion", "8"));
        properties.add(new Property("mpu_numOfDataRegion", "8"));
        properties.add(new Property("mpu_minInstRegionSize", "_12"));
        properties.add(new Property("mpu_minDataRegionSize", "_12"));
        properties.add(new Property("mpu_enabled", "false"));
        properties.add(new Property("mmu_uitlbNumEntries", "_4"));
        properties.add(new Property("mmu_udtlbNumEntries", "_6"));
        properties.add(new Property("mmu_tlbPtrSz", "_7"));
        properties.add(new Property("mmu_tlbNumWays", "_16"));
        properties.add(new Property("mmu_processIDNumBits", "_8"));
        properties.add(new Property("mmu_enabled", "false"));
        properties.add(new Property("mmu_autoAssignTlbPtrSz", "true"));
        properties.add(new Property("mmu_TLBMissExcSlave", ""));
        properties.add(new Property("mmu_TLBMissExcOffset", "0"));
        properties.add(new Property("manuallyAssignCpuID", "false"));
        properties.add(new Property("internalIrqMaskSystemInfo", "1"));
        properties.add(new Property("instSlaveMapParam", "", "<![CDATA[<address-map><slave name='" + nomeRAM + ".s1' start='0x1000' end='0x2000' /><slave name='" + nomeCPU + ".jtag_debug_module' start='0x2800' end='0x3000' /></address-map>]]>"));// memory name
        properties.add(new Property("instAddrWidth", "13"));
        properties.add(new Property("impl", "Tiny"));
        properties.add(new Property("icache_size", "_4096"));
        properties.add(new Property("icache_ramBlockType", "Automatic"));
        properties.add(new Property("icache_numTCIM", "_0"));
        properties.add(new Property("icache_burstType", "None"));
        properties.add(new Property("exceptionSlave", nomeRAM + ".s1"));
        properties.add(new Property("exceptionOffset", "32"));
        properties.add(new Property("deviceFeaturesSystemInfo", "", "M512_MEMORY 0 M4K_MEMORY 1 M9K_MEMORY 0 M20K_MEMORY 0 M144K_MEMORY 0 MRAM_MEMORY 0 MLAB_MEMORY 0 ESB 0 EPCS 1 DSP 0 EMUL 0 HARDCOPY 0 LVDS_IO 0 ADDRESS_STALL 0 TRANSCEIVER_3G_BLOCK 0 TRANSCEIVER_6G_BLOCK 0 DSP_SHIFTER_BLOCK 0"));
        properties.add(new Property("deviceFamilyName", "Cyclone"));
        properties.add(new Property("debug_triggerArming", "true"));
        properties.add(new Property("debug_level", "Level1"));
        properties.add(new Property("debug_jtagInstanceID", "0"));
        properties.add(new Property("debug_embeddedPLL", "true"));
        properties.add(new Property("debug_debugReqSignals", "false"));
        properties.add(new Property("debug_assignJtagInstanceID", "false"));
        properties.add(new Property("debug_OCIOnchipTrace", "_128"));
        properties.add(new Property("dcache_size", "_2048"));
        properties.add(new Property("dcache_ramBlockType", "Automatic"));
        properties.add(new Property("dcache_omitDataMaster", "false"));
        properties.add(new Property("dcache_numTCDM", "_0"));
        properties.add(new Property("dcache_lineSize", "_32"));
        properties.add(new Property("dcache_bursts", "false"));
        //properties.add(new Property("dataSlaveMapParam", "", "<![CDATA[]]>"));
        properties.add(new Property("dataSlaveMapParam", "", "<![CDATA[<address-map><slave name='" + nomeRAM + ".s1' start='0x1000' end='0x2000' /><slave name='cpu_0.jtag_debug_module' start='0x2800' end='0x3000' /><slave name='" + nomeJTAG + ".avalon_jtag_slave' start='0x3000' end='0x3008' /></address-map>]]>"));//memory name
        properties.add(new Property("dataAddrWidth", "13"));
        
        properties.add(new Property("customInstSlavesSystemInfo", "<info/>"));
        
        properties.add(new Property("cpuReset", "false"));
        properties.add(new Property("cpuID", "0"));
        properties.add(new Property("clockFrequency", "50000000"));
        properties.add(new Property("breakSlave", "", "cpu_0.jtag_debug_module"));
        properties.add(new Property("breakOffset", "32"));
        //
        for(int i = 0; i < values.size(); i++){//atributos
            if(values.get(i).getName().contains("frequency")){//transformo em Hz
                if(values.get(i).getName().contains("KHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("KHz", ""))*1000));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("MHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("MHz", ""))*1000000));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("GHz")){
                    aux = new Property("clockFrequency", String.valueOf(Integer.parseInt(values.get(i).getValue().replace("GHz", ""))*1000000000));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("rpm")){
                    aux = new Property("clockFrequency", String.valueOf(Double.parseDouble(values.get(i).getValue().replace("rpm", ""))*0.0166666666667));
                    values.set(i, aux);
                }
            }
            //
            //
            //
            if(values.get(i).getName().contains("Size")){//transformo p bytes
                if(values.get(i).getName().contains("KB")){
                    aux = new Property(values.get(i).getName(), String.valueOf(Integer.parseInt(values.get(i).getValue().replace("KB", ""))*1024));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("MB")){
                    aux = new Property(values.get(i).getName(), String.valueOf(Integer.parseInt(values.get(i).getValue().replace("MB", ""))*1048576));
                    values.set(i, aux);
                } else if(values.get(i).getName().contains("GB")){
                    aux = new Property(values.get(i).getName(), String.valueOf(Integer.parseInt(values.get(i).getValue().replace("GB", ""))*1073741824));
                    values.set(i, aux);
                }
            }
            //
            //
            //
            for(int j = 0; j < properties.size(); j++){//propriedades finais
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * DM9000A_IF
     */
    public List<Property> pll(){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("c0", "", "<![CDATA[tap c0 mult 2 div 1 phase 0 enabled true inputfreq 50000000 outputfreq 100000000 ]]>"));
        properties.add(new Property("c1", "", "<![CDATA[tap c1 mult 2 div 1 phase -1806 enabled true inputfreq 50000000 outputfreq 100000000 ]]>"));
        properties.add(new Property("c2", "", "<![CDATA[tap c2 mult 4 div 11 phase 0 enabled true inputfreq 50000000 outputfreq 18181818 ]]>"));
        properties.add(new Property("c3", "", "<![CDATA[tap c3 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c4", "", "<![CDATA[tap c4 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c5", "", "<![CDATA[tap c5 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c6", "", "<![CDATA[tap c6 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c7", "", "<![CDATA[tap c7 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c8", "", "<![CDATA[tap c8 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c9", "", "<![CDATA[tap c9 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        //
        properties.add(new Property("deviceFamily", "CYCLONEII"));
        //
        properties.add(new Property("e0", "", "<![CDATA[tap e0 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("e1", "", "<![CDATA[tap e1 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("e2", "", "<![CDATA[tap e2 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("e3", "", "<![CDATA[tap e3 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        //
        properties.add(new Property("inputClockFrequency", "50000000"));
        properties.add(new Property("inputClockRate", "50000000"));
        properties.add(new Property("lockedOutputPortOption", "Export"));
        properties.add(new Property("pfdenaInputPortOption", "Register"));
        //
        properties.add(new Property("pllHdl", "", "<![CDATA[// megafunction wizard: %ALTPLL% // GENERATION: STANDARD // VERSION: WM1.0 // MODULE: altpll // ============================================================ // CNX file retrieval info // ============================================================ // Retrieval info: PRIVATE: ACTIVECLK_CHECK STRING \"0\" // Retrieval info: PRIVATE: BANDWIDTH STRING \"1.000\" // Retrieval info: PRIVATE: BANDWIDTH_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: BANDWIDTH_FREQ_UNIT STRING \"MHz\" // Retrieval info: PRIVATE: BANDWIDTH_PRESET STRING \"Low\" // Retrieval info: PRIVATE: BANDWIDTH_USE_AUTO STRING \"1\" // Retrieval info: PRIVATE: BANDWIDTH_USE_CUSTOM STRING \"0\" // Retrieval info: PRIVATE: BANDWIDTH_USE_PRESET STRING \"0\" // Retrieval info: PRIVATE: CLKBAD_SWITCHOVER_CHECK STRING \"0\" // Retrieval info: PRIVATE: CLKLOSS_CHECK STRING \"0\" // Retrieval info: PRIVATE: CLKSWITCH_CHECK STRING \"0\" // Retrieval info: PRIVATE: CNX_NO_COMPENSATE_RADIO STRING \"0\" // Retrieval info: PRIVATE: CREATE_CLKBAD_CHECK STRING \"0\" // Retrieval info: PRIVATE: CREATE_INCLK1_CHECK STRING \"0\" // Retrieval info: PRIVATE: CUR_DEDICATED_CLK STRING \"c0\" // Retrieval info: PRIVATE: CUR_FBIN_CLK STRING \"e0\" // Retrieval info: PRIVATE: DEVICE_SPEED_GRADE STRING \"Any\" // Retrieval info: PRIVATE: DIV_FACTOR0 NUMERIC \"1\" // Retrieval info: PRIVATE: DIV_FACTOR1 NUMERIC \"1\" // Retrieval info: PRIVATE: DIV_FACTOR2 NUMERIC \"11\" // Retrieval info: PRIVATE: DUTY_CYCLE0 STRING \"50.00000000\" // Retrieval info: PRIVATE: DUTY_CYCLE1 STRING \"50.00000000\" // Retrieval info: PRIVATE: DUTY_CYCLE2 STRING \"50.00000000\" // Retrieval info: PRIVATE: EXPLICIT_SWITCHOVER_COUNTER STRING \"0\" // Retrieval info: PRIVATE: EXT_FEEDBACK_RADIO STRING \"0\" // Retrieval info: PRIVATE: GLOCKED_COUNTER_EDIT_CHANGED STRING \"1\" // Retrieval info: PRIVATE: GLOCKED_FEATURE_ENABLED STRING \"1\" // Retrieval info: PRIVATE: GLOCKED_MODE_CHECK STRING \"0\" // Retrieval info: PRIVATE: GLOCK_COUNTER_EDIT NUMERIC \"1048575\" // Retrieval info: PRIVATE: HAS_MANUAL_SWITCHOVER STRING \"1\" // Retrieval info: PRIVATE: INCLK0_FREQ_EDIT STRING \"50.0\" // Retrieval info: PRIVATE: INCLK0_FREQ_UNIT_COMBO STRING \"MHz\" // Retrieval info: PRIVATE: INCLK1_FREQ_EDIT STRING \"100.000\" // Retrieval info: PRIVATE: INCLK1_FREQ_EDIT_CHANGED STRING \"1\" // Retrieval info: PRIVATE: INCLK1_FREQ_UNIT_CHANGED STRING \"1\" // Retrieval info: PRIVATE: INCLK1_FREQ_UNIT_COMBO STRING \"MHz\" // Retrieval info: PRIVATE: INTENDED_DEVICE_FAMILY STRING \"Cyclone II\" // Retrieval info: PRIVATE: INT_FEEDBACK__MODE_RADIO STRING \"1\" // Retrieval info: PRIVATE: LOCKED_OUTPUT_CHECK STRING \"0\" // Retrieval info: PRIVATE: LONG_SCAN_RADIO STRING \"1\" // Retrieval info: PRIVATE: LVDS_MODE_DATA_RATE STRING \"Not Available\" // Retrieval info: PRIVATE: LVDS_MODE_DATA_RATE_DIRTY NUMERIC \"0\" // Retrieval info: PRIVATE: LVDS_PHASE_SHIFT_UNIT0 STRING \"ps\" // Retrieval info: PRIVATE: LVDS_PHASE_SHIFT_UNIT1 STRING \"ps\" // Retrieval info: PRIVATE: LVDS_PHASE_SHIFT_UNIT2 STRING \"ps\" // Retrieval info: PRIVATE: MIRROR_CLK0 STRING \"0\" // Retrieval info: PRIVATE: MIRROR_CLK1 STRING \"0\" // Retrieval info: PRIVATE: MIRROR_CLK2 STRING \"0\" // Retrieval info: PRIVATE: MULT_FACTOR0 NUMERIC \"2\" // Retrieval info: PRIVATE: MULT_FACTOR1 NUMERIC \"2\" // Retrieval info: PRIVATE: MULT_FACTOR2 NUMERIC \"4\" // Retrieval info: PRIVATE: NORMAL_MODE_RADIO STRING \"1\" // Retrieval info: PRIVATE: OUTPUT_FREQ0 STRING \"0.00010000\" // Retrieval info: PRIVATE: OUTPUT_FREQ1 STRING \"100.00000000\" // Retrieval info: PRIVATE: OUTPUT_FREQ2 STRING \"18.32400000\" // Retrieval info: PRIVATE: OUTPUT_FREQ_MODE0 STRING \"0\" // Retrieval info: PRIVATE: OUTPUT_FREQ_MODE1 STRING \"0\" // Retrieval info: PRIVATE: OUTPUT_FREQ_MODE2 STRING \"0\" // Retrieval info: PRIVATE: OUTPUT_FREQ_UNIT0 STRING \"MHz\" // Retrieval info: PRIVATE: OUTPUT_FREQ_UNIT1 STRING \"MHz\" // Retrieval info: PRIVATE: OUTPUT_FREQ_UNIT2 STRING \"MHz\" // Retrieval info: PRIVATE: PHASE_RECONFIG_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: PHASE_RECONFIG_INPUTS_CHECK STRING \"0\" // Retrieval info: PRIVATE: PHASE_SHIFT0 STRING \"0.00000000\" // Retrieval info: PRIVATE: PHASE_SHIFT1 STRING \"-65.00000000\" // Retrieval info: PRIVATE: PHASE_SHIFT2 STRING \"0.00000000\" // Retrieval info: PRIVATE: PHASE_SHIFT_STEP_ENABLED_CHECK STRING \"0\" // Retrieval info: PRIVATE: PHASE_SHIFT_UNIT0 STRING \"ps\" // Retrieval info: PRIVATE: PHASE_SHIFT_UNIT1 STRING \"deg\" // Retrieval info: PRIVATE: PHASE_SHIFT_UNIT2 STRING \"deg\" // Retrieval info: PRIVATE: PLL_ADVANCED_PARAM_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_ARESET_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_AUTOPLL_CHECK NUMERIC \"1\" // Retrieval info: PRIVATE: PLL_ENA_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_ENHPLL_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PLL_FASTPLL_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PLL_FBMIMIC_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_LVDS_PLL_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PLL_PFDENA_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_TARGET_HARCOPY_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PRIMARY_CLK_COMBO STRING \"inclk0\" // Retrieval info: PRIVATE: SACN_INPUTS_CHECK STRING \"0\" // Retrieval info: PRIVATE: SCAN_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: SELF_RESET_LOCK_LOSS STRING \"0\" // Retrieval info: PRIVATE: SHORT_SCAN_RADIO STRING \"0\" // Retrieval info: PRIVATE: SPREAD_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: SPREAD_FREQ STRING \"50.000\" // Retrieval info: PRIVATE: SPREAD_FREQ_UNIT STRING \"KHz\" // Retrieval info: PRIVATE: SPREAD_PERCENT STRING \"0.500\" // Retrieval info: PRIVATE: SPREAD_USE STRING \"0\" // Retrieval info: PRIVATE: SRC_SYNCH_COMP_RADIO STRING \"0\" // Retrieval info: PRIVATE: STICKY_CLK0 STRING \"1\" // Retrieval info: PRIVATE: STICKY_CLK1 STRING \"1\" // Retrieval info: PRIVATE: STICKY_CLK2 STRING \"1\" // Retrieval info: PRIVATE: SWITCHOVER_COUNT_EDIT NUMERIC \"1\" // Retrieval info: PRIVATE: SWITCHOVER_FEATURE_ENABLED STRING \"1\" // Retrieval info: PRIVATE: SYNTH_WRAPPER_GEN_POSTFIX STRING \"0\" // Retrieval info: PRIVATE: USE_CLK0 STRING \"1\" // Retrieval info: PRIVATE: USE_CLK1 STRING \"1\" // Retrieval info: PRIVATE: USE_CLK2 STRING \"1\" // Retrieval info: PRIVATE: USE_CLKENA0 STRING \"0\" // Retrieval info: PRIVATE: USE_CLKENA1 STRING \"0\" // Retrieval info: PRIVATE: USE_CLKENA2 STRING \"0\" // Retrieval info: PRIVATE: ZERO_DELAY_RADIO STRING \"0\" // Retrieval info: LIBRARY: altera_mf altera_mf.altera_mf_components.all // Retrieval info: CONSTANT: CLK0_DIVIDE_BY NUMERIC \"1\" // Retrieval info: CONSTANT: CLK0_DUTY_CYCLE NUMERIC \"50\" // Retrieval info: CONSTANT: CLK0_MULTIPLY_BY NUMERIC \"2\" // Retrieval info: CONSTANT: CLK0_PHASE_SHIFT STRING \"0\" // Retrieval info: CONSTANT: CLK1_DIVIDE_BY NUMERIC \"1\" // Retrieval info: CONSTANT: CLK1_DUTY_CYCLE NUMERIC \"50\" // Retrieval info: CONSTANT: CLK1_MULTIPLY_BY NUMERIC \"2\" // Retrieval info: CONSTANT: CLK1_PHASE_SHIFT STRING \"-1806\" // Retrieval info: CONSTANT: CLK2_DIVIDE_BY NUMERIC \"11\" // Retrieval info: CONSTANT: CLK2_DUTY_CYCLE NUMERIC \"50\" // Retrieval info: CONSTANT: CLK2_MULTIPLY_BY NUMERIC \"4\" // Retrieval info: CONSTANT: CLK2_PHASE_SHIFT STRING \"0\" // Retrieval info: CONSTANT: COMPENSATE_CLOCK STRING \"CLK0\" // Retrieval info: CONSTANT: INCLK0_INPUT_FREQUENCY NUMERIC \"20000\" // Retrieval info: CONSTANT: INTENDED_DEVICE_FAMILY STRING \"Cyclone II\" // Retrieval info: CONSTANT: LPM_TYPE STRING \"altpll\" // Retrieval info: CONSTANT: OPERATION_MODE STRING \"NORMAL\" // Retrieval info: CONSTANT: PORT_ACTIVECLOCK STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_ARESET STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKBAD0 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKBAD1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKLOSS STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKSWITCH STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CONFIGUPDATE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_FBIN STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_INCLK0 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_INCLK1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_LOCKED STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PFDENA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASECOUNTERSELECT STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASEDONE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASESTEP STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASEUPDOWN STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PLLENA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANACLR STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANCLK STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANCLKENA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANDATA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANDATAOUT STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANDONE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANREAD STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANWRITE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clk0 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_clk1 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_clk2 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_clk3 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clk4 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clk5 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena0 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena2 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena3 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena4 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena5 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk0 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk2 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk3 STRING \"PORT_UNUSED\" // Retrieval info: USED_PORT: c0 0 0 0 0 OUTPUT_CLK_EXT VCC \"c0\" // Retrieval info: USED_PORT: c1 0 0 0 0 OUTPUT_CLK_EXT VCC \"c1\" // Retrieval info: USED_PORT: c2 0 0 0 0 OUTPUT_CLK_EXT VCC \"c2\" // Retrieval info: USED_PORT: inclk0 0 0 0 0 INPUT_CLK_EXT GND \"inclk0\" ]]>"));
        properties.add(new Property("resetInputPortOption", "Register"));
        //
        return properties;
    }

    /*
     * DM9000A_IF
     */
    public List<Property> pll(List<Property> values ){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("c0", "", "<![CDATA[tap c0 mult 2 div 1 phase 0 enabled true inputfreq 50000000 outputfreq 100000000 ]]>"));
        properties.add(new Property("c1", "", "<![CDATA[tap c1 mult 2 div 1 phase -1806 enabled true inputfreq 50000000 outputfreq 100000000 ]]>"));
        properties.add(new Property("c2", "", "<![CDATA[tap c2 mult 4 div 11 phase 0 enabled true inputfreq 50000000 outputfreq 18181818 ]]>"));
        properties.add(new Property("c3", "", "<![CDATA[tap c3 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c4", "", "<![CDATA[tap c4 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c5", "", "<![CDATA[tap c5 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c6", "", "<![CDATA[tap c6 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c7", "", "<![CDATA[tap c7 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c8", "", "<![CDATA[tap c8 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("c9", "", "<![CDATA[tap c9 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        //
        properties.add(new Property("deviceFamily", "CYCLONEII"));
        //
        properties.add(new Property("e0", "", "<![CDATA[tap e0 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("e1", "", "<![CDATA[tap e1 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("e2", "", "<![CDATA[tap e2 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        properties.add(new Property("e3", "", "<![CDATA[tap e3 mult 1 div 1 phase 0 enabled false inputfreq 0 outputfreq 0 ]]>"));
        //
        properties.add(new Property("inputClockFrequency", "50000000"));
        properties.add(new Property("inputClockRate", "50000000"));
        properties.add(new Property("lockedOutputPortOption", "Export"));
        properties.add(new Property("pfdenaInputPortOption", "Register"));
        //
        properties.add(new Property("pllHdl", "", "<![CDATA[// megafunction wizard: %ALTPLL% // GENERATION: STANDARD // VERSION: WM1.0 // MODULE: altpll // ============================================================ // CNX file retrieval info // ============================================================ // Retrieval info: PRIVATE: ACTIVECLK_CHECK STRING \"0\" // Retrieval info: PRIVATE: BANDWIDTH STRING \"1.000\" // Retrieval info: PRIVATE: BANDWIDTH_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: BANDWIDTH_FREQ_UNIT STRING \"MHz\" // Retrieval info: PRIVATE: BANDWIDTH_PRESET STRING \"Low\" // Retrieval info: PRIVATE: BANDWIDTH_USE_AUTO STRING \"1\" // Retrieval info: PRIVATE: BANDWIDTH_USE_CUSTOM STRING \"0\" // Retrieval info: PRIVATE: BANDWIDTH_USE_PRESET STRING \"0\" // Retrieval info: PRIVATE: CLKBAD_SWITCHOVER_CHECK STRING \"0\" // Retrieval info: PRIVATE: CLKLOSS_CHECK STRING \"0\" // Retrieval info: PRIVATE: CLKSWITCH_CHECK STRING \"0\" // Retrieval info: PRIVATE: CNX_NO_COMPENSATE_RADIO STRING \"0\" // Retrieval info: PRIVATE: CREATE_CLKBAD_CHECK STRING \"0\" // Retrieval info: PRIVATE: CREATE_INCLK1_CHECK STRING \"0\" // Retrieval info: PRIVATE: CUR_DEDICATED_CLK STRING \"c0\" // Retrieval info: PRIVATE: CUR_FBIN_CLK STRING \"e0\" // Retrieval info: PRIVATE: DEVICE_SPEED_GRADE STRING \"Any\" // Retrieval info: PRIVATE: DIV_FACTOR0 NUMERIC \"1\" // Retrieval info: PRIVATE: DIV_FACTOR1 NUMERIC \"1\" // Retrieval info: PRIVATE: DIV_FACTOR2 NUMERIC \"11\" // Retrieval info: PRIVATE: DUTY_CYCLE0 STRING \"50.00000000\" // Retrieval info: PRIVATE: DUTY_CYCLE1 STRING \"50.00000000\" // Retrieval info: PRIVATE: DUTY_CYCLE2 STRING \"50.00000000\" // Retrieval info: PRIVATE: EXPLICIT_SWITCHOVER_COUNTER STRING \"0\" // Retrieval info: PRIVATE: EXT_FEEDBACK_RADIO STRING \"0\" // Retrieval info: PRIVATE: GLOCKED_COUNTER_EDIT_CHANGED STRING \"1\" // Retrieval info: PRIVATE: GLOCKED_FEATURE_ENABLED STRING \"1\" // Retrieval info: PRIVATE: GLOCKED_MODE_CHECK STRING \"0\" // Retrieval info: PRIVATE: GLOCK_COUNTER_EDIT NUMERIC \"1048575\" // Retrieval info: PRIVATE: HAS_MANUAL_SWITCHOVER STRING \"1\" // Retrieval info: PRIVATE: INCLK0_FREQ_EDIT STRING \"50.0\" // Retrieval info: PRIVATE: INCLK0_FREQ_UNIT_COMBO STRING \"MHz\" // Retrieval info: PRIVATE: INCLK1_FREQ_EDIT STRING \"100.000\" // Retrieval info: PRIVATE: INCLK1_FREQ_EDIT_CHANGED STRING \"1\" // Retrieval info: PRIVATE: INCLK1_FREQ_UNIT_CHANGED STRING \"1\" // Retrieval info: PRIVATE: INCLK1_FREQ_UNIT_COMBO STRING \"MHz\" // Retrieval info: PRIVATE: INTENDED_DEVICE_FAMILY STRING \"Cyclone II\" // Retrieval info: PRIVATE: INT_FEEDBACK__MODE_RADIO STRING \"1\" // Retrieval info: PRIVATE: LOCKED_OUTPUT_CHECK STRING \"0\" // Retrieval info: PRIVATE: LONG_SCAN_RADIO STRING \"1\" // Retrieval info: PRIVATE: LVDS_MODE_DATA_RATE STRING \"Not Available\" // Retrieval info: PRIVATE: LVDS_MODE_DATA_RATE_DIRTY NUMERIC \"0\" // Retrieval info: PRIVATE: LVDS_PHASE_SHIFT_UNIT0 STRING \"ps\" // Retrieval info: PRIVATE: LVDS_PHASE_SHIFT_UNIT1 STRING \"ps\" // Retrieval info: PRIVATE: LVDS_PHASE_SHIFT_UNIT2 STRING \"ps\" // Retrieval info: PRIVATE: MIRROR_CLK0 STRING \"0\" // Retrieval info: PRIVATE: MIRROR_CLK1 STRING \"0\" // Retrieval info: PRIVATE: MIRROR_CLK2 STRING \"0\" // Retrieval info: PRIVATE: MULT_FACTOR0 NUMERIC \"2\" // Retrieval info: PRIVATE: MULT_FACTOR1 NUMERIC \"2\" // Retrieval info: PRIVATE: MULT_FACTOR2 NUMERIC \"4\" // Retrieval info: PRIVATE: NORMAL_MODE_RADIO STRING \"1\" // Retrieval info: PRIVATE: OUTPUT_FREQ0 STRING \"0.00010000\" // Retrieval info: PRIVATE: OUTPUT_FREQ1 STRING \"100.00000000\" // Retrieval info: PRIVATE: OUTPUT_FREQ2 STRING \"18.32400000\" // Retrieval info: PRIVATE: OUTPUT_FREQ_MODE0 STRING \"0\" // Retrieval info: PRIVATE: OUTPUT_FREQ_MODE1 STRING \"0\" // Retrieval info: PRIVATE: OUTPUT_FREQ_MODE2 STRING \"0\" // Retrieval info: PRIVATE: OUTPUT_FREQ_UNIT0 STRING \"MHz\" // Retrieval info: PRIVATE: OUTPUT_FREQ_UNIT1 STRING \"MHz\" // Retrieval info: PRIVATE: OUTPUT_FREQ_UNIT2 STRING \"MHz\" // Retrieval info: PRIVATE: PHASE_RECONFIG_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: PHASE_RECONFIG_INPUTS_CHECK STRING \"0\" // Retrieval info: PRIVATE: PHASE_SHIFT0 STRING \"0.00000000\" // Retrieval info: PRIVATE: PHASE_SHIFT1 STRING \"-65.00000000\" // Retrieval info: PRIVATE: PHASE_SHIFT2 STRING \"0.00000000\" // Retrieval info: PRIVATE: PHASE_SHIFT_STEP_ENABLED_CHECK STRING \"0\" // Retrieval info: PRIVATE: PHASE_SHIFT_UNIT0 STRING \"ps\" // Retrieval info: PRIVATE: PHASE_SHIFT_UNIT1 STRING \"deg\" // Retrieval info: PRIVATE: PHASE_SHIFT_UNIT2 STRING \"deg\" // Retrieval info: PRIVATE: PLL_ADVANCED_PARAM_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_ARESET_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_AUTOPLL_CHECK NUMERIC \"1\" // Retrieval info: PRIVATE: PLL_ENA_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_ENHPLL_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PLL_FASTPLL_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PLL_FBMIMIC_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_LVDS_PLL_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PLL_PFDENA_CHECK STRING \"0\" // Retrieval info: PRIVATE: PLL_TARGET_HARCOPY_CHECK NUMERIC \"0\" // Retrieval info: PRIVATE: PRIMARY_CLK_COMBO STRING \"inclk0\" // Retrieval info: PRIVATE: SACN_INPUTS_CHECK STRING \"0\" // Retrieval info: PRIVATE: SCAN_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: SELF_RESET_LOCK_LOSS STRING \"0\" // Retrieval info: PRIVATE: SHORT_SCAN_RADIO STRING \"0\" // Retrieval info: PRIVATE: SPREAD_FEATURE_ENABLED STRING \"0\" // Retrieval info: PRIVATE: SPREAD_FREQ STRING \"50.000\" // Retrieval info: PRIVATE: SPREAD_FREQ_UNIT STRING \"KHz\" // Retrieval info: PRIVATE: SPREAD_PERCENT STRING \"0.500\" // Retrieval info: PRIVATE: SPREAD_USE STRING \"0\" // Retrieval info: PRIVATE: SRC_SYNCH_COMP_RADIO STRING \"0\" // Retrieval info: PRIVATE: STICKY_CLK0 STRING \"1\" // Retrieval info: PRIVATE: STICKY_CLK1 STRING \"1\" // Retrieval info: PRIVATE: STICKY_CLK2 STRING \"1\" // Retrieval info: PRIVATE: SWITCHOVER_COUNT_EDIT NUMERIC \"1\" // Retrieval info: PRIVATE: SWITCHOVER_FEATURE_ENABLED STRING \"1\" // Retrieval info: PRIVATE: SYNTH_WRAPPER_GEN_POSTFIX STRING \"0\" // Retrieval info: PRIVATE: USE_CLK0 STRING \"1\" // Retrieval info: PRIVATE: USE_CLK1 STRING \"1\" // Retrieval info: PRIVATE: USE_CLK2 STRING \"1\" // Retrieval info: PRIVATE: USE_CLKENA0 STRING \"0\" // Retrieval info: PRIVATE: USE_CLKENA1 STRING \"0\" // Retrieval info: PRIVATE: USE_CLKENA2 STRING \"0\" // Retrieval info: PRIVATE: ZERO_DELAY_RADIO STRING \"0\" // Retrieval info: LIBRARY: altera_mf altera_mf.altera_mf_components.all // Retrieval info: CONSTANT: CLK0_DIVIDE_BY NUMERIC \"1\" // Retrieval info: CONSTANT: CLK0_DUTY_CYCLE NUMERIC \"50\" // Retrieval info: CONSTANT: CLK0_MULTIPLY_BY NUMERIC \"2\" // Retrieval info: CONSTANT: CLK0_PHASE_SHIFT STRING \"0\" // Retrieval info: CONSTANT: CLK1_DIVIDE_BY NUMERIC \"1\" // Retrieval info: CONSTANT: CLK1_DUTY_CYCLE NUMERIC \"50\" // Retrieval info: CONSTANT: CLK1_MULTIPLY_BY NUMERIC \"2\" // Retrieval info: CONSTANT: CLK1_PHASE_SHIFT STRING \"-1806\" // Retrieval info: CONSTANT: CLK2_DIVIDE_BY NUMERIC \"11\" // Retrieval info: CONSTANT: CLK2_DUTY_CYCLE NUMERIC \"50\" // Retrieval info: CONSTANT: CLK2_MULTIPLY_BY NUMERIC \"4\" // Retrieval info: CONSTANT: CLK2_PHASE_SHIFT STRING \"0\" // Retrieval info: CONSTANT: COMPENSATE_CLOCK STRING \"CLK0\" // Retrieval info: CONSTANT: INCLK0_INPUT_FREQUENCY NUMERIC \"20000\" // Retrieval info: CONSTANT: INTENDED_DEVICE_FAMILY STRING \"Cyclone II\" // Retrieval info: CONSTANT: LPM_TYPE STRING \"altpll\" // Retrieval info: CONSTANT: OPERATION_MODE STRING \"NORMAL\" // Retrieval info: CONSTANT: PORT_ACTIVECLOCK STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_ARESET STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKBAD0 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKBAD1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKLOSS STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CLKSWITCH STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_CONFIGUPDATE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_FBIN STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_INCLK0 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_INCLK1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_LOCKED STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PFDENA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASECOUNTERSELECT STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASEDONE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASESTEP STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PHASEUPDOWN STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_PLLENA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANACLR STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANCLK STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANCLKENA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANDATA STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANDATAOUT STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANDONE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANREAD STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_SCANWRITE STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clk0 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_clk1 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_clk2 STRING \"PORT_USED\" // Retrieval info: CONSTANT: PORT_clk3 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clk4 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clk5 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena0 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena2 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena3 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena4 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_clkena5 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk0 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk1 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk2 STRING \"PORT_UNUSED\" // Retrieval info: CONSTANT: PORT_extclk3 STRING \"PORT_UNUSED\" // Retrieval info: USED_PORT: c0 0 0 0 0 OUTPUT_CLK_EXT VCC \"c0\" // Retrieval info: USED_PORT: c1 0 0 0 0 OUTPUT_CLK_EXT VCC \"c1\" // Retrieval info: USED_PORT: c2 0 0 0 0 OUTPUT_CLK_EXT VCC \"c2\" // Retrieval info: USED_PORT: inclk0 0 0 0 0 INPUT_CLK_EXT GND \"inclk0\" ]]>"));
        properties.add(new Property("resetInputPortOption", "Register"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * Return the original name of the type
     */
    public static String consultKindModule(String type){
        if(type.equals("<<HwProcessor>>")){
            return "altera_nios2";
        } else if(type.equals("<<HwClock>>")){
            return "clock_source";
        } else if(type.equals("<<HwRAM>>")){
            return "altera_avalon_onchip_memory2";
        } else if(type.equals("<<hwPIO_RED>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_GREEN>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_SWITCH>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_BTN>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwSDRAM>>")){
            return "altera_avalon_new_sdram_controller";
        } else if(type.equals("<<hwSSRAM>>")){
            return "altera_avalon_cy7c1380_ssram";
        } else if(type.equals("<<hwTRISTAGE_BRIDGE>>")){
            return "altera_avalon_tri_state_bridge";
        } else if(type.equals("<<hwCFIFlash>")){
            return "altera_avalon_cfi_flash";
        } else if(type.equals("<<hwTIMER>>")){
            return "altera_avalon_timer";
        } else if(type.equals("<<hwTIMER_STAMP>>")){
            return "altera_avalon_timer";
        } else if(type.equals("<<HwI_O>>")){
            return "altera_avalon_jtag_uart";
        } else if(type.equals("<<hwUART>>")){
            return "altera_avalon_uart";
        } else if(type.equals("<<hwTRISTAGEBRIDGE>>")){
            return "altera_avalon_tri_state_bridge";
        } else if(type.equals("<<hwISP1362_IF>>")){
            return "ISP1362_IF";
        } else if(type.equals("<<hwPIO>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwCLK_SOURCE>>")){
            return "clock_source";
        } else if(type.equals("<<hwSEG7_IF>>")){
            return "SEG7_IF";
        } else if(type.equals("<<hwAUDIO_IF>>")){
            return "AUDIO_IF";
        } else if(type.equals("<<hwVGA>>")){
            return "VGA_NIOS_CTRL";
        } else if(type.equals("<<hwDM9000A_IF>>")){
            return "DM9000A_IF";
        } else if(type.equals("<<hwVGA_NIOS_CTRL>>")){
            return "VGA_NIOS_CTRL";
        } else if(type.equals("<<hwSYSID>>")){
            return "altera_avalon_sysid";
        /*} else if(type.equals("<<HwPLD>>")){
            return "altera_avalon_pll";*/
        } else if (type.equals("<<hwISP1362>>")){
            return "ISP1362_IF";
        } else if(type.equals("<<HwPLD>>")){
            return "altpll";
        } else if(type.equals("<<hwLCD>>")){
            return "altera_avalon_lcd_16207";
        } else{
            return "";
        }
    }

    /*
     * Return the characteristics of the specified kind
     */
    public List<Property> searchKindModule(String type, List<Property> atributos, String nomeRAM, String nomeCPU, String nomeJTAG, String nomeCLK, String nomeALTPLL){
        if(type.equals("<<HwProcessor>>")){
            return cpu_nios2(atributos, nomeRAM, nomeCPU, nomeJTAG, nomeALTPLL);
        } else if(type.equals("<<HwClock>>")){
            return clk_source(atributos);
        } else if(type.equals("<<HwBus>>")){
            return bus_zero();
        } else if(type.equals("<<HwRAM>>")){
            return onchip_memory(atributos,nomeRAM);
        } else if(type.equals("<<hwPIO_RED>>")){
            return pio_green_led(atributos);
        } else if(type.equals("<<hwPIO_GREEN>>")){
            return pio_red_led(atributos);
        } else if(type.equals("<<hwPIO_SWITCH>>")){
            return pio_switch(atributos);
        } else if(type.equals("<<hwPIO_BTN>>")){
            return pio_button(atributos);
        } else if(type.equals("<<hwSDRAM>>")){
            return SDRAM(atributos);
        } else if(type.equals("<<hwSSRAM>>")){
            return SSRAM(atributos);
        } else if(type.equals("<<hwTRISTAGE_BRIDGE>>")){
            return tri_stage_bridge(atributos);
        } else if(type.equals("<<hwCFIFlash>")){
            return cfi_flash(atributos);
        } else if(type.equals("<<hwTIMER>>")){
            return timer(atributos);
        } else if(type.equals("<<hwTIMER_STAMP>>")){
            return timer_stamp(atributos);
        } else if(type.equals("<<HwI_O>>")){
            return jtag_uart(atributos);
        } else if(type.equals("<<hwUART>>")){
            return uart(atributos);
        } else if(type.equals("<<hwISP1362_IF>>")){
            return isp1362(atributos);
        } else if(type.equals("<<hwPIO>>")){
            return pio(atributos);
        } else if(type.equals("<<hwCLK_SOURCE>>")){
            return clk(atributos);
        } else if(type.equals("<<hwSEG7_IF>>")){
            return seg7_if(atributos);
        } else if(type.equals("<<hwAUDIO_IF>>")){
            return audio(atributos);
        } else if(type.equals("<<hwVGA>>")){
            return vga(atributos);
        } else if(type.equals("<<hwDM9000A_IF>>")){
            return dm9000a(atributos);
        } else if(type.equals("<<hwVGA_NIOS_CTRL>>")){
            return vga_nios_ctrl(atributos);
        } else if(type.equals("<<HwPLD>>")){
            return altpll(atributos);
        /*} else if(type.equals("<<HwPLD>>")){
            return pll(atributos);*/
        } else if(type.equals("<<hwTIMER>>")){
            return timer(atributos);
        } else if(type.equals("<<hwTIMER_STAMP>>")){
            return timer_stamp(atributos);
        } else{
            return new LinkedList<Property>();
        }
    }
}
