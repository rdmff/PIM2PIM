/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Library;

import java.util.List;
import java.util.LinkedList;
import Basic.Property;
import Basic.Property;

/**
 * Created on 16/09/2011, 14:25:35
 * @author Roberto de Medeiros
 */
public class libXilinx {

    /*
     * Não há cabeçalho
     * Nesta versão ainda não instalei o padrão, como abaixo. Obs.: lembrar do igual.
     * BEGIN microblaze
     *  PARAMETER INSTANCE = microblaze_0
     *  PARAMETER C_AREA_OPTIMIZED = 1
     * ...
     * END
     */

    /*
     * proc_microblaze com list de propertie-value
     */
    public List<Property> proc_microblaze(List<Property> values){//ok
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "microblaze"));
        properties.add(new Property("PARAMETER C_AREA_OPTIMIZED", "0"));
        properties.add(new Property("PARAMETER C_USE_BARREL", "1"));
        properties.add(new Property("PARAMETER C_DEBUG_ENABLED", "1"));
        
        properties.add(new Property("PARAMETER C_ICACHE_BASEADDR", "0x80000000"));
        properties.add(new Property("PARAMETER C_ICACHE_HIGHADDR", "0x83ffffff"));
        
        properties.add(new Property("PARAMETER C_CACHE_BYTE_SIZE", "1024"));
        properties.add(new Property("PARAMETER C_ICACHE_ALWAYS_USED", "1"));
        properties.add(new Property("PARAMETER HW_VER", "8.20.b"));
        properties.add(new Property("PARAMETER C_USE_ICACHE", "1"));
        
        properties.add(new Property("BUS_INTERFACE DPLB", "mb_plb"));
        properties.add(new Property("BUS_INTERFACE IPLB", "mb_plb"));
        
        properties.add(new Property("BUS_INTERFACE IXCL", "microblaze_0_IXCL"));
        properties.add(new Property("BUS_INTERFACE DEBUG", "microblaze_0_mdm_bus"));
        properties.add(new Property("BUS_INTERFACE DLMB", "dlmb"));
        properties.add(new Property("BUS_INTERFACE ILMB", "ilmb"));
        
        properties.add(new Property("PORT MB_RESET", "mb_reset"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * plb_v46 com list de propertie-value
     */
    public List<Property> plb_v46(List<Property> values){//consultando
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "plb_v46"));
        properties.add(new Property("PARAMETER HW_VER", "1.05.a"));
        properties.add(new Property("PORT PLB_Clk", "clk_50_0000MHz"));
        properties.add(new Property("PORT SYS_Rst", "sys_bus_reset"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * lmb_v10 com list de propertie-value
     */
    public List<Property> lmb_v10(List<Property> values){//consultando
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "lmb_v10"));
        properties.add(new Property("PARAMETER HW_VER", "2.00.b"));
        properties.add(new Property("PORT LMB_Clk", "clk_50_0000MHz"));
        properties.add(new Property("PORT SYS_Rst", "sys_bus_reset"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * lmb_bram_if_cntlr com list de propertie-value
     */
    public List<Property> lmb_bram_if_cntlr(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "lmb_bram_if_cntlr"));
        properties.add(new Property("PARAMETER HW_VER", "3.00.b"));
        properties.add(new Property("PARAMETER C_BASEADDR", "0x00000000"));
        properties.add(new Property("PARAMETER C_HIGHADDR", "0x00001fff"));
        properties.add(new Property("BUS_INTERFACE SLMB", "dlmb"));
        properties.add(new Property("BUS_INTERFACE BRAM_PORT", "dlmb_port"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * bram_block com list de propertie-value
     */
    public List<Property> bram_block(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "lmb_bram"));
        properties.add(new Property("PARAMETER HW_VER", "1.00.a"));
        properties.add(new Property("BUS_INTERFACE PORTA", "ilmb_port"));
        properties.add(new Property("BUS_INTERFACE PORTB", "dlmb_port"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * mpmc com list de propertie-value
     */
    public List<Property> mpmc(List<Property> values){//ok
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "mpmc"));
        properties.add(new Property("PARAMETER C_NUM_PORTS", "2"));
        properties.add(new Property("PARAMETER C_SPECIAL_BOARD", "S3E_STKIT"));
        properties.add(new Property("PARAMETER C_MEM_TYPE", "DDR"));
        
        properties.add(new Property("PARAMETER C_MEM_PARTNO", "MT46V32M16-6"));
        properties.add(new Property("PARAMETER C_MEM_DATA_WIDTH", "16"));
        properties.add(new Property("PARAMETER C_PIM0_BASETYPE", "2"));
        properties.add(new Property("PARAMETER C_PIM1_BASETYPE", "1"));
        
        properties.add(new Property("PARAMETER HW_VER", "6.05.a"));
        properties.add(new Property("PARAMETER C_MPMC_BASEADDR", "0x80000000"));
        properties.add(new Property("PARAMETER C_MPMC_HIGHADDR", "0x83ffffff"));
        properties.add(new Property("BUS_INTERFACE SPLB0", "mb_plb"));
        
        properties.add(new Property("BUS_INTERFACE XCL1", "microblaze_0_IXCL"));
        properties.add(new Property("PORT MPMC_Clk0", "clk_100_0000MHzDCM0"));
        properties.add(new Property("PORT MPMC_Clk90", "clk_100_0000MHz90DCM0"));
        properties.add(new Property("PORT MPMC_Rst", "sys_periph_reset"));
        
        properties.add(new Property("PORT DDR_Clk", "fpga_0_DDR_SDRAM_DDR_Clk_pin"));
        properties.add(new Property("PORT DDR_Clk_n", "fpga_0_DDR_SDRAM_DDR_Clk_n_pin"));
        properties.add(new Property("PORT DDR_Clk_n", "fpga_0_DDR_SDRAM_DDR_Clk_n_pin"));
        properties.add(new Property("PORT DDR_CE", "fpga_0_DDR_SDRAM_DDR_CE_pin"));
        
        properties.add(new Property("PORT DDR_CS_n", "fpga_0_DDR_SDRAM_DDR_CS_n_pin"));
        properties.add(new Property("PORT DDR_RAS_n", "fpga_0_DDR_SDRAM_DDR_RAS_n_pin"));
        properties.add(new Property("PORT DDR_CAS_n", "fpga_0_DDR_SDRAM_DDR_CAS_n_pin"));
        properties.add(new Property("PORT DDR_WE_n", "fpga_0_DDR_SDRAM_DDR_WE_n_pin"));
        
        properties.add(new Property("PORT DDR_BankAddr", "fpga_0_DDR_SDRAM_DDR_BankAddr_pin"));
        properties.add(new Property("PORT DDR_Addr", "fpga_0_DDR_SDRAM_DDR_Addr_pin"));
        properties.add(new Property("PORT DDR_DQ", "fpga_0_DDR_SDRAM_DDR_DQ_pin"));
        properties.add(new Property("PORT DDR_DM", "fpga_0_DDR_SDRAM_DDR_DM_pin"));
        
        properties.add(new Property("PORT DDR_DQS", "fpga_0_DDR_SDRAM_DDR_DQS_pin"));
        properties.add(new Property("PORT DDR_DQS_Div_O", "fpga_0_DDR_SDRAM_ddr_dqs_div_io_pin"));
        properties.add(new Property("PORT DDR_DQS_Div_I", "fpga_0_DDR_SDRAM_ddr_dqs_div_io_pin"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }
    
    /*
     * xps_uartlite com list de propertie-value
     */
    public List<Property> xps_uartlite(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "xps_uartlite"));
        properties.add(new Property("PARAMETER C_BAUDRATE", "9600"));
        properties.add(new Property("PARAMETER C_DATA_BITS", "8"));
        properties.add(new Property("PARAMETER C_USE_PARITY", "0"));
        properties.add(new Property("PARAMETER C_ODD_PARITY", "0"));
        properties.add(new Property("PARAMETER HW_VER", "1.02.a"));
        properties.add(new Property("PARAMETER C_BASEADDR", "0x84000000"));
        properties.add(new Property("PARAMETER C_HIGHADDR", "0x8400ffff"));
        properties.add(new Property("BUS_INTERFACE SPLB", "mb_plb"));
        properties.add(new Property("PORT RX", "fpga_0_RS232_DTE_RX_pin"));
        properties.add(new Property("PORT TX", "fpga_0_RS232_DTE_TX_pin"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * xps_gpio com list de propertie-value
     */
    public List<Property> xps_gpio(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "xps_gpio"));
        properties.add(new Property("PARAMETER C_ALL_INPUTS", "0"));
        properties.add(new Property("PARAMETER C_GPIO_WIDTH", "8"));
        properties.add(new Property("PARAMETER C_INTERRUPT_PRESENT", "0"));
        properties.add(new Property("PARAMETER C_IS_DUAL", "0"));
        properties.add(new Property("PARAMETER HW_VE", "2.00.a"));
        properties.add(new Property("PARAMETER C_BASEADDR", "0x81400000"));
        properties.add(new Property("PARAMETER C_HIGHADDR", "0x8140ffff"));
        properties.add(new Property("BUS_INTERFACE SPLB", "mb_plb"));
        properties.add(new Property("PORT GPIO_IO_O", "fpga_0_LEDs_8Bit_GPIO_IO_O_pin"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * xps_ethernetlite com list de propertie-value
     */
    public List<Property> xps_ethernetlite(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "xps_ethernetlite"));
        properties.add(new Property("PARAMETER HW_VER", "4.00.a"));
        properties.add(new Property("PARAMETER C_BASEADDR", "0x81000000"));
        properties.add(new Property("PARAMETER C_HIGHADDR", "0x8100ffff"));
        properties.add(new Property("BUS_INTERFACE SPLB", "mb_plb"));
        properties.add(new Property("PORT PHY_tx_clk", "fpga_0_Ethernet_MAC_PHY_tx_clk_pin"));
        properties.add(new Property("PORT PHY_rx_clk", "fpga_0_Ethernet_MAC_PHY_rx_clk_pin"));
        properties.add(new Property("PORT PHY_crs", "fpga_0_Ethernet_MAC_PHY_crs_pin"));
        properties.add(new Property("PORT PHY_dv", "fpga_0_Ethernet_MAC_PHY_dv_pin"));
        properties.add(new Property("PORT PHY_rx_data", "fpga_0_Ethernet_MAC_PHY_rx_data_pin"));
        properties.add(new Property("PORT PHY_col", "fpga_0_Ethernet_MAC_PHY_col_pin"));
        properties.add(new Property("PORT PHY_rx_er", "fpga_0_Ethernet_MAC_PHY_rx_er_pin"));
        properties.add(new Property("PORT PHY_rst_n", "fpga_0_Ethernet_MAC_PHY_rst_n_pin"));
        properties.add(new Property("PORT PHY_tx_en", "fpga_0_Ethernet_MAC_PHY_tx_en_pin"));
        properties.add(new Property("PORT PHY_tx_data", "fpga_0_Ethernet_MAC_PHY_tx_data_pin"));
        properties.add(new Property("PORT PHY_MDC", "fpga_0_Ethernet_MAC_PHY_MDC_pin"));
        properties.add(new Property("PORT PHY_MDIO", "fpga_0_Ethernet_MAC_PHY_MDIO_pin"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * xps_spi com list de propertie-value
     */
    public List<Property> xps_spi(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "xps_spi"));
        properties.add(new Property("PARAMETER C_FIFO_EXIST", "0"));
        properties.add(new Property("PARAMETER C_SCK_RATIO", "64"));
        properties.add(new Property("PARAMETER C_NUM_SS_BITS", "2"));
        properties.add(new Property("PARAMETER C_NUM_TRANSFER_BITS", "8"));
        properties.add(new Property("PARAMETER HW_VER", "2.02.a"));
        properties.add(new Property("PARAMETER C_BASEADDR", "0x83400000"));
        properties.add(new Property("PARAMETER C_HIGHADDR", "0x8340ffff"));
        properties.add(new Property("BUS_INTERFACE SPLB", "mb_plb"));
        properties.add(new Property("PORT SPISEL", "net_vcc"));
        properties.add(new Property("PORT SCK", "fpga_0_SPI_FLASH_SCK_pin"));
        properties.add(new Property("PORT MISO", "fpga_0_SPI_FLASH_MISO_pin"));
        properties.add(new Property("PORT MOSI", "fpga_0_SPI_FLASH_MOSI_pin"));
        properties.add(new Property("PORT SS", "fpga_0_SPI_FLASH_SS_pin"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * clock_generator com list de propertie-value
     */
    public List<Property> clock_generator(List<Property> values){//ok?
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "clock_generator"));
        properties.add(new Property("PARAMETER C_CLKIN_FREQ", "50000000"));
        properties.add(new Property("PARAMETER C_CLKOUT0_FREQ", "100000000"));
        properties.add(new Property("PARAMETER C_CLKOUT0_PHASE", "90"));
        properties.add(new Property("PARAMETER C_CLKOUT0_GROUP", "DCM0"));
        properties.add(new Property("PARAMETER C_CLKOUT0_BUF", "TRUE"));
        
        properties.add(new Property("PARAMETER C_CLKOUT1_FREQ", "100000000"));
        properties.add(new Property("PARAMETER C_CLKOUT1_PHASE", "0"));
        properties.add(new Property("PARAMETER C_CLKOUT1_GROUP", "DCM0"));
        properties.add(new Property("PARAMETER C_CLKOUT1_BUF", "TRUE"));
        properties.add(new Property("PARAMETER C_CLKOUT2_FREQ", "50000000"));
        properties.add(new Property("PARAMETER C_CLKOUT2_PHASE", "0"));
        
        properties.add(new Property("PARAMETER C_CLKOUT2_GROUP", "NONE"));
        properties.add(new Property("PARAMETER C_CLKOUT2_BUF", "TRUE"));
        properties.add(new Property("PARAMETER C_EXT_RESET_HIGH", "1"));
        properties.add(new Property("PARAMETER HW_VER", "4.03.a"));
        
        properties.add(new Property("PORT CLKIN", "CLK_S"));
        properties.add(new Property("PORT CLKOUT0", "clk_100_0000MHz90DCM0"));
        properties.add(new Property("PORT CLKOUT1", "clk_100_0000MHzDCM0"));
        properties.add(new Property("PORT CLKOUT2", "clk_50_0000MHz"));
        properties.add(new Property("PORT RST", "sys_rst_s"));
        properties.add(new Property("PORT LOCKED", "Dcm_all_locked"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * mdm com list de propertie-value
     */
    public List<Property> mdm(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "mdm"));
        properties.add(new Property("PARAMETER C_MB_DBG_PORTS", "1"));
        properties.add(new Property("PARAMETER C_USE_UART", "1"));
        properties.add(new Property("PARAMETER HW_VER", "2.00.b"));
        properties.add(new Property("PARAMETER C_BASEADDR", "0x84400000"));
        properties.add(new Property("PARAMETER C_HIGHADDR", "0x8440ffff"));
        properties.add(new Property("BUS_INTERFACE SPLB", "mb_plb"));
        properties.add(new Property("BUS_INTERFACE MBDEBUG_0", "microblaze_0_mdm_bus"));
        properties.add(new Property("PORT Debug_SYS_Rst", "Debug_SYS_Rst"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * proc_sys_reset com list de propertie-value
     */
    public List<Property> proc_sys_reset(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("PARAMETER INSTANCE", "proc_sys_reset"));
        properties.add(new Property("PARAMETER C_EXT_RESET_HIGH", "1"));
        properties.add(new Property("PARAMETER HW_VER", "3.00.a"));
        properties.add(new Property("PORT Slowest_sync_clk", "clk_50_0000MHz"));
        properties.add(new Property("PORT Ext_Reset_In", "sys_rst_s"));
        properties.add(new Property("PORT MB_Debug_Sys_Rst", "Debug_SYS_Rst"));
        properties.add(new Property("PORT Dcm_locked", "Dcm_all_locked"));
        properties.add(new Property("PORT MB_Reset", "mb_reset"));
        properties.add(new Property("PORT Bus_Struct_Reset", "sys_bus_reset"));
        properties.add(new Property("PORT Peripheral_Reset", "sys_periph_reset"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * Return the original name of the type
     */
    public static String consultKindModule(String type){
        if(type.equals("<<HwProcessor>>")){
            return "microblaze";
        } else if(type.equals("<<HwClock>>")){
            return "clock_source";
        } else if(type.equals("<<HwRAM>>")){
            return "lmb_v10";
        } else if(type.equals("<<hwPIO_RED>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_GREEN>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_SWITCH>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_BTN>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwSDRAM>>")){
            return "altera_avalon_new_sdram_controller";
        } else if(type.equals("<<hwSSRAM>>")){
            return "altera_avalon_cy7c1380_ssram";
        } else if(type.equals("<<hwTRISTAGE_BRIDGE>>")){
            return "altera_avalon_tri_state_bridge";
        } else if(type.equals("<<hwCFIFlash>")){
            return "altera_avalon_cfi_flash";
        } else if(type.equals("<<hwTIMER>>")){
            return "altera_avalon_timer";
        } else if(type.equals("<<hwTIMER_STAMP>>")){
            return "altera_avalon_timer";
        } else if(type.equals("<<HWI_O>>")){
            return "xps_uartlite";
        } else if(type.equals("<<hwUART>>")){
            return "xps_uartlite";
        } else if(type.equals("<<hwTRISTAGEBRIDGE>>")){
            return "altera_avalon_tri_state_bridge";
        } else if(type.equals("<<hwISP1362_IF>>")){
            return "ISP1362_IF";
        } else if(type.equals("<<hwPIO>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwCLK_SOURCE>>")){
            return "clock_source";
        } else if(type.equals("<<hwSEG7_IF>>")){
            return "SEG7_IF";
        } else if(type.equals("<<hwAUDIO_IF>>")){
            return "AUDIO_IF";
        } else if(type.equals("<<hwVGA>>")){
            return "VGA_NIOS_CTRL";
        } else if(type.equals("<<hwDM9000A_IF>>")){
            return "DM9000A_IF";
        } else if(type.equals("<<hwVGA_NIOS_CTRL>>")){
            return "VGA_NIOS_CTRL";
        } else if(type.equals("<<hwSYSID>>")){
            return "altera_avalon_sysid";
        } else if(type.equals("<<hwPLL>>")){
            return "altera_avalon_pll";
        } else if (type.equals("<<hwISP1362>>")){
            return "ISP1362_IF";
        } else if(type.equals("<<hwALT_PLL>>")){
            return "altpll";
        } else if(type.equals("<<hwLCD>>")){
            return "altera_avalon_lcd_16207";
        } else{
            return "";
        }
    }

    /*
     * Return the characteristics of the specified kind
     */
    public List<Property> searchKindModule(String type, List<Property> atributos){
        if(type.equals("microblaze")){
            return proc_microblaze(atributos);
        } else if(type.equals("clock_source")){
            return clock_generator(atributos);
        } else if(type.equals("lmb_v10")){
            return lmb_v10(atributos);
        } else if(type.equals("xps_uartlite")){
            return xps_uartlite(atributos);
        } else{
            return new LinkedList<Property>();
        }
    }
}
