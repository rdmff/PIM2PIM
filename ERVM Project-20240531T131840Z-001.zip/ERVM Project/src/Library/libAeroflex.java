/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Library;

import java.util.LinkedList;
import java.util.List;
import Basic.Property;
import Basic.Property;

/**
 * Created on 27/09/2011, 21:04:58
 * @author Roberto de Medeiros
 */
public class libAeroflex {
    //
    
    /*
     * sdctrl16 com list de propertie-value
     * 16- and 32-bit SDRAM memory controller
     */
    public List<Property> sdctrl16(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-de2-ep2c35\\sdctrl16.vhd"));
        properties.add(new Property("integer", "hindex", "0", ""));
        properties.add(new Property("integer", "haddr", "0", ""));
        properties.add(new Property("integer", "hmask", "16#f00#", ""));
        properties.add(new Property("integer", "ioaddr", "16#000#", ""));
        properties.add(new Property("integer", "iomask", "16#fff#", ""));
        properties.add(new Property("integer", "wprot", "0", ""));
        properties.add(new Property("integer", "invclk", "0", ""));
        properties.add(new Property("integer", "fast", "0", ""));
        properties.add(new Property("integer", "pwron", "0", ""));
        properties.add(new Property("integer", "sdbits", "16", ""));
        properties.add(new Property("integer", "oepol", "0", ""));
        properties.add(new Property("integer", "pageburst", "0", ""));
        properties.add(new Property("integer", "mobile", "0", ""));
        properties.add(new Property("port", "", "(\nrst     : in  std_ulogic;\nclk     : in  std_ulogic;\nahbsi   : in  ahb_slv_in_type;\nahbso   : out ahb_slv_out_type;\nsdi     : in  sdctrl_in_type;\nsdo     : out sdctrl_out_type\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }
    
    /*
     * apblcd com list de propertie-value
     * APB LCD module rev
     */
    public List<Property> apblcd(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-de2-ep2c35\\apblcd.vhd"));
        properties.add(new Property("integer", "pindex", "0", ""));
        properties.add(new Property("integer", "paddr", "0", ""));
        properties.add(new Property("integer", "pmask", "0", ""));
        properties.add(new Property("integer range 0 to 1", "oepol", "0", ""));
        properties.add(new Property("integer range 0 to 15", "tas", "1", ""));
        properties.add(new Property("integer range 0 to 127", "epw", "12", ""));
        //
        properties.add(new Property("port", "", "(\nrst     : in  std_ulogic;\nclk     : in  std_ulogic;\napbi    : in apb_slv_in_type;\napbo    : out apb_slv_out_type;\nlcdo    : out lcd_out_type;\nlcdi    : in lcd_in_type\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * clkgen_ep1c20board.vhd com list de propertie-value
     * Altera Cyclone ep1c20 clock generator
     */
    public List<Property> clkgen_ep1c20board(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep1c20\\clkgen_ep1c20board.vhd"));
        //
        properties.add(new Property("integer", "tech", "DEFFABTECH", ""));
        properties.add(new Property("integer", "clk_mul", "1", ""));
        properties.add(new Property("integer", "clk_div", "1", ""));
        properties.add(new Property("integer", "sdramen", "0", ""));
        properties.add(new Property("integer", "sdinvclk", "1", ""));
        properties.add(new Property("integer", "freq", "50000", ""));
        //
        properties.add(new Property("port", "", "(\nclkin   : in  std_logic;\nclkout  : out  std_logic;\nclk     : out std_logic;			-- main clock\nclkn    : out std_logic;			-- inverted main clock\nsdclk   : out std_logic;			-- SDRAM clock\ncgi     : in clkgen_in_type;\ncgo     : out clkgen_out_type);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * smc_mctrl com list de propertie-value
     * External memory controller
     */
    public List<Property> smc_mctrl(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep1c20\\smc_mctrl.vhd"));
        //
        properties.add(new Property("integer", "hindex", "0", ""));
        properties.add(new Property("integer", "pindex", "0", ""));
        properties.add(new Property("integer", "romaddr", "16#000#", ""));
        properties.add(new Property("integer", "rommask", "16#000#", ""));
        properties.add(new Property("integer", "ioaddr", "16#000#", ""));
        properties.add(new Property("integer", "iomask", "16#000#", ""));

        properties.add(new Property("integer", "ramaddr", "16#000#", ""));
        properties.add(new Property("integer", "rammask", "16#000#", ""));
        properties.add(new Property("integer", "paddr", "0", ""));
        properties.add(new Property("integer", "pmask", "16#000#", ""));
        properties.add(new Property("integer", "wprot", "0", ""));

        properties.add(new Property("integer", "invclk", "0", ""));
        properties.add(new Property("integer", "fast", "0", ""));
        properties.add(new Property("integer", "romasel", "28", ""));
        properties.add(new Property("integer", "sdrasel", "29", ""));
        properties.add(new Property("integer", "srbanks", "4", ""));

        properties.add(new Property("integer", "ram8", "0", ""));
        properties.add(new Property("integer", "ram16", "0", ""));
        properties.add(new Property("integer", "sden", "0", ""));
        properties.add(new Property("integer", "sepbus", "0", ""));
        properties.add(new Property("integer", "sdbits", "32", ""));

        properties.add(new Property("integer", "sdlsb", "2", ""));
        properties.add(new Property("integer", "oepol", "0", ""));
        properties.add(new Property("integer", "syncrst", "0", ""));
        //
        properties.add(new Property("port", "", "(\nrst       : in  std_ulogic;\nclk       : in  std_ulogic;\nmemi      : in  memory_in_type;\nmemo      : out memory_out_type;\nahbsi     : in  ahb_slv_in_type;\nahbso     : out ahb_slv_out_type;\napbi      : in  apb_slv_in_type;\napbo      : out apb_slv_out_type;\nwpo       : in  wprot_out_type;\nsdo       : out sdram_out_type;\neth_aen   : out std_logic; -- for smsc eth\neth_readn : out std_logic; -- for smsc eth\neth_writen: out std_logic;  -- for smsc eth\neth_nbe   : out std_logic_vector(3 downto 0) -- for smsc eth\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * ahbrom com list de propertie-value
     * 32-bit AHB ROM Module
     */
    public List<Property> ahbrom(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep1c20\\ahbrom.vhd"));
        //
        properties.add(new Property("integer", "hindex", "0", ""));
        properties.add(new Property("integer", "haddr", "0", ""));
        properties.add(new Property("integer", "hmask", "1", ""));
        properties.add(new Property("integer", "sdramen", "0", ""));
        properties.add(new Property("integer", "sdinvclk", "1", ""));
        properties.add(new Property("integer", "freq", "50000", ""));
        //
        properties.add(new Property("port", "", "(\nclkin   : in  std_logic;\nclkout  : out  std_logic;\nclk     : out std_logic;			-- main clock\nclkn    : out std_logic;			-- inverted main clock\nsdclk   : out std_logic;			-- SDRAM clock\ncgi     : in clkgen_in_type;\ncgo     : out clkgen_out_type);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * debugreg com list de propertie-value
     * very simple readable and adressable 64 bit (2x 32 bit)
     */
    public List<Property> debugreg(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep2sgx90-av\\debugreg.vhd"));
        //
        properties.add(new Property("port", "", "0", "(\nclk : in std_logic;\nrst_n : in std_logic;\nbus_addr : in std_logic_vector(2 downto 0);\nbus_datai : in std_logic_vector(31 downto 0);\nbus_datao : out std_logic_vector(31 downto 0);\nbus_wen : in std_logic;\nbus_cen : in std_logic;\niopins : out std_logic_vector(63 downto 0)\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * ft245uart com list de propertie-value
     * UART via USB FTDI FT245BL FIFO interface
     */
    public List<Property> ft245uart(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep2sgx90-av\\ft245uart.vhd"));
        //
        properties.add(new Property("integer", "pindex", "0", ""));
        properties.add(new Property("integer", "paddr", "0", ""));
        properties.add(new Property("integer", "pmask", "16#fff#", ""));
        properties.add(new Property("integer", "console", "0", ""));
        properties.add(new Property("integer", "pirq", "0", ""));
        properties.add(new Property("integer", "abits", "8", ""));
        //
        properties.add(new Property("port", "", "(\nrst    : in  std_ulogic;\nclk    : in  std_ulogic;\napbi   : in  apb_slv_in_type;\napbo   : out apb_slv_out_type;\nft245i : in  ft245_in_type;\nft245o : out ft245_out_type);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * prgmem com list de propertie-value
     * Program-Memory
     */
    public List<Property> prgmem(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep2sgx90-av\\prgmem.vhd"));
        //
        properties.add(new Property("string", "INIT_FILE_NAME"));
        properties.add(new Property("positive", "PRGM_MEM", "12", ""));
        properties.add(new Property("positive", "MEM_WIDTH", "32", ""));
        //
        properties.add(new Property("port", "", "(\n-- common signals\nclk               : in std_logic;                 -- normal system clock\nreset             : in std_logic;\n-- access (r)\naddr		: in std_logic_vector(PRGM_MEM-1 downto 0);\ndata		: out std_logic_vector(MEM_WIDTH-1 downto 0)\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * sram32 com list de propertie-value
     * Simulation model of generic 32-bit async SRAM
     */
    public List<Property> sram32(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep2sgx90-av\\sram32.vhd"));
        //
        properties.add(new Property("integer", "index", "0", ""));
        properties.add(new Property("Positive", "abits", "10", ""));
        properties.add(new Property("integer", "echk", "0", ""));
        properties.add(new Property("integer", "tacc", "10", ""));
        properties.add(new Property("string", "fname", "\"ram.dat\"", ""));
        //
        properties.add(new Property("port", "", "(  \na : in std_logic_vector(abits-1 downto 0);\nd : inout std_logic_vector(31 downto 0);\nlb : in std_logic;\nub : in std_logic;\nce : in std_logic;\nwe : in std_ulogic;\noe : in std_ulogic);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * altera_eek_clkgen com list de propertie-value
     * altpll lcd/vga clock generator
     */
    public List<Property> altera_eek_clkgen(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep3c25-eek\\altera_eek_clkgen.vhd"));
        //
        properties.add(new Property("integer", "clk0_mul", "1", ""));
        properties.add(new Property("integer", "clk0_div", "1", ""));
        properties.add(new Property("integer", "clk1_mul", "1", ""));
        properties.add(new Property("integer", "clk1_div", "1", ""));
        properties.add(new Property("integer", "clk_freq", "25000", ""));
        //
        properties.add(new Property("port", "", "(\ninclk0 : in  std_ulogic;\nclk0   : out std_ulogic;\nclk0x3 : out std_ulogic;\nclksel : in  std_logic_vector(1 downto 0);\nlocked : out std_ulogic);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * serializer com list de propertie-value
     * three vectors and serializes them into one output vector
     * serialize RGB VGA data
     */
    public List<Property> serializer(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-altera-ep3c25-eek\\serializer.vhd"));
        //
        properties.add(new Property("integer", "length", "8", ""));
        //
        properties.add(new Property("port", "", "(\nclk   : in  std_ulogic;\nsync  : in  std_ulogic;\nivec0 : in  std_logic_vector((length-1) downto 0);\nivec1 : in  std_logic_vector((length-1) downto 0);\nivec2 : in  std_logic_vector((length-1) downto 0);\novec  : out std_logic_vector((length-1) downto 0)\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * bschain com list de propertie-value
     */
    public List<Property> bschain(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-asic\\bschain.vhd"));
        //
        properties.add(new Property("integer", "tech", "1", ""));
        properties.add(new Property("integer range 0 to 1", "enable", "CFG_BOUNDSCAN_EN", ""));
        properties.add(new Property("integer range 0 to 1 ", "hzsup", "1", ""));
        //
        properties.add(new Property("port", "", "(\ninclk0 : in  std_ulogic;\nclk0   : out std_ulogic;\nclk0x3 : out std_ulogic;\nclksel : in  std_logic_vector(1 downto 0);\nlocked : out std_ulogic);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * core com list de propertie-value
     */
    public List<Property> core(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-asic\\core.vhd"));
        //
        properties.add(new Property("integer", "fabtech", "CFG_FABTECH", ""));
        properties.add(new Property("integer", "memtech", "CFG_MEMTECH", ""));
        properties.add(new Property("integer", "padtech", "CFG_PADTECH", ""));
        properties.add(new Property("integer", "clktech", "CFG_CLKTECH", ""));
        properties.add(new Property("integer", "disas", "CFG_DISAS", ""));
        properties.add(new Property("integer", "dbguart", "CFG_DUART", ""));
        properties.add(new Property("integer", "pclow", "CFG_PCLOW", ""));
        properties.add(new Property("integer", "scantest", "CFG_SCAN", ""));
        properties.add(new Property("integer", "bscanen", "CFG_BOUNDSCAN_EN", ""));
        //
        properties.add(new Property("port", "", "(\nresetn	: in  std_ulogic;\nclksel 	: in  std_logic_vector (1 downto 0);\nclk		: in  std_ulogic;\nerrorn	: out std_ulogic;\naddress 	: out std_logic_vector(27 downto 0);\ndatain	: in std_logic_vector(31 downto 0);\ndataout	: out std_logic_vector(31 downto 0);\ndataen 	: out std_logic_vector(31 downto 0);\ncbin   	: in std_logic_vector(7 downto 0);\ncbout   	: out std_logic_vector(7 downto 0);\ncben   	: out std_logic_vector(7 downto 0);\nsdclk  	: out std_ulogic;\nsdcsn  	: out std_logic_vector (1 downto 0);    -- sdram chip select\nsdwen  	: out std_ulogic;                       -- sdram write enable\nsdrasn  	: out std_ulogic;                       -- sdram ras\nsdcasn  	: out std_ulogic;                       -- sdram cas\nsddqm   	: out std_logic_vector (3 downto 0);    -- sdram dqm\ndsutx  	: out std_ulogic; 			-- DSU tx data\ndsurx  	: in  std_ulogic;  			-- DSU rx data\ndsuen   	: in std_ulogic;\ndsubre  	: in std_ulogic;\ndsuact  	: out std_ulogic;\ntxd1   	: out std_ulogic; 			-- UART1 tx data\nrxd1   	: in  std_ulogic;  			-- UART1 rx data\ntxd2   	: out std_ulogic; 			-- UART2 tx data\nrxd2   	: in  std_ulogic;  			-- UART2 rx data\nramsn  	: out std_logic_vector (4 downto 0);\nramoen 	: out std_logic_vector (4 downto 0);\nrwen   	: out std_logic_vector (3 downto 0);\noen    	: out std_ulogic;\nwriten 	: out std_ulogic;\nread   	: out std_ulogic;\niosn   	: out std_ulogic;\nromsn  	: out std_logic_vector (1 downto 0);\nbrdyn  	: in  std_ulogic;\nbexcn  	: in  std_ulogic;\nwdogn  	: out std_ulogic;\ngpioin      : in std_logic_vector(CFG_GRGPIO_WIDTH-1 downto 0); 	-- I/O port\ngpioout     : out std_logic_vector(CFG_GRGPIO_WIDTH-1 downto 0); 	-- I/O port\ngpioen      : out std_logic_vector(CFG_GRGPIO_WIDTH-1 downto 0); 	-- I/O port\nprom32	: in  std_ulogic;\npromedac	: in  std_ulogic;\nspw_clksel 	: in  std_logic_vector (1 downto 0);\nspw_clk	: in  std_ulogic;\nspw_rxd     : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_rxs     : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txd     : out std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txs     : out std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_ten     : out std_logic_vector(0 to CFG_SPW_NUM-1);\nlclk2x      : in  std_ulogic;\nlclk4x      : in  std_ulogic;\nlclkdis     : out std_ulogic;\nlclklock    : in  std_ulogic;\nlock        : out std_ulogic;\nroen        : in  std_ulogic;\nroout       : out std_ulogic;\ntesten 	: in  std_ulogic;\ngnd         : out std_ulogic;\ntrst        : in std_ulogic;\ntck         : in std_ulogic;\ntms         : in std_ulogic;\ntdi         : in std_ulogic;\ntdo         : out std_ulogic\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * pads com list de propertie-value
     */
    public List<Property> pads(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-asic\\pads.vhd"));
        //
        properties.add(new Property("integer", "clktech", "CFG_CLKTECH", ""));
        properties.add(new Property("integer", "padtech", "CFG_PADTECH", ""));
        //
        properties.add(new Property("port", "", "(\nresetn	: in  std_ulogic;\nclksel 	: in  std_logic_vector (1 downto 0);\nclk		: in  std_ulogic;\nlock    	: out std_ulogic;\nerrorn	: inout std_ulogic;\naddress 	: out std_logic_vector(27 downto 0);\ndata	: inout std_logic_vector(31 downto 0);\ncb   	: inout std_logic_vector(7 downto 0);\nsdclk  	: out std_ulogic;\nsdcsn  	: out std_logic_vector (1 downto 0);    -- sdram chip select\nsdwen  	: out std_ulogic;                       -- sdram write enable\nsdrasn  	: out std_ulogic;                       -- sdram ras\nsdcasn  	: out std_ulogic;                       -- sdram cas\nsddqm   	: out std_logic_vector (3 downto 0);    -- sdram dqm\ndsutx  	: out std_ulogic; 			-- DSU tx data\ndsurx  	: in  std_ulogic;  			-- DSU rx data\ndsuen   	: in std_ulogic;\ndsubre  	: in std_ulogic;\ndsuact  	: out std_ulogic;\ntxd1   	: out std_ulogic; 			-- UART1 tx data\nrxd1   	: in  std_ulogic;  			-- UART1 rx data\ntxd2   	: out std_ulogic; 			-- UART2 tx data\nrxd2   	: in  std_ulogic;  			-- UART2 rx data\nramsn  	: out std_logic_vector (4 downto 0);\nramoen 	: out std_logic_vector (4 downto 0);\nrwen   	: out std_logic_vector (3 downto 0);\noen    	: out std_ulogic;\nwriten 	: out std_ulogic;\nread   	: out std_ulogic;\niosn   	: out std_ulogic;\nromsn  	: out std_logic_vector (1 downto 0);\nbrdyn  	: in  std_ulogic;\nbexcn  	: in  std_ulogic;\nwdogn  	: inout std_ulogic;\ngpio        : inout std_logic_vector(CFG_GRGPIO_WIDTH-1 downto 0); 	-- I/O port\nprom32	: in std_ulogic;\npromedac	: in std_ulogic;\nspw_clksel 	: in  std_logic_vector (1 downto 0);\nspw_clk    	: in  std_ulogic;\nspw_rxdp    : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_rxdn    : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_rxsp    : in  std_logic_vector(0 to CFG_SPW_NUM-1);\npw_rxsn    : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txdp    : out std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txdn    : out std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txsp    : out std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txsn    : out std_logic_vector(0 to CFG_SPW_NUM-1);\nlvdsref    	: in  std_ulogic;\nroen        : in  std_ulogic;\nroout       : out std_ulogic;\ntest       	: in  std_ulogic;\ntrst        : in std_ulogic;\ntck         : in std_ulogic;\ntms         : in std_ulogic;\ntdi         : in std_ulogic;\ntdo         : out std_ulogic;\nlresetn	: out std_ulogic;\nlclksel 	: out std_logic_vector (1 downto 0);\nlclk	: out std_ulogic;\nlerrorn	: in std_ulogic;\nladdress 	: in std_logic_vector(27 downto 0);\ndatain	: out std_logic_vector(31 downto 0);\ndataout	: in std_logic_vector(31 downto 0);\ndataen	: in std_logic_vector(31 downto 0);\ncbin   	: out std_logic_vector(7 downto 0);\ncbout   	: in std_logic_vector(7 downto 0);\ncben   	: in std_logic_vector(7 downto 0);\nlsdclk  	: in std_ulogic;\nlsdcsn  	: in std_logic_vector (1 downto 0);    -- sdram chip select\nlsdwen  	: in std_ulogic;                       -- sdram write enable\nlsdrasn  	: in std_ulogic;                       -- sdram ras\nlsdcasn  	: in std_ulogic;                       -- sdram cas\nlsddqm   	: in std_logic_vector (3 downto 0);    -- sdram dqm\nldsutx  	: in std_ulogic; 			-- DSU tx data\nldsurx  	: out std_ulogic;  			-- DSU rx data\nldsuen   	: out std_ulogic;\nldsubre  	: out std_ulogic;\nldsuact  	: in std_ulogic;\nltxd1   	: in std_ulogic; 			-- UART1 tx data\nlrxd1   	: out std_ulogic;  			-- UART1 rx data\nltxd2   	: in std_ulogic; 			-- UART2 tx data\nlrxd2   	: out std_ulogic;  			-- UART2 rx data\nlramsn  	: in std_logic_vector (4 downto 0);\nlramoen 	: in std_logic_vector (4 downto 0);\nlrwen   	: in std_logic_vector (3 downto 0);\nloen    	: in std_ulogic;\nlwriten 	: in std_ulogic;\nlread   	: in std_ulogic;\nliosn   	: in std_ulogic;\nlromsn  	: in std_logic_vector (1 downto 0);\nlbrdyn  	: out std_ulogic;\nlbexcn  	: out std_ulogic;\nlwdogn  	: in std_ulogic;\ngpioin      : out std_logic_vector(CFG_GRGPIO_WIDTH-1 downto 0); 	-- I/O port\ngpioout     : in std_logic_vector(CFG_GRGPIO_WIDTH-1 downto 0); 	-- I/O port\ngpioen      : in std_logic_vector(CFG_GRGPIO_WIDTH-1 downto 0); 	-- I/O port\nlprom32	: out std_ulogic;\nlpromedac	: out std_ulogic;\nlspw_clksel	: out std_logic_vector (1 downto 0);\nlspw_clk    : out std_ulogic;\nspw_rxd     : out std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_rxs     : out std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txd     : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_txs     : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nspw_ten     : in  std_logic_vector(0 to CFG_SPW_NUM-1);\nlclk2x      : out std_ulogic;\nlclk4x      : out std_ulogic;\nlclkdis     : in  std_ulogic;\nlclklock    : out std_ulogic;\nllock    	: in std_ulogic;\nlroen       : out std_ulogic;\nlroout      : in  std_ulogic;\nltest       : out std_ulogic;\ngnd       	: in  std_ulogic;\nltrst        : out std_ulogic;\nltck         : out std_ulogic;\nltms         : out std_ulogic;\nltdi         : out std_ulogic;\nltdo         : in std_ulogic\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }


    /*
     * mctrl_avnet com list de propertie-value
     *
     */
    public List<Property> mctrl_avnet(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-avnet-3s1500\\mctrl_avnet.vhd"));
        //
        properties.add(new Property("integer", "hindex", "0", ""));
        properties.add(new Property("integer", "pindex", "0", ""));
        properties.add(new Property("integer", "romaddr", "16#000#", ""));
        properties.add(new Property("integer", "rommask", "16#E00#", ""));
        properties.add(new Property("integer", "ioaddr", "16#200#", ""));
        properties.add(new Property("integer", "iomask", "16#E00#", ""));
        properties.add(new Property("integer", "ramaddr", "16#400#", ""));
        properties.add(new Property("integer", "rammask", "16#C00#", ""));
        properties.add(new Property("integer", "paddr", "0", ""));
        properties.add(new Property("integer", "pmask", "16#fff#", ""));
        properties.add(new Property("integer", "wprot", "0", ""));
        properties.add(new Property("integer", "invclk", "0", ""));
        properties.add(new Property("integer", "fast", "0", ""));
        properties.add(new Property("integer", "romasel", "28", ""));
        properties.add(new Property("integer", "sdrasel", "29", ""));
        properties.add(new Property("integer", "srbanks", "4", ""));
        properties.add(new Property("integer", "ram8", "0", ""));
        properties.add(new Property("integer", "ram16", "0", ""));
        properties.add(new Property("integer", "sden", "0", ""));
        properties.add(new Property("integer", "sepbus", "0", ""));
        properties.add(new Property("integer", "sdbits", "32", ""));
        properties.add(new Property("integer", "sdlsb", "2", ""));
        properties.add(new Property("integer", "oepol", "0", ""));
        properties.add(new Property("integer", "syncrst", "0", ""));
        properties.add(new Property("integer", "pageburst", "0", ""));
        properties.add(new Property("integer", "avnetmezz", "0", ""));
        //
        properties.add(new Property("port", "", "(\nrst       : in  std_ulogic;\nclk       : in  std_ulogic;\nmemi      : in  memory_in_type;\nmemo      : out memory_out_type;\nahbsi     : in  ahb_slv_in_type;\nahbso     : out ahb_slv_out_type;\napbi      : in  apb_slv_in_type;\napbo      : out apb_slv_out_type;\nwpo       : in  wprot_out_type;\nsdo       : out sdram_out_type\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * clkgate com list de propertie-value
     *
     */
    public List<Property> clkgate(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-clock-gate\\clkgate.vhd"));
        properties.add(new Property("port", "port (\nrst     : in  std_ulogic;\nclkin   : in  std_ulogic;\npwd     : in  std_logic_vector(ncpu-1 downto 0);\nclkahb  : out std_ulogic;\nclkcpu  : out std_logic_vector(ncpu-1 downto 0)\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * ahb2mig_grxc6s_2p com list de propertie-value
     * AHB-2.0 interface for the Xilinx Spartan-6 MIG
     */
    public List<Property> ahb2mig_grxc6s_2p(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-gr-xc6s\\ahb2mig_grxc6s_2p.vhd"));
        //
        properties.add(new Property("integer", "hindex", "0", ""));
        properties.add(new Property("integer", "haddr", "0", ""));
        properties.add(new Property("integer", "hmask", "16#f00#", ""));
        properties.add(new Property("integer", "pindex", "0", ""));
        properties.add(new Property("integer", "paddr", "0", ""));
        properties.add(new Property("integer", "vgamst", "0", ""));
        properties.add(new Property("integer", "vgaburst", "0", ""));
        //
        properties.add(new Property("port", "", "(\nmcb3_dram_dq      : inout  std_logic_vector(15 downto 0);\nmcb3_dram_a       : out std_logic_vector(12 downto 0);\nmcb3_dram_ba      : out std_logic_vector(2 downto 0);\nmcb3_dram_ras_n   : out std_logic;\nmcb3_dram_cas_n   : out std_logic;\nmcb3_dram_we_n    : out std_logic;\nmcb3_dram_odt     : out std_logic;\nmcb3_dram_cke     : out std_logic;\nmcb3_dram_dm      : out std_logic;\nmcb3_dram_udqs    : inout std_logic;\nmcb3_rzq          : inout std_logic;\nmcb3_zio          : inout std_logic;\nmcb3_dram_udm     : out std_logic;\nmcb3_dram_dqs     : inout std_logic;\nmcb3_dram_ck      : out std_logic;\nmcb3_dram_ck_n    : out std_logic;\nahbso             : out ahb_slv_out_type;  \nahbsi             : in  ahb_slv_in_type;\nahbmi	      : out ahb_mst_in_type;\nahbmo	      : in  ahb_mst_out_type;  \napbi   	      : in  apb_slv_in_type;\napbo   	      : out apb_slv_out_type;\ncalib_done        : out std_logic;\ntest_error	      : out std_logic; \nrst_n_syn         : in std_logic;\nrst_n_async	      : in std_logic; \nclk_amba          : in std_logic;\nclk_mem_n         : in std_logic;\nclk_mem_p         : in std_logic\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * rgmii com list de propertie-value
     */
    public List<Property> rgmii(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-gr-xc6s\\rgmii.vhd"));
        //
        properties.add(new Property("integer", "tech", "0", ""));
        properties.add(new Property("integer", "rxclk", "0", ""));
        properties.add(new Property("integer", "gmii", "0", ""));
        properties.add(new Property("integer", "odelen", "0", ""));
        //
        properties.add(new Property("port", "", "(\nrstn        : in  std_ulogic;\nclk50       : in  std_ulogic;\ngmiii	: out eth_in_type;\ngmiio	: in  eth_out_type;\nrgmiii	: in  eth_in_type;\nrgmiio	: out eth_out_type\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * svga2ch7301c com list de propertie-value
     * SVGACTRL core to a Chrontel CH7301C DVI transmitter
     */
    public List<Property> svga2ch7301c(List<Property> values){
        List<Property> properties = new LinkedList<Property>();
        //
        properties.add(new Property("pathVHD", "F:\\grlib-gpl-1.1.0-b4108\\grlib-gpl-1.1.0-b4108\\designs\\leon3-gr-xc6s\\rgmii.vhd"));
        //
        properties.add(new Property("integer", "tech", "0", ""));
        properties.add(new Property("integer", "idf", "0", ""));
        properties.add(new Property("integer", "dynamic", "0", ""));
        //
        properties.add(new Property("port", "", "(\nclk         : in  std_ulogic;\nvgao        : in  apbvga_out_type;\nvgaclk      : in  std_ulogic;\ndclk_p      : out std_ulogic;\ndclk_n      : out std_ulogic;\ndata        : out std_logic_vector(11 downto 0);\nhsync       : out std_ulogic;\nvsync       : out std_ulogic;\nde          : out std_ulogic\n);"));
        //
        for(int i = 0; i < values.size(); i++){
            for(int j = 0; j < properties.size(); j++){
                if(properties.get(j).getName().equals(values.get(i).getName())){
                    properties.set(j, new Property(values.get(i).getName(), values.get(i).getValue()));
                }
            }
        }
        //
        return properties;
    }

    /*
     * Return the original name of the type
     */
    public static String consultKindModule(String type){
        if(type.equals("<<hwCPU>>")){
            return "altera_nios2";
        } else if(type.equals("<<hwCLK>>")){
            return "clock_source";
        } else if(type.equals("<<hwRAM>>")){
            return "altera_avalon_onchip_memory2";
        } else if(type.equals("<<hwPIO_RED>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_GREEN>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_SWITCH>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwPIO_BTN>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwSDRAM>>")){
            return "altera_avalon_new_sdram_controller";
        } else if(type.equals("<<hwSSRAM>>")){
            return "altera_avalon_cy7c1380_ssram";
        } else if(type.equals("<<hwTRISTAGE_BRIDGE>>")){
            return "altera_avalon_tri_state_bridge";
        } else if(type.equals("<<hwCFIFlash>")){
            return "altera_avalon_cfi_flash";
        } else if(type.equals("<<hwTIMER>>")){
            return "altera_avalon_timer";
        } else if(type.equals("<<hwTIMER_STAMP>>")){
            return "altera_avalon_timer";
        } else if(type.equals("<<hwJTAG>>")){
            return "altera_avalon_jtag_uart";
        } else if(type.equals("<<hwUART>>")){
            return "altera_avalon_uart";
        } else if(type.equals("<<hwTRISTAGEBRIDGE>>")){
            return "altera_avalon_tri_state_bridge";
        } else if(type.equals("<<hwISP1362_IF>>")){
            return "ISP1362_IF";
        } else if(type.equals("<<hwPIO>>")){
            return "altera_avalon_pio";
        } else if(type.equals("<<hwCLK_SOURCE>>")){
            return "clock_source";
        } else if(type.equals("<<hwSEG7_IF>>")){
            return "SEG7_IF";
        } else if(type.equals("<<hwAUDIO_IF>>")){
            return "AUDIO_IF";
        } else if(type.equals("<<hwVGA>>")){
            return "VGA_NIOS_CTRL";
        } else if(type.equals("<<hwDM9000A_IF>>")){
            return "DM9000A_IF";
        } else if(type.equals("<<hwVGA_NIOS_CTRL>>")){
            return "VGA_NIOS_CTRL";
        } else if(type.equals("<<hwSYSID>>")){
            return "altera_avalon_sysid";
        } else if(type.equals("<<hwPLL>>")){
            return "altera_avalon_pll";
        } else if (type.equals("<<hwISP1362>>")){
            return "ISP1362_IF";
        } else if(type.equals("<<hwALT_PLL>>")){
            return "altpll";
        } else if(type.equals("<<hwLCD>>")){
            return "altera_avalon_lcd_16207";
        } else{
            return "";
        }
    }

    /*
     * Return the characteristics of the specified kind
     */
    public List<Property> searchKindModule(String type, List<Property> atributos){
        /*if(type.equals("<<hwCPU>>")){
            return cpu_nios2(atributos);
        } else if(type.equals("<<hwCLK>>")){
            return clk_source(atributos);
        } else if(type.equals("<<hwRAM>>")){
            return onchip_memory(atributos);
        } else if(type.equals("<<hwPIO_RED>>")){
            return pio_green_led(atributos);
        } else if(type.equals("<<hwPIO_GREEN>>")){
            return pio_red_led(atributos);
        } else if(type.equals("<<hwPIO_SWITCH>>")){
            return pio_switch(atributos);
        } else if(type.equals("<<hwPIO_BTN>>")){
            return pio_button(atributos);
        } else if(type.equals("<<hwSDRAM>>")){
            return SDRAM(atributos);
        } else if(type.equals("<<hwSSRAM>>")){
            return SSRAM(atributos);
        } else if(type.equals("<<hwTRISTAGE_BRIDGE>>")){
            return tri_stage_bridge(atributos);
        } else if(type.equals("<<hwCFIFlash>")){
            return cfi_flash(atributos);
        } else if(type.equals("<<hwTIMER>>")){
            return timer(atributos);
        } else if(type.equals("<<hwTIMER_STAMP>>")){
            return timer_stamp(atributos);
        } else if(type.equals("<<hwJTAG>>")){
            return jtag_uart(atributos);
        } else if(type.equals("<<hwUART>>")){
            return uart(atributos);
        } else if(type.equals("<<hwISP1362_IF>>")){
            return isp1362(atributos);
        } else if(type.equals("<<hwPIO>>")){
            return pio(atributos);
        } else if(type.equals("<<hwCLK_SOURCE>>")){
            return clk(atributos);
        } else if(type.equals("<<hwSEG7_IF>>")){
            return seg7_if(atributos);
        } else if(type.equals("<<hwAUDIO_IF>>")){
            return audio(atributos);
        } else if(type.equals("<<hwVGA>>")){
            return vga(atributos);
        } else if(type.equals("<<hwDM9000A_IF>>")){
            return dm9000a(atributos);
        } else if(type.equals("<<hwVGA_NIOS_CTRL>>")){
            return vga_nios_ctrl(atributos);
        } else if(type.equals("<<hwALT_PLL>>")){
            return altpll(atributos);
        } else if(type.equals("<<hwPLL>>")){
            return pll(atributos);
        } else if(type.equals("<<hwTIMER>>")){
            return timer(atributos);
        } else if(type.equals("<<hwTIMER_STAMP>>")){
            return timer_stamp(atributos);
        } else{*/
            return new LinkedList<Property>();
        //}
    }
}
