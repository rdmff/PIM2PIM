/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.f  tr                                                                                                                                                   
 */
package DataBase;

import Registry.RegistryAltera;
import Library.libAltera;
import Repository.RepositoryAltera;
import java.io.*;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import org.w3c.dom.*;
import Basic.Property;
import Basic.TextFile;
import Library.libXilinx;
import Registry.RegistryXilinx;


/**
 *
 * @author Roberto
 */
public class DatabaseXilinx {   

    /*public void writeXMP(String XmpVersion, String VerMgmt, String IntStype,
            String Flow, String MhsFile, String Architecture, String Device,
            String Package, String SpeedGrade, String UserCmd1,
            String UserCmd1Type, String UserCmd2, String UserCmd2Type,
            String GenSimTB, String SdkExportBmmBit, String SdkExportDir,
            String InsertNoPads, String WarnForEAArch, String HdlLang,
            String SimModel, String ExternalMemSim, String UcfFile,
            String EnableParTimingError, String ShowLicenseDialog,
            String Processor, String ElfImp, String ElfSim)  throws Exception {
        //String nomeCPU = "", nomeRAM = "", nomeJTAG = "", nomeCLK = "", nomeALT_PLL = "";//ainda, core único
        List<Property> propriedades, atributos;
        String[] strAtrib;
    }*/
    /*
     * Grava as coisas em arquivos SOPC
     * Corrigir core única em versões posteriores
     */
    public void writeXMP(String FullPath, List<Property> propriedades)  throws Exception {
        //String nomeCPU = "", nomeRAM = "", nomeJTAG = "", nomeCLK = "", nomeALT_PLL = "";//ainda, core único
        //List<Property> propriedades, atributos;
        String FullText = "#ERVM, by Roberto de Medeiros & Vanderlei Bonato\r\n\r\n";
        for(int i = 0; i < propriedades.size(); i++){
            FullText += propriedades.get(i).getName() + ": " + propriedades.get(i).getValue() + "\r\n";
        }
        TextFile.Write(FullText, FullPath);
    }
    
    public void writeMHS(String path, RegistryXilinx xmi, String nomeProjeto) throws IOException{
        //
        String text = "";
        List<Property> propriedades;
        libXilinx library = new libXilinx();
        //inserindo comentários
        text += "# ----------------------------------------------------------\r\n";
        text += "# Created by Embedded Robotics Visual Modeling\r\n";
        text += "# ----------------------------------------------------------\r\n\r\n";
        //
        text += "PARAMETER VERSION = 2.1.0\r\n\r\n";
        text += "PORT fpga_0_RS232_DTE_RX_pin = fpga_0_RS232_DTE_RX_pin, DIR = I\r\n";
        text += "PORT fpga_0_RS232_DTE_TX_pin = fpga_0_RS232_DTE_TX_pin, DIR = O\r\n";
        text += "PORT fpga_0_RS232_DCE_RX_pin = fpga_0_RS232_DCE_RX_pin, DIR = I\r\n";
        text += "PORT fpga_0_RS232_DCE_TX_pin = fpga_0_RS232_DCE_TX_pin, DIR = O\r\n";
        text += "PORT fpga_0_clk_1_sys_clk_pin = CLK_S, DIR = I, SIGIS = CLK, CLK_FREQ = 50000000\r\n";
        text += "PORT fpga_0_rst_1_sys_rst_pin = sys_rst_s, DIR = I, SIGIS = RST, RST_POLARITY = 1\r\n";
        
        text += "\r\n\r\n";
        for(int i= 0; i < xmi.size(); i++){
            //cada componente é um xmi.getId()
            
            //CORRIGIR AQUI
            //parameterinstance precisa ser o nome
            propriedades = library.searchKindModule(libXilinx.consultKindModule(xmi.get(i).getTipo()), new LinkedList<Property>());
            if(propriedades.size()>0){
                text += "BEGIN " + propriedades.get(0).getValue() + "\r\n";
                //xmi.get(i).getNome()
                //não há atributos
                text += propriedades.get(0).getName() + " = " + xmi.get(i).getNome() + "\r\n";
                for(int j = 1; j < propriedades.size(); j++){
                    text += propriedades.get(j).getName() + " = " + propriedades.get(j).getValue() + "\r\n";
                    //if(xmi.get(i).getAtributo(j))//se contém PARAMETER
                    //text += " "
                }
                text += "END\r\n\r\n";
            }
        }
        TextFile.Write(text, path);
        /*for(int i = 0; i < xmi.size(); i++){
            text += "BEGIN " + xmi.get(i).getNome() + "\n";
            for(int j = 0; j < xmi.get(i).getSizeAtributo(); j++){
                text += "PARAMETER " + xmi.get(i).getAtributo(j) + " = ";
            }
            text += "END\n";
        }*/
    }
    
    public void writeUCF(){
        //
    }
}
