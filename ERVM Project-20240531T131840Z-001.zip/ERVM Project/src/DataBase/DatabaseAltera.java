/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package DataBase;

import Registry.RegistryAltera;
import Library.libAltera;
import Repository.RepositoryAltera;
import java.io.*;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import org.w3c.dom.*;
import Basic.Property;
import Basic.TextFile;
/**
 *
 * @author Roberto
 */
public class DatabaseAltera{
    /*public static void main(String[] args)  throws Exception {

        DocumentBuilderFactory factory =
            DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        // Here instead of parsing an existing document we want to
        // create a new one.
        Document testDoc = builder.newDocument();

        // This creates a new tag named 'testElem' inside
        // the document and sets its data to 'TestContent'
        Element el = testDoc.createElement("testElem");
        el.setTextContent("TestContent");
        /////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////
        ////////////CRIADO POR MIM///////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////
        Element elChild = testDoc.createElement("testElem");
        elChild.setTextContent("TestContent");
        //
        el.appendChild(elChild);
        //
        //
        //
        //
        testDoc.appendChild(el);

        // The XML document we created above is still in memory
        // so we have to output it to a real file.
        // In order to do it we first have to create
        // an instance of DOMSource
        DOMSource source = new DOMSource(testDoc);
        //Node childNode = new javax.xml.soap.Node() {}
        //el.appendChild();
        // PrintStream will be responsible for writing
        // the text data to the file
        PrintStream ps = new PrintStream("c:\\ROBERTO\\test2.xml");
        StreamResult result = new StreamResult(ps);

        // Once again we are using a factory of some sort,
        // this time for getting a Transformer instance,
        // which we use to output the XML
        TransformerFactory transformerFactory = TransformerFactory
            .newInstance();
        Transformer transformer = transformerFactory.newTransformer();

        // The actual output to a file goes here
        transformer.transform(source, result);
    }*/    

    /*
     * Grava as coisas em arquivos SOPC
     * Corrigir core única em versões posteriores
     */
    public void writeSOPC(String path, RegistryAltera xmi, String nomeProjeto, String device)  throws Exception {
        String nomeCPU = "", nomeRAM = "", nomeJTAG = "", nomeCLK = "", nomeALT_PLL = "";//ainda, core único
        List<Property> propriedades, atributos;
        libAltera library = new libAltera();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document testDoc = builder.newDocument();
        Element elSubchild;
        List<String> componentes = new LinkedList<String>();
        //List<String> atributosString = new LinkedList<String>();
        String[] strAtrib;
        //
        int valueKey = 6144;//valor chave que incrementa os endereços (em decimal)
        RepositoryAltera nome1, nome2;
        //List<String> listaELementos
        //
        //String nomeCPU = "", nomeRAM = "", nomeJTAG = "", nomeCLK = "", nomeALT_PLL = "";//ainda, core único
        //
        for(int i = 1; i < xmi.size(); i++){
            if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<HwProcessor>>")){
                nomeCPU = xmi.get(i).getNome();
            }
            else if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<HwRAM>>")){
                nomeRAM = xmi.get(i).getNome();
            }
            else if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<HwI_O>>")){
                nomeJTAG = xmi.get(i).getNome();
            }
            else if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<HwClock>>")){
                nomeCLK = xmi.get(i).getNome();
            }
            else if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<HwPLD>>")){
                nomeALT_PLL = xmi.get(i).getNome();
            }
        }
        /*
         * Neste trecho, tudo pode ser alterado...
         */
        Element el = testDoc.createElement("system");//nome da chave/elemento
        el.setAttribute("name", nomeProjeto);//atributos internos ao elemento
        //
        Element elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "bonusData");//atributos internos ao elemento
        //elChild.setTextContent("![CDATA[bonusData { element AUDIO { datum _sortIndex { value = \"27\"; type = \"int\"; } } element AUDIO_IF_0 { datum _sortIndex { value = \"32\"; type = \"int\"; } } element DE2_70_SOPC { } element DM9000A { datum _sortIndex { value = \"30\"; type = \"int\"; } } element ISP1362 { datum _sortIndex { value = \"19\"; type = \"int\"; } } element ISP1362_IF_0 { datum _sortIndex { value = \"34\"; type = \"int\"; } } element SEG7 { datum _sortIndex { value = \"26\"; type = \"int\"; } } element VGA { datum _sortIndex { value = \"28\"; type = \"int\"; } } element VGA_NIOS_CTRL_0 { datum _sortIndex { value = \"33\"; type = \"int\"; } } element jtag_uart.avalon_jtag_slave { datum _lockedAddress { value = \"0\"; type = \"boolean\"; } datum baseAddress { value = \"155226408\"; type = \"long\"; } } element tristate_bridge_ssram.avalon_slave { datum baseAddress { value = \"0\"; type = \"long\"; } } element tristate_bridge_flash.avalon_slave { datum baseAddress { value = \"0\"; type = \"long\"; } } element pll.c0 { datum _clockDomain { value = \"pll_c0_system\"; type = \"String\"; } } element pll.c1 { datum _clockDomain { value = \"pll_c1_memory\"; type = \"String\"; } } element pll.c2 { datum _clockDomain { value = \"pll_c2_audio\"; type = \"String\"; } } element cfi_flash { datum _sortIndex { value = \"16\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element clk_25 { datum _sortIndex { value = \"31\"; type = \"int\"; } } element clk_50 { datum _sortIndex { value = \"29\"; type = \"int\"; } } element sysid.control_slave { datum baseAddress { value = \"155226400\"; type = \"long\"; } } element lcd.control_slave { datum baseAddress { value = \"155226272\"; type = \"long\"; } } element cpu { datum _sortIndex { value = \"0\"; type = \"int\"; } } element i2c_sclk { datum _sortIndex { value = \"20\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element i2c_sdat { datum _sortIndex { value = \"21\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element cpu.jtag_debug_module { datum baseAddress { value = \"155224064\"; type = \"long\"; } } element jtag_uart { datum _sortIndex { value = \"7\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element lcd { datum _sortIndex { value = \"11\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element onchip_mem { datum _sortIndex { value = \"1\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{memorySize=KBytes}\"; type = \"String\"; } } element pio_button { datum _sortIndex { value = \"9\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element pio_green_led { datum _sortIndex { value = \"4\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element pio_red_led { datum _sortIndex { value = \"5\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element pio_switch { datum _sortIndex { value = \"6\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element pll { datum _sortIndex { value = \"10\"; type = \"int\"; } } element pll.pll_slave { datum baseAddress { value = \"155226384\"; type = \"long\"; } } element ssram.s1 { datum baseAddress { value = \"153092096\"; type = \"long\"; } } element pio_green_led.s1 { datum baseAddress { value = \"155226208\"; type = \"long\"; } } element cfi_flash.s1 { datum baseAddress { value = \"142606336\"; type = \"long\"; } } element sd_clk.s1 { datum baseAddress { value = \"155226320\"; type = \"long\"; } } element timer_stamp.s1 { datum baseAddress { value = \"155226144\"; type = \"long\"; } } element pio_button.s1 { datum baseAddress { value = \"155226256\"; type = \"long\"; } } element i2c_sclk.s1 { datum baseAddress { value = \"155226288\"; type = \"long\"; } } element uart.s1 { datum baseAddress { value = \"155226176\"; type = \"long\"; } } element sdram_u1.s1 { datum baseAddress { value = \"67108864\"; type = \"long\"; } } element timer.s1 { datum baseAddress { value = \"155226112\"; type = \"long\"; } } element pio_red_led.s1 { datum baseAddress { value = \"155226224\"; type = \"long\"; } } element onchip_mem.s1 { datum baseAddress { value = \"155205632\"; type = \"long\"; } } element sd_cmd.s1 { datum baseAddress { value = \"155226336\"; type = \"long\"; } } element pio_switch.s1 { datum baseAddress { value = \"155226240\"; type = \"long\"; } } element sd_dat.s1 { datum baseAddress { value = \"155226352\"; type = \"long\"; } } element sd_dat3.s1 { datum baseAddress { value = \"155226368\"; type = \"long\"; } } element i2c_sdat.s1 { datum baseAddress { value = \"155226304\"; type = \"long\"; } } element sdram_u2.s1 { datum baseAddress { value = \"100663296\"; type = \"long\"; } } element sd_clk { datum _sortIndex { value = \"22\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element sd_cmd { datum _sortIndex { value = \"23\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element sd_dat { datum _sortIndex { value = \"24\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element sd_dat3 { datum _sortIndex { value = \"25\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element sdram_u1 { datum _sortIndex { value = \"12\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element sdram_u2 { datum _sortIndex { value = \"13\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element ssram { datum _sortIndex { value = \"14\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element sysid { datum _sortIndex { value = \"18\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element timer { datum _sortIndex { value = \"2\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element timer_stamp { datum _sortIndex { value = \"3\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element tristate_bridge_flash { datum _sortIndex { value = \"17\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element tristate_bridge_ssram { datum _sortIndex { value = \"15\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element uart { datum _sortIndex { value = \"8\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } } ]]");
        //elSubchild = testDoc.createElement("![CDATA[bonusData { element clk_0 { datum _sortIndex { value = \"0\"; type = \"int\"; } } element cpu_0 { datum _sortIndex { value = \"1\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element cpu_0.jtag_debug_module { datum baseAddress { value = \"2048\"; type = \"long\"; } } } ]]");
        //elChild.setTextContent("<![CDATA[bonusData { element clk_0 { datum _sortIndex { value = \"0\"; type = \"int\"; } } element cpu_0 { datum _sortIndex { value = \"1\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element cpu_0.jtag_debug_module { datum baseAddress { value = \"2048\"; type = \"long\"; } } } ]]>");
        //elChild.setTextContent("<![CDATA[bonusData { element altpll_0 { datum _sortIndex { value = \"4\"; type = \"int\"; } } element jtag_uart_0.avalon_jtag_slave { datum baseAddress { value = \"69648\"; type = \"long\"; } } element beta02 { } element clk_0 { datum _sortIndex { value = \"0\"; type = \"int\"; } } element cpu_0 { datum _sortIndex { value = \"1\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element cpu_0.data_master { datum _tags { value = \"\"; type = \"String\"; } } element cpu_0.jtag_debug_module { datum baseAddress { value = \"67584\"; type = \"long\"; } } element jtag_uart_0 { datum _sortIndex { value = \"3\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element onchip_memory2_0 { datum _sortIndex { value = \"2\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element altpll_0.pll_slave { datum baseAddress { value = \"69632\"; type = \"long\"; } } element onchip_memory2_0.s1 { datum baseAddress { value = \"32768\"; type = \"long\"; } } } ]]>");
        elChild.setTextContent("<![CDATA[bonusData { element altpll_0 { datum _sortIndex { value = \"4\"; type = \"int\"; } } element " + nomeJTAG + ".avalon_jtag_slave { datum baseAddress { value = \"69648\"; type = \"long\"; } } element beta02 { } element " + nomeCLK + " { datum _sortIndex { value = \"0\"; type = \"int\"; } } element " + nomeCPU + " { datum _sortIndex { value = \"1\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element " + nomeCPU + ".data_master { datum _tags { value = \"\"; type = \"String\"; } } element " + nomeCPU + ".jtag_debug_module { datum baseAddress { value = \"67584\"; type = \"long\"; } } element  " + nomeJTAG + " { datum _sortIndex { value = \"3\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element " + nomeRAM + " { datum _sortIndex { value = \"\"; type = \"int\"; } datum megawizard_uipreferences { value = \"{}\"; type = \"String\"; } } element altpll_0.pll_slave { datum baseAddress { value = \"69632\"; type = \"long\"; } } element " + nomeRAM + ".s1 { datum baseAddress { value = \"32768\"; type = \"long\"; } } } ]]>");
        /*
         * Grava os subelementos no elemento principal
         */
        //elChild.appendChild(elSubchild);
        el.appendChild(elChild);
        //
        /*
         * São copiados, embora, na segunda fase recebam inteligência
         */
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "clockCrossingAdapter");
        elChild.setAttribute("value", "HANDSHAKE");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "deviceFamily");
        elChild.setAttribute("value", device);
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "fabricMode");
        elChild.setAttribute("value", "SOPC");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "generateLegacySim");
        elChild.setAttribute("value", "false");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "generationId");
        elChild.setAttribute("value", "0");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "globalResetBus");
        elChild.setAttribute("value", "true");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "hdlLanguage");
        elChild.setAttribute("value", "VHDL");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "maxAdditionalLatency");
        elChild.setAttribute("value", "0");
        //
        el.appendChild(elChild);
        //
        //
        //        
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "projectName");
        elChild.setAttribute("value", nomeProjeto);
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "sopcBorderPoints");
        elChild.setAttribute("value", "true");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "systemHash");
        elChild.setAttribute("value", "-3178706913");
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("parameter");
        elChild.setAttribute("name", "timeStamp");
        elChild.setAttribute("value", "1337890868081");
        //
        el.appendChild(elChild);
        /*
         * fim do código "não alterável" (nesta versão)
         */
        
        /*
         * MONTAGEM DOS COMPONENTES
         */
        for(int i = 1; i < xmi.size(); i++){
            if(!xmi.get(i).getTipo().equals("Connection") && libAltera.consultKindModule(xmi.get(i).getTipo())!=""){
                elChild = testDoc.createElement("module");
                //
                elChild.setAttribute("name", xmi.get(i).getNome());
                elChild.setAttribute("enabled", "1");
                elChild.setAttribute("version", "10.1");
                elChild.setAttribute("kind", libAltera.consultKindModule(xmi.get(i).getTipo()));//esse é o problema
                //
                atributos = new LinkedList<Property>();
                //
                for(int j = 0; j < xmi.get(i).getSizeAtributo(); j++){
                    strAtrib = (xmi.get(i).getAtributo(j).split(":"))[1].split("=");
                    if(strAtrib.length>1)
                        atributos.add(new Property(strAtrib[0], strAtrib[1]));
                }
                //
                propriedades = library.searchKindModule(xmi.get(i).getTipo(), atributos, nomeRAM, nomeCPU, nomeJTAG, nomeCLK, nomeALT_PLL);
                for(int j = 0; j < propriedades.size(); j++){
                    elSubchild = testDoc.createElement("parameter");
                    //
                    elSubchild.setAttribute("name", propriedades.get(j).getName());
                    if(propriedades.get(j).getInternal().equals("")){
                        elSubchild.setAttribute("value", propriedades.get(j).getValue());
                    } else{
                        elSubchild.setTextContent(propriedades.get(j).getInternal());
                    }
                    elChild.appendChild(elSubchild);
                    elChild.setAttribute("name", xmi.get(i).getNome());
                }
                //
                el.appendChild(elChild);
            } /*else{
                //
            }*/
        }


        /*
         * TRATANDO 26/06/2011, Versão Alfa 2
         */
        /*
         * Carrega as Conexões
         */
        //System.out.println("_-_");
        /*--------------------------------------------------------------------------------------
        for(int i = 1; i < xmi.size(); i++){
            if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<hwCPU>>")){
                nomeCPU = xmi.get(i).getNome();
                break;
            }
        }
        //
        //testes de conexões
        //
        elChild = testDoc.createElement("connection");
        //
        elChild.setAttribute("version", "6.1");
        elChild.setAttribute("kind", "avalon");//
        elChild.setAttribute("end", nomeCPU + ".jtag_debug_module");//
        elChild.setAttribute("start", nomeCPU + "." + "instruction_master");//
        //
        elSubchild = testDoc.createElement("parameter");//
        //
        elSubchild.setAttribute("name", "arbitrationPriority");//
        elSubchild.setAttribute("value", "1");//
        //
        elChild.appendChild(elSubchild);//
        //
        //
        elSubchild = testDoc.createElement("parameter");//
        //
        elSubchild.setAttribute("name", "baseAddress");//
        elSubchild.setAttribute("value", "0x00010800");//
        //
        elChild.appendChild(elSubchild);
        //
        el.appendChild(elChild);
        //
        //
        //
        elChild = testDoc.createElement("connection");//
        //
        elChild.setAttribute("version", "6.1");
        elChild.setAttribute("kind", "avalon");//
        elChild.setAttribute("start", nomeCPU + ".data_master");//
        elChild.setAttribute("end", nomeCPU + ".jtag_debug_module");//
        //
        elSubchild = testDoc.createElement("parameter");//
        //
        elSubchild.setAttribute("name", "arbitrationPriority");//
        elSubchild.setAttribute("value", "1");//
        //
        elChild.appendChild(elSubchild);//
        //
        //
        elSubchild = testDoc.createElement("parameter");//
        //
        elSubchild.setAttribute("name", "baseAddress");//
        elSubchild.setAttribute("value", "0x00010800");//
        //
        elChild.appendChild(elSubchild);
        //
        el.appendChild(elChild);

        //
        //onchip memory
        //
        for(int i = 1; i < xmi.size(); i++){
            if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<HwRAM>>")){
                nomeRAM = xmi.get(i).getNome();
                break;
            }
        }
        if(!nomeRAM.equals("")){---------------------------------------------------------------------------*/
            /*elChild = testDoc.createElement("connection");//
            //
            elChild.setAttribute("version", "6.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("start", nomeCPU + ".intruction_master");//
            elChild.setAttribute("end", nomeRAM + ".s1");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x8000");//
            //
            elChild.appendChild(elSubchild);
            //
            el.appendChild(elChild);*/
            //
            //
            //
            /*elChild = testDoc.createElement("connection");//
            //
            elChild.setAttribute("version", "6.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("start", nomeCPU + ".data_master");//
            elChild.setAttribute("end", nomeRAM + ".s1");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x8000");//
            //
            elChild.appendChild(elSubchild);
            //
            el.appendChild(elChild);
        }
        //
        //jtag uart
        //
        for(int i = 1; i < xmi.size(); i++){
            if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<hwIO>>")){
                nomeJTAG = xmi.get(i).getNome();
                break;
            }
        }
        for(int i = 1; i < xmi.size(); i++){
            if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<hwCLK>>")){
                nomeCLK = xmi.get(i).getNome();
                break;
            }
        }
        if(!nomeRAM.equals("") && !nomeCLK.equals("")){
                elChild = testDoc.createElement("connection");//
                //
                elChild.setAttribute("version", "10.1");//
                elChild.setAttribute("kind", "clock");//
                elChild.setAttribute("start", nomeCLK + ".clk");//
                elChild.setAttribute("end", nomeRAM + ".clk1");//
                //
                el.appendChild(elChild);
            }
        if(!(nomeJTAG.equals("") && nomeCLK.equals(""))){
            elChild = testDoc.createElement("connection");//
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "clock");//
            elChild.setAttribute("start", nomeCLK + ".clk");//
            elChild.setAttribute("end", nomeJTAG + ".clk");//
            //
            //
            el.appendChild(elChild);
            //
            //
            elChild = testDoc.createElement("connection");//
            //
            elChild.setAttribute("version", "6.1");//
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("start", nomeCPU + ".data_master");//
            elChild.setAttribute("end", nomeJTAG + ".avalon_jtag_slave");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x00011010");//
            //
            elChild.appendChild(elSubchild);
            //
            el.appendChild(elChild);
            //
            //
            elChild = testDoc.createElement("connection");//
            //
            elChild.setAttribute("version", "10.1");//
            elChild.setAttribute("kind", "interrupt");//
            elChild.setAttribute("start", nomeCPU + ".d_irq");//
            elChild.setAttribute("end", nomeJTAG + ".irq");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "irqNumber");//
            elSubchild.setAttribute("value", "0");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
        }
        //
        //alt pll
        //
        for(int i = 1; i < xmi.size(); i++){
            if(!xmi.get(i).getTipo().equals("Connection") &&
                    xmi.get(i).getTipo().equals("<<hwALT_PLL>>")){
                nomeALT_PLL = xmi.get(i).getNome();
                break;
            }
        }
        if(!nomeALT_PLL.equals("")){
            elChild = testDoc.createElement("connection");//
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "clock");//
            elChild.setAttribute("end", nomeALT_PLL + ".inclk_interface");//
            elChild.setAttribute("start", nomeCLK + ".clk");//
            //
            //
            el.appendChild(elChild);
            //
            //
            if(!nomeCPU.equals("")){
                elChild = testDoc.createElement("connection");//
                //
                elChild.setAttribute("version", "6.1");//
                elChild.setAttribute("kind", "avalon");//
                elChild.setAttribute("end", nomeALT_PLL + ".pll_slave");//
                elChild.setAttribute("start", nomeCPU + ".data_master");//
                //
                //
                elSubchild = testDoc.createElement("parameter");//
                //
                elSubchild.setAttribute("name", "arbitrationPriority");//
                elSubchild.setAttribute("value", "1");//
                //
                elChild.appendChild(elSubchild);//
                //
                elSubchild = testDoc.createElement("parameter");//
                //
                elSubchild.setAttribute("name", "baseAddress");//
                elSubchild.setAttribute("value", "0x00011000");//
                //
                elChild.appendChild(elSubchild);//
                //
                el.appendChild(elChild);
                //
                //
                //
                elChild = testDoc.createElement("connection");//
                //
                elChild.setAttribute("version", "10.1");//
                elChild.setAttribute("kind", "clock");//
                elChild.setAttribute("start", nomeALT_PLL + ".c0");//
                elChild.setAttribute("end", nomeCPU + ".clk");//
                //
                el.appendChild(elChild);
            }------------------------------------------------------------------------------------------*/
            /*if(!nomeRAM.equals("")){
                elChild = testDoc.createElement("connection");//
                //
                elChild.setAttribute("version", "10.1");
                elChild.setAttribute("kind", "clock");//
                elChild.setAttribute("start", nomeALT_PLL + ".c0");//
                elChild.setAttribute("end", nomeRAM + ".clk_0");//
                //
                //
                el.appendChild(elChild);
            }*/
        /*}-----------------------------------------------------------------------------------------------*/

        //
        //
        //
        //
        //REVER... TLVEZ HAJAM ERROS AQUI, alfa3
        //
        /*elChild = testDoc.createElement("connection");
        //
        elChild.setAttribute("version", "10.1");
        elChild.setAttribute("kind", "clock");//
        elChild.setAttribute("end", "pll.inclk_interface");//
        elChild.setAttribute("start", "clk_0.clk");//
        //
        el.appendChild(elChild);*/
        
        //
        //
        //
        /*NOVA IMPLEMENTAÇÃO*/
        if((!nomeJTAG.equals("")&&(!nomeCLK.equals("")))){
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "clock");//
            elChild.setAttribute("end", nomeJTAG + ".clk");//
            elChild.setAttribute("start", nomeCLK + ".clk");//
            //
            el.appendChild(elChild);
        }
        if((!nomeCPU.equals("")&&(!nomeCLK.equals("")))){
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "clock");//
            elChild.setAttribute("end", nomeCPU + ".clk");//
            elChild.setAttribute("start", nomeCLK + ".clk");//
            //
            el.appendChild(elChild);
        }
        if(!nomeCPU.equals("")){
            //
            //
            //
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("end", nomeCPU + ".jtag_debug_module");//
            elChild.setAttribute("start", nomeCPU + ".instruction_master");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x1000");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
            //
            //
            //
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("end", nomeCPU + ".jtag_debug_module");//
            elChild.setAttribute("start", nomeCPU + ".data_master");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x1000");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
        }
        if((!nomeJTAG.equals(""))&&(!nomeCPU.equals(""))){
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("end", nomeJTAG + ".avalon_jtag_slave");//
            elChild.setAttribute("start", nomeCPU + ".data_master");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x0000");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
            //
            //
            //
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "interrupt");//
            elChild.setAttribute("end", nomeJTAG + ".irq");//
            elChild.setAttribute("start", nomeCPU + ".d_irq");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "irqNumber");//
            elSubchild.setAttribute("value", "0");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
        }
        if((!nomeRAM.equals(""))&&(!nomeCLK.equals(""))){
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "clock");//
            elChild.setAttribute("end", nomeRAM + ".clk1");//
            elChild.setAttribute("start", nomeCLK + ".clk");//
            //
            el.appendChild(elChild);
            //
            //
            //
        }
        if((!nomeRAM.equals(""))&&(!nomeCPU.equals(""))){
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("end", nomeRAM + ".s1");//
            elChild.setAttribute("start", nomeCPU + ".instruction_master");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x3000");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
            //
            //
            //
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("end", nomeRAM + ".s1");//
            elChild.setAttribute("start", nomeCPU + ".data_master");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x3000");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
        }
        if((!nomeALT_PLL.equals(""))&&(!nomeCPU.equals(""))&&(!nomeCLK.equals(""))){
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "clock");//
            elChild.setAttribute("end", nomeALT_PLL + ".inclk_interface");//
            elChild.setAttribute("start", nomeCLK + ".clk");//
            //
            el.appendChild(elChild);
            //
            //
            //
            elChild = testDoc.createElement("connection");
            //
            elChild.setAttribute("version", "10.1");
            elChild.setAttribute("kind", "avalon");//
            elChild.setAttribute("end", nomeALT_PLL + ".pll_slave");//
            elChild.setAttribute("start",  nomeCPU + ".data_master");//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "arbitrationPriority");//
            elSubchild.setAttribute("value", "1");//
            //
            elChild.appendChild(elSubchild);//
            //
            elSubchild = testDoc.createElement("parameter");//
            //
            elSubchild.setAttribute("name", "baseAddress");//
            elSubchild.setAttribute("value", "0x0010");//
            //
            elChild.appendChild(elSubchild);//
            //
            el.appendChild(elChild);
        }
        
        
        /*
         * Grava aqui versão alfa 1
         */
        testDoc.appendChild(el);
        DOMSource source = new DOMSource(testDoc);
        //
        PrintStream ps = new PrintStream(path);//path é o endereço
        //
        StreamResult result = new StreamResult(ps);
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.transform(source, result);
        //
        ps.close();
        //tratamento de string com caracteres em html
        
    }

    public static void replaceMinnorGreaterThanXML(String path) throws IOException{
        String original = TextFile.Read(path);
        String gravado = (original.replace("&lt;", "<")).replace("&gt;", ">");
        gravado = gravado.replaceAll("<info/>","&lt;info/&gt;");
        TextFile.Write(gravado, path);
    }
    
    //algo errado
    public static void replaceErrorsXML(String path) throws IOException{
        File pFile = new File(path);
        FileWriter fw;
        BufferedReader br =  new BufferedReader(new FileReader(pFile));
        char c;
        String texto = "", line;
        while((line=br.readLine())!=null){
            texto += line;
        }
        br.close();
        //tratando
        texto = texto.replace("&lt;", "<");
        texto = texto.replace("&gt;", ">");
        //
        pFile = new File(path);
        fw = new FileWriter(pFile);//
        fw.write(texto);
        fw.close();
    }
}
